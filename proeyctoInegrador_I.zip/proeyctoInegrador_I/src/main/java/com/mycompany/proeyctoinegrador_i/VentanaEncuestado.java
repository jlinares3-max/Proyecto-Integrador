/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proeyctoinegrador_i;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.sql.SQLException;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;

public class VentanaEncuestado extends JFrame {

    private final JTextField txtArticulo = new JTextField(20);
    private final JTextField txtCantidad = new JTextField(8);
    private final JTextField txtEquivalencia = new JTextField(8);
    private final JTextField txtValor = new JTextField(10);

    private final JComboBox<String> cbUnidad = new JComboBox<>(
            new String[]{"Seleccione", "CM3", "LITRO", "GRAMO",
                "ONZA", "LIBRA", "KILOGRAMO", "ARROBA", "OTRA"});

    private final JComboBox<String> cbAdquisicion = new JComboBox<>(
            new String[]{"Seleccione", "COMPRA", "PAGO_TRABAJO",
                "REGALO", "TRUEQUE", "PRODUCIDO_HOGAR",
                "NEGOCIO_HOGAR", "OTRA"});

    private final JComboBox<String> cbLugar = new JComboBox<>(
            new String[]{"Seleccione", "Tienda Don Jairo", "Plaza Minorista"});

    private final JComboBox<String> cbFrecuencia = new JComboBox<>(
            new String[]{"Seleccione", "DIARIO", "VARIAS_SEMANA",
                "SEMANAL", "QUINCENAL", "MENSUAL", "BIMESTRAL",
                "TRIMESTRAL", "ESPORADICA"});

    private final JComboBox<String> cbTipoGasto = new JComboBox<>(
            new String[]{"Seleccione", "HOGAR", "PERSONAL"});

    private final DefaultTableModel modelo = new DefaultTableModel(
            new Object[]{
                "Artículo", "Cantidad", "Unidad", "Equivalencia",
                "Adquisición", "Lugar", "Valor", "Frecuencia", "Tipo"
            }, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };

    private final JTable tabla = new JTable(modelo);

    public VentanaEncuestado() {
        setTitle("ENPH Urbano - Gastos diarios");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(1150, 720);
        setMinimumSize(new Dimension(950, 600));
        setLocationRelativeTo(null);

        txtArticulo.setEditable(true);
        txtArticulo.setEnabled(true);

        JPanel principal = new JPanel(new BorderLayout(15, 15));
        principal.setBackground(new Color(245, 247, 250));
        principal.setBorder(BorderFactory.createEmptyBorder(22, 25, 22, 25));
        setContentPane(principal);

        JLabel titulo = new JLabel("Gastos Diarios del Hogar");
        titulo.setFont(new Font("SansSerif", Font.BOLD, 27));
        titulo.setForeground(new Color(34, 49, 63));

        JLabel subtitulo = new JLabel("Día 8 · 2026-08-23");
        subtitulo.setFont(new Font("SansSerif", Font.PLAIN, 15));
        subtitulo.setForeground(new Color(100, 110, 120));

        JPanel encabezado = new JPanel(new BorderLayout(4, 4));
        encabezado.setOpaque(false);
        encabezado.add(titulo, BorderLayout.NORTH);
        encabezado.add(subtitulo, BorderLayout.SOUTH);

        principal.add(encabezado, BorderLayout.NORTH);

        JPanel contenido = new JPanel(new BorderLayout(12, 12));
        contenido.setOpaque(false);
        principal.add(contenido, BorderLayout.CENTER);

        JPanel formulario = new JPanel(new GridBagLayout());
        formulario.setBackground(Color.WHITE);
        formulario.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(225, 229, 235)),
                BorderFactory.createEmptyBorder(18, 18, 18, 18)));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(7, 7, 7, 7);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Fila 0: Artículo (ocupa 3 columnas de ancho para que quede cómodo)
        agregarCampoCompleto(formulario, gbc, 0, 0, "Nombre del artículo o servicio", txtArticulo, 3);

        // Fila 1: Cantidad y Unidad
        agregarCampo(formulario, gbc, 0, 1, "Cantidad", txtCantidad);
        agregarCampo(formulario, gbc, 2, 1, "Unidad de medida", cbUnidad);

        // Fila 2: Equivalencia y Adquisición
        agregarCampo(formulario, gbc, 0, 2, "Equiv. en gramos", txtEquivalencia);
        agregarCampo(formulario, gbc, 2, 2, "Forma de adquisición", cbAdquisicion);

        // Fila 3: Lugar y Valor
        agregarCampo(formulario, gbc, 0, 3, "Lugar de compra", cbLugar);
        agregarCampo(formulario, gbc, 2, 3, "Valor pagado / estimado", txtValor);

        // Fila 4: Frecuencia y Tipo de Gasto
        agregarCampo(formulario, gbc, 0, 4, "Frecuencia de compra", cbFrecuencia);
        agregarCampo(formulario, gbc, 2, 4, "Gasto del hogar o personal", cbTipoGasto);

        JButton btnAgregar = new JButton("Agregar otro artículo");
        btnAgregar.setBackground(new Color(39, 111, 191));
        btnAgregar.setForeground(Color.WHITE);
        btnAgregar.setFocusPainted(false);
        btnAgregar.addActionListener(e -> agregarArticulo());

        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 4;
        gbc.insets = new Insets(14, 7, 5, 7);
        formulario.add(btnAgregar, gbc);

        contenido.add(formulario, BorderLayout.NORTH);

        tabla.setRowHeight(27);
        tabla.setFont(new Font("SansSerif", Font.PLAIN, 12));
        tabla.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 12));
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabla.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBorder(BorderFactory.createTitledBorder("Artículos registrados durante el día"));
        contenido.add(scroll, BorderLayout.CENTER);

        JButton btnEliminar = new JButton("Eliminar artículo seleccionado");
        btnEliminar.addActionListener(e -> eliminarArticulo());

        JButton btnFinalizar = new JButton("Finalizar el día");
        btnFinalizar.setBackground(new Color(35, 135, 91));
        btnFinalizar.setForeground(Color.WHITE);
        btnFinalizar.setFocusPainted(false);
        btnFinalizar.addActionListener(e -> finalizarDia());

        JPanel acciones = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));
        acciones.setOpaque(false);
        acciones.add(btnEliminar);
        acciones.add(btnFinalizar);

        principal.add(acciones, BorderLayout.SOUTH);

        SwingUtilities.invokeLater(() -> txtArticulo.requestFocusInWindow());
    }

    private void agregarCampo(
            JPanel panel,
            GridBagConstraints gbc,
            int x,
            int y,
            String texto,
            java.awt.Component componente) {

        gbc.gridx = x;
        gbc.gridy = y;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.weightx = 0;

        JLabel etiqueta = new JLabel(texto);
        etiqueta.setFont(new Font("SansSerif", Font.BOLD, 12));
        panel.add(etiqueta, gbc);

        gbc.gridx = x + 1;
        gbc.gridy = y;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.weightx = 1;

        componente.setFont(new Font("SansSerif", Font.PLAIN, 13));
        componente.setPreferredSize(new Dimension(200, 30));
        panel.add(componente, gbc);
    }

    private void agregarCampoCompleto(
            JPanel panel,
            GridBagConstraints gbc,
            int x,
            int y,
            String texto,
            java.awt.Component componente,
            int anchoComponente) {

        gbc.gridx = x;
        gbc.gridy = y;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.weightx = 0;

        JLabel etiqueta = new JLabel(texto);
        etiqueta.setFont(new Font("SansSerif", Font.BOLD, 12));
        panel.add(etiqueta, gbc);

        gbc.gridx = x + 1;
        gbc.gridy = y;
        gbc.gridwidth = anchoComponente;
        gbc.gridheight = 1;
        gbc.weightx = 1;

        componente.setFont(new Font("SansSerif", Font.PLAIN, 13));
        componente.setPreferredSize(new Dimension(200, 30));
        panel.add(componente, gbc);
    }

    private void agregarArticulo() {
        String articulo = txtArticulo.getText().trim();
        String cantidadTexto = txtCantidad.getText().trim();
        String equivalenciaTexto = txtEquivalencia.getText().trim();
        String valorTexto = txtValor.getText().trim();

        // Validar solo lo estrictamente necesario para que no te bloquees en la demo
        if (articulo.isEmpty() || cantidadTexto.isEmpty() || valorTexto.isEmpty()) {
            JOptionPane.showMessageDialog(
                    this,
                    "Por favor completa al menos el artículo, la cantidad y el valor.",
                    "Campos pendientes",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            double cantidad = Double.parseDouble(cantidadTexto);
            double valor = Double.parseDouble(valorTexto);

            if (cantidad <= 0 || valor < 0) {
                JOptionPane.showMessageDialog(
                        this,
                        "La cantidad debe ser mayor que cero y el valor no puede ser negativo.",
                        "Datos inválidos",
                        JOptionPane.WARNING_MESSAGE);
                return;
            }

            // Si se quedan en "Seleccione" (índice 0), asignar valores por defecto automáticamente
            String unidad = cbUnidad.getSelectedIndex() == 0 ? "KILOGRAMO" : cbUnidad.getSelectedItem().toString();
            String adquisicion = cbAdquisicion.getSelectedIndex() == 0 ? "COMPRA" : cbAdquisicion.getSelectedItem().toString();
            String frecuencia = cbFrecuencia.getSelectedIndex() == 0 ? "DIARIO" : cbFrecuencia.getSelectedItem().toString();
            String tipoGasto = cbTipoGasto.getSelectedIndex() == 0 ? "HOGAR" : cbTipoGasto.getSelectedItem().toString();
            
            String lugar = "No aplica";
            if (adquisicion.equals("COMPRA")) {
                lugar = cbLugar.getSelectedIndex() == 0 ? "Tienda Don Jairo" : cbLugar.getSelectedItem().toString();
            }

            String equivalencia = equivalenciaTexto.isEmpty() ? "" : equivalenciaTexto;

            // Agregar a la tabla visual
            modelo.addRow(new Object[]{
                articulo,
                cantidad,
                unidad,
                equivalencia,
                adquisicion,
                lugar,
                valor,
                frecuencia,
                tipoGasto
            });

            // Limpiar campos para el siguiente artículo
            txtArticulo.setText("");
            txtCantidad.setText("");
            txtEquivalencia.setText("");
            txtValor.setText("");
            cbUnidad.setSelectedIndex(0);
            cbAdquisicion.setSelectedIndex(0);
            cbLugar.setSelectedIndex(0);
            cbFrecuencia.setSelectedIndex(0);
            cbTipoGasto.setSelectedIndex(0);
            txtArticulo.requestFocusInWindow();

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(
                    this,
                    "Cantidad, equivalencia y valor deben ser valores numéricos.",
                    "Formato incorrecto",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void eliminarArticulo() {
        int fila = tabla.getSelectedRow();

        if (fila == -1) {
            JOptionPane.showMessageDialog(
                    this,
                    "Selecciona un artículo de la tabla.",
                    "Ningún artículo seleccionado",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        modelo.removeRow(tabla.convertRowIndexToModel(fila));
    }

    private void finalizarDia() {
        if (modelo.getRowCount() == 0) {
            JOptionPane.showMessageDialog(
                    this,
                    "Agrega al menos un artículo antes de finalizar el día.",
                    "Sin artículos",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        int confirmacion = JOptionPane.showConfirmDialog(
                this,
                "¿Deseas registrar y guardar todos los artículos en la base de datos de la UDI?",
                "Confirmar guardado",
                JOptionPane.YES_NO_OPTION
        );

        if (confirmacion != JOptionPane.YES_OPTION) {
            return;
        }

        GastoDAO dao = new GastoDAO();
        int exitosos = 0;
        int idEncuestadoDefault = 1;

        try {
            for (int i = 0; i < modelo.getRowCount(); i++) {
                String articulo = modelo.getValueAt(i, 0).toString();
                double cantidad = Double.parseDouble(modelo.getValueAt(i, 1).toString());
                String unidad = modelo.getValueAt(i, 2).toString();
                
                String eqStr = modelo.getValueAt(i, 3).toString();
                Double equivalencia = eqStr.isEmpty() ? null : Double.parseDouble(eqStr);
                
                String adquisicion = modelo.getValueAt(i, 4).toString();
                double valor = Double.parseDouble(modelo.getValueAt(i, 6).toString());
                String frecuencia = modelo.getValueAt(i, 7).toString();
                String tipoGasto = modelo.getValueAt(i, 8).toString();

                boolean guardado = dao.guardarGasto(
                        articulo,
                        cantidad,
                        valor,
                        frecuencia,
                        tipoGasto,
                        adquisicion,
                        unidad,
                        equivalencia,
                        idEncuestadoDefault,
                        1
                );

                if (guardado) {
                    exitosos++;
                }
            }

            JOptionPane.showMessageDialog(
                    this,
                    "Se han guardado exitosamente " + exitosos + " de " + modelo.getRowCount() + " artículos en Oracle.",
                    "Guardado exitoso",
                    JOptionPane.INFORMATION_MESSAGE
            );
            
            modelo.setRowCount(0);

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(
                    this,
                    "Error al guardar los gastos en la base de datos:\n" + ex.getMessage(),
                    "Error de Base de Datos",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> {
            new VentanaEncuestado().setVisible(true);
        });
    }
}