/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proeyctoinegrador_i;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class GastoDAO {

    public boolean guardarGasto(
            String articulo,
            double cantidad,
            double valor,
            String frecuenciaCompra,
            String tipoGasto,
            String formaAdquisicion,
            String unidadMedida,
            Double equivalencia,
            int idEncuestado,
            Integer idLugar) throws SQLException {

        String sql = "INSERT INTO GASTOS ("
                + "ID_GASTO, ARTICULO, CANTIDAD, VALOR, "
                + "FRECUENCIA_COMPRA, FECHA_REGISTRO, "
                + "TIPO_GASTO, FORMA_ADQUISICION, ESTADO, "
                + "UND_MEDIDA, EQUIVALENCIA, ID_ENCUESTADO, ID_LUGAR"
                + ") VALUES ("
                + "ENPH_NUEVO.SEQ_GASTOS.NEXTVAL, ?, ?, ?, ?, "
                + "SYSDATE, ?, ?, 'PENDIENTE', ?, ?, ?, ?"
                + ")";

        try (Connection conexion = ConexionBD.conectar();
             PreparedStatement sentencia =
                     conexion.prepareStatement(sql)) {

            sentencia.setString(1, articulo);
            sentencia.setDouble(2, cantidad);
            sentencia.setDouble(3, valor);
            sentencia.setString(4, frecuenciaCompra);
            sentencia.setString(5, tipoGasto);
            sentencia.setString(6, formaAdquisicion);
            sentencia.setString(7, unidadMedida);

            if (equivalencia == null) {
                sentencia.setNull(8, java.sql.Types.NUMERIC);
            } else {
                sentencia.setDouble(8, equivalencia);
            }

            sentencia.setInt(9, idEncuestado);

            if (idLugar == null) {
                sentencia.setNull(10, java.sql.Types.NUMERIC);
            } else {
                sentencia.setInt(10, idLugar);
            }

            return sentencia.executeUpdate() == 1;
        }
    }
}