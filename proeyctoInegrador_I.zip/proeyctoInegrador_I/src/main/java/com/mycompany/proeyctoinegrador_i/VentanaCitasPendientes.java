package com.mycompany.proeyctoinegrador_i;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class VentanaCitasPendientes extends JFrame {

    private final Color fondo = new Color(245, 245, 245);
    private final Color textoSecundario = new Color(115, 115, 115);
    private final Color naranja = new Color(180, 105, 0);

    public VentanaCitasPendientes() {
        setTitle("Citas pendientes");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(850, 570);
        setLocationRelativeTo(null);

        JPanel principal = new JPanel();
        principal.setLayout(new BoxLayout(principal, BoxLayout.Y_AXIS));
        principal.setBackground(fondo);
        principal.setBorder(new EmptyBorder(18, 24, 18, 24));

        JLabel titulo = new JLabel("Citas pendientes");
        titulo.setFont(new Font("SansSerif", Font.BOLD, 13));

        JLabel resumen = new JLabel(
                "4 citas · 2 hoy · 1 visita fallida por reagendar");
        resumen.setFont(new Font("SansSerif", Font.PLAIN, 11));
        resumen.setForeground(textoSecundario);

        principal.add(Box.createVerticalStrut(18));
        principal.add(titulo);
        principal.add(Box.createVerticalStrut(5));
        principal.add(resumen);
        principal.add(Box.createVerticalStrut(15));

        String hoy = LocalDate.now().format(
                DateTimeFormatter.ofPattern("dd/MM/yyyy"));

        agregarFecha(principal, "Hoy · " + hoy);

        // Primera visita: aún no hay hogar, no abre seguimiento.
        agregarCita(
                principal,
                "03:00 PM · V-0232",
                "Cra 4 #12-50 · El Reposo",
                "Entregar el cuadernillo 2 y registrar el capítulo A",
                "Primera visita",
                "Novedad",
                "Iniciar visita",
                () -> abrirVisita("V-0232")
        );

        // TODO: reemplazar 2, 2 por los IDs reales traídos de Oracle.
        final int idEncH0260 = 2;
        final int idHogH0260 = 2;
        agregarCita(
                principal,
                "05:30 PM · H-0260-01",
                "Cll 9 #3-21 · Centro · Día 5 de 14",
                "Nadie atendió el 21/08 · 2.º intento · Día 4 sin registrar",
                "Visita fallida",
                "Novedad",
                "Iniciar visita",
                () -> abrirSeguimiento(idEncH0260, idHogH0260)
        );

        principal.add(Box.createVerticalStrut(15));
        agregarFecha(principal, "Mañana · "
                + LocalDate.now().plusDays(1).format(
                        DateTimeFormatter.ofPattern("dd/MM/yyyy")));

        // TODO: reemplazar 3, 3 por los IDs reales traídos de Oracle.
        final int idEncH0198 = 3;
        final int idHogH0198 = 3;
        agregarCita(
                principal,
                "09:00 AM · H-0198-01",
                "Cll 9 #3-21 · Día 14 de 14",
                "Recoger el cuadernillo, aplicar D2 y cerrar el ciclo",
                "Visita de cierre",
                "Novedad",
                "Cerrar ciclo",
                () -> cerrarCiclo("H-0198-01", idEncH0198, idHogH0198)
        );

        principal.add(Box.createVerticalStrut(15));
        agregarFecha(principal, LocalDate.now().plusDays(2).format(
                DateTimeFormatter.ofPattern("dd/MM/yyyy")));

        // TODO: reemplazar 4, 4 por los IDs reales traídos de Oracle.
        final int idEncH0231 = 4;
        final int idHogH0231 = 4;
        agregarCita(
                principal,
                "10:00 AM · H-0231-01",
                "Cra 4 #12-46 · El Reposo · Visita 5 · Día 10 de 14",
                "Día 6 sin registrar · 7 de 8 días completos",
                "",
                "Novedad",
                "Ver hogar",
                () -> abrirSeguimiento(idEncH0231, idHogH0231)
        );

        JScrollPane scroll = new JScrollPane(principal);
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(16);

        setContentPane(scroll);
    }

    private void agregarFecha(JPanel panel, String fecha) {
        JLabel etiqueta = new JLabel(fecha);
        etiqueta.setFont(new Font("SansSerif", Font.PLAIN, 11));
        etiqueta.setForeground(textoSecundario);
        etiqueta.setAlignmentX(Component.LEFT_ALIGNMENT);

        panel.add(etiqueta);
        panel.add(Box.createVerticalStrut(7));
    }

    private void agregarCita(
            JPanel panel,
            String titulo,
            String direccion,
            String descripcion,
            String estado,
            String textoNovedad,
            String textoAccion,
            Runnable accion) {

        JPanel tarjeta = new JPanel(new BorderLayout(10, 5));
        tarjeta.setBackground(Color.WHITE);
        tarjeta.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(
                        new Color(220, 220, 220)),
                new EmptyBorder(11, 12, 11, 12)
        ));
        tarjeta.setMaximumSize(new Dimension(Integer.MAX_VALUE, 95));
        tarjeta.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel informacion = new JPanel();
        informacion.setBackground(Color.WHITE);
        informacion.setLayout(new BoxLayout(informacion, BoxLayout.Y_AXIS));

        JLabel lblTitulo = new JLabel(titulo);
        lblTitulo.setFont(new Font("SansSerif", Font.BOLD, 12));

        JLabel lblDireccion = new JLabel(direccion);
        lblDireccion.setFont(new Font("SansSerif", Font.PLAIN, 10));
        lblDireccion.setForeground(textoSecundario);

        JLabel lblDescripcion = new JLabel("□ " + descripcion);
        lblDescripcion.setFont(new Font("SansSerif", Font.PLAIN, 10));
        lblDescripcion.setForeground(naranja);

        informacion.add(lblTitulo);
        informacion.add(Box.createVerticalStrut(4));
        informacion.add(lblDireccion);
        informacion.add(Box.createVerticalStrut(3));
        informacion.add(lblDescripcion);

        tarjeta.add(informacion, BorderLayout.CENTER);

        JPanel acciones = new JPanel(
                new FlowLayout(FlowLayout.RIGHT, 5, 12));
        acciones.setBackground(Color.WHITE);

        if (!estado.isBlank()) {
            JLabel etiquetaEstado = new JLabel(estado);
            etiquetaEstado.setFont(
                    new Font("SansSerif", Font.PLAIN, 9));
            etiquetaEstado.setForeground(new Color(70, 110, 170));
            acciones.add(etiquetaEstado);
        }

        JButton novedad = new JButton(textoNovedad);
        novedad.setFont(new Font("SansSerif", Font.PLAIN, 11));
        novedad.setForeground(new Color(180, 130, 0));
        novedad.setBackground(Color.WHITE);
        novedad.addActionListener(e -> registrarNovedad(titulo));
        acciones.add(novedad);

        JButton botonAccion = new JButton(textoAccion);
        botonAccion.setFont(new Font("SansSerif", Font.PLAIN, 11));
        botonAccion.addActionListener(e -> accion.run());
        acciones.add(botonAccion);

        tarjeta.add(acciones, BorderLayout.EAST);

        panel.add(tarjeta);
        panel.add(Box.createVerticalStrut(9));
    }

    private void registrarNovedad(String cita) {
        String observacion = JOptionPane.showInputDialog(
                this,
                "Describe la novedad de la cita:\n" + cita,
                "Registrar novedad",
                JOptionPane.PLAIN_MESSAGE
        );

        if (observacion != null && !observacion.isBlank()) {
            JOptionPane.showMessageDialog(
                    this,
                    "Novedad capturada en pantalla.\n"
                    + "Falta conectar su almacenamiento con Oracle."
            );
        }
    }

    private void abrirVisita(String hogar) {
        JOptionPane.showMessageDialog(
                this,
                "Cita seleccionada: " + hogar
                + "\nLa apertura de la visita se conectará "
                + "con el módulo de seguimiento."
        );
    }

    /** Abre el seguimiento del hogar de la cita seleccionada. */
    private void abrirSeguimiento(int idEncuestado, int idHogar) {
        new VentanaSeguimientoHogar(idEncuestado, idHogar)
                .setVisible(true);
    }

    private void cerrarCiclo(String codigoHogar,
                             int idEncuestado, int idHogar) {
        int respuesta = JOptionPane.showConfirmDialog(
                this,
                "¿Deseas iniciar el cierre del ciclo de "
                + codigoHogar + "?",
                "Cerrar ciclo",
                JOptionPane.YES_NO_OPTION
        );

        if (respuesta == JOptionPane.YES_OPTION) {
            JOptionPane.showMessageDialog(
                    this,
                    "Antes de cerrar, se debe verificar en Oracle "
                    + "que los 14 días estén revisados."
            );
            abrirSeguimiento(idEncuestado, idHogar);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() ->
                new VentanaCitasPendientes().setVisible(true)
        );
    }
}