/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.mycompany.proeyctoinegrador_i;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class VentanaSeguimientoHogar extends JFrame {

    private final Color fondo = new Color(245, 245, 245);
    private final Color gris = new Color(110, 110, 110);
    private final Color azul = new Color(35, 105, 210);

    private final DefaultTableModel modelo = new DefaultTableModel(
            new Object[]{
                "Día", "Fecha", "Estado", "Artículos",
                "Total (COP)", "Acción"
            }, 0) {
        @Override
        public boolean isCellEditable(int fila, int columna) {
            return false;
        }
    };

    private final String[] estados = {
        "Completo", "Completo", "Completo", "Pendiente",
        "Completo", "Pendiente", "Pendiente", "Pendiente",
        "Pendiente", "Pendiente", "Pendiente", "Pendiente",
        "Pendiente", "Pendiente"
    };

    private final int idEncuestado;
    private final int idHogar;

    public VentanaSeguimientoHogar(int idEncuestado, int idHogar) {
        this.idEncuestado = idEncuestado;
        this.idHogar = idHogar;
        setTitle("Seguimiento del hogar");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(1050, 720);
        setLocationRelativeTo(null);

        JPanel principal = new JPanel();
        principal.setLayout(new BoxLayout(principal, BoxLayout.Y_AXIS));
        principal.setBackground(fondo);
        principal.setBorder(new EmptyBorder(18, 22, 18, 22));

        JLabel migas = new JLabel(
                "Citas pendientes  /  Seguimiento del hogar");
        migas.setFont(new Font("SansSerif", Font.PLAIN, 12));
        migas.setForeground(gris);

        JLabel titulo = new JLabel("Seguimiento al hogar");
        titulo.setFont(new Font("SansSerif", Font.BOLD, 25));

        JLabel fecha = new JLabel("23/08/2026");
        fecha.setFont(new Font("SansSerif", Font.PLAIN, 13));
        fecha.setForeground(gris);

        principal.add(migas);
        principal.add(Box.createVerticalStrut(12));
        principal.add(titulo);
        principal.add(Box.createVerticalStrut(5));
        principal.add(fecha);
        principal.add(Box.createVerticalStrut(15));

        JPanel hogar = new JPanel(new GridLayout(2, 3, 12, 10));
        hogar.setBackground(Color.WHITE);
        hogar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(225, 225, 225)),
                new EmptyBorder(15, 15, 15, 15)));

        hogar.add(dato("Código del hogar", "H-0260-01"));
        hogar.add(dato("Encuestado", "María Eugenia García López"));
        hogar.add(dato("Recolector", "Laura Gómez"));
        hogar.add(dato("Dirección", "Cll 9 #3-21 · Centro"));
        hogar.add(dato("Estado del ciclo", "En seguimiento"));
        hogar.add(dato("Periodo", "Día 5 de 14"));

        principal.add(hogar);
        principal.add(Box.createVerticalStrut(18));

        JLabel tituloDias = new JLabel("Registro diario de gastos");
        tituloDias.setFont(new Font("SansSerif", Font.BOLD, 17));
        principal.add(tituloDias);
        principal.add(Box.createVerticalStrut(9));

        JPanel resumen = new JPanel(new GridLayout(1, 3, 10, 0));
        resumen.setOpaque(false);
        resumen.add(tarjetaResumen("Días completos", "4 de 14", new Color(35, 140, 85)));
        resumen.add(tarjetaResumen("Días pendientes", "10 de 14", new Color(180, 120, 15)));
        resumen.add(tarjetaResumen("Gastos registrados", "4", azul));
        principal.add(resumen);
        principal.add(Box.createVerticalStrut(15));

        for (int i = 0; i < 14; i++) {
            int dia = i + 1;
            String estado = estados[i];
            String fechaDia = String.format("%02d/08/2026", 19 + i);

            Object[] fila = {
                "Día " + dia,
                fechaDia,
                estado,
                dia <= 4 ? "1" : "—",
                dia <= 4 ? "$9.600" : "—",
                dia <= 4 ? "Ver gastos" : "Registrar"
            };
            modelo.addRow(fila);
        }

        JTable tabla = new JTable(modelo);
        tabla.setRowHeight(30);
        tabla.getTableHeader().setFont(
                new Font("SansSerif", Font.BOLD, 12));
        tabla.setFont(new Font("SansSerif", Font.PLAIN, 12));
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scrollTabla = new JScrollPane(tabla);
        scrollTabla.setPreferredSize(new Dimension(900, 340));
        scrollTabla.setBorder(BorderFactory.createLineBorder(
                new Color(220, 220, 220)));

        principal.add(scrollTabla);
        principal.add(Box.createVerticalStrut(15));

        JPanel botones = new JPanel(
                new FlowLayout(FlowLayout.RIGHT, 10, 5));
        botones.setOpaque(false);

        JButton btnVolver = new JButton("Volver a citas pendientes");
        JButton btnCorregir = new JButton("Corregir gasto seleccionado");

        btnCorregir.setBackground(azul);
        btnCorregir.setForeground(Color.WHITE);
        btnCorregir.setFocusPainted(false);

        botones.add(btnVolver);
        botones.add(btnCorregir);
        principal.add(botones);

        btnVolver.addActionListener(e -> dispose());

        btnCorregir.addActionListener(e -> {
            int fila = tabla.getSelectedRow();

            if (fila < 0) {
                JOptionPane.showMessageDialog(
                        this,
                        "Selecciona un día de la tabla primero.",
                        "Seleccionar día",
                        JOptionPane.WARNING_MESSAGE);
                return;
            }

            int dia = fila + 1;

            if (dia > 4) {
                JOptionPane.showMessageDialog(
                        this,
                        "Este día no tiene gastos de ejemplo. "
                        + "La consulta real de gastos se conectará a Oracle.");
                return;
            }

            JOptionPane.showMessageDialog(
                    this,
                    "Día seleccionado: " + dia
                    + "\nEl formulario de corrección se conectará "
                    + "con los datos reales en el siguiente paso.");
        });

        setContentPane(new JScrollPane(principal));
    }

    private JPanel dato(String titulo, String valor) {
        JPanel panel = new JPanel();
        panel.setBackground(Color.WHITE);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        JLabel t = new JLabel(titulo);
        t.setForeground(gris);
        t.setFont(new Font("SansSerif", Font.PLAIN, 11));

        JLabel v = new JLabel(valor);
        v.setFont(new Font("SansSerif", Font.BOLD, 13));

        panel.add(t);
        panel.add(Box.createVerticalStrut(5));
        panel.add(v);

        return panel;
    }

    private JPanel tarjetaResumen(String titulo, String valor, Color color) {
        JPanel panel = new JPanel();
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(225, 225, 225)),
                new EmptyBorder(12, 14, 12, 14)));
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        JLabel t = new JLabel(titulo);
        t.setForeground(gris);
        t.setFont(new Font("SansSerif", Font.PLAIN, 12));

        JLabel v = new JLabel(valor);
        v.setForeground(color);
        v.setFont(new Font("SansSerif", Font.BOLD, 22));

        panel.add(t);
        panel.add(Box.createVerticalStrut(6));
        panel.add(v);

        return panel;
    }

    public static void main(String[] args) {
    SwingUtilities.invokeLater(() -> {
        new VentanaSeguimientoHogar(1, 1).setVisible(true);
    });
}
}