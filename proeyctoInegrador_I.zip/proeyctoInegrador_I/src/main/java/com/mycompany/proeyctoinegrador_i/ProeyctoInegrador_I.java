package com.mycompany.proeyctoinegrador_i;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.SwingUtilities;

public class ProeyctoInegrador_I {

    public static void main(String[] args) {
        System.out.println("Iniciando Proyecto Integrador...");

        // 1. Validar la conexión a Oracle en consola (demostración de arquitectura)
        String sql = "SELECT COUNT(*) AS TOTAL FROM USER_TABLES";

        try (Connection conexion = ConexionBD.conectar();
             Statement sentencia = conexion.createStatement();
             ResultSet resultado = sentencia.executeQuery(sql)) {

            if (resultado.next()) {
                System.out.println("Conexion a Oracle exitosa.");
                System.out.println(
                    "Tablas del esquema ENPH_NUEVO: "
                    + resultado.getInt("TOTAL")
                );
            }

        } catch (SQLException e) {
            System.out.println("Error al consultar Oracle:");
            System.out.println(e.getMessage());
        }

        // 2. Lanzar la ventana de inicio de sesión de la aplicación
        SwingUtilities.invokeLater(() -> {
            new VentanaLogin().setVisible(true);
        });
    }
}