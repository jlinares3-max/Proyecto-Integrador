package com.mycompany.proeyctoinegrador_i;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class VentanaLogin extends JFrame {

    private final JButton btnRecolector = new JButton("Ingresar como Recolector");
    private final JButton btnEncuestado = new JButton("Ingresar como Encuestado (Cuadernillo 2)");

    public VentanaLogin() {
        setTitle("ENPH Urbano - Selección de Rol");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(460, 420);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel fondo = new JPanel(new BorderLayout());
        fondo.setBackground(new Color(245, 245, 245));
        fondo.setBorder(new EmptyBorder(16, 20, 16, 20));

        JPanel tarjeta = new JPanel();
        tarjeta.setBackground(new Color(250, 250, 250));
        tarjeta.setBorder(new EmptyBorder(30, 30, 20, 30));
        tarjeta.setLayout(new BoxLayout(tarjeta, BoxLayout.Y_AXIS));

        JLabel icono = new JLabel("\u2611", SwingConstants.CENTER);
        icono.setOpaque(true);
        icono.setBackground(new Color(220, 235, 255));
        icono.setForeground(new Color(37, 99, 235));
        icono.setFont(new Font("SansSerif", Font.BOLD, 34));
        icono.setPreferredSize(new Dimension(56, 56));
        icono.setMaximumSize(new Dimension(56, 56));
        icono.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel titulo = new JLabel("ENPH Urbano");
        titulo.setFont(new Font("SansSerif", Font.BOLD, 21));
        titulo.setForeground(new Color(25, 32, 45));
        titulo.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel subtitulo = new JLabel("Seleccione el módulo a presentar");
        subtitulo.setFont(new Font("SansSerif", Font.PLAIN, 13));
        subtitulo.setForeground(new Color(105, 115, 130));
        subtitulo.setAlignmentX(Component.CENTER_ALIGNMENT);

        tarjeta.add(icono);
        tarjeta.add(Box.createVerticalStrut(15));
        tarjeta.add(titulo);
        tarjeta.add(Box.createVerticalStrut(6));
        tarjeta.add(subtitulo);
        tarjeta.add(Box.createVerticalStrut(30));

        // Botón para Recolector
        estilizarBoton(btnRecolector, new Color(35, 105, 210));
        btnRecolector.addActionListener(e -> abrirModuloRecolector());
        tarjeta.add(btnRecolector);

        tarjeta.add(Box.createVerticalStrut(15));

        // Botón para Encuestado
        estilizarBoton(btnEncuestado, new Color(35, 135, 91));
        btnEncuestado.addActionListener(e -> abrirModuloEncuestado());
        tarjeta.add(btnEncuestado);

        tarjeta.add(Box.createVerticalGlue());

        JLabel pie = new JLabel("Arquitectura Cliente-Servidor · UDI 2026");
        pie.setFont(new Font("SansSerif", Font.PLAIN, 11));
        pie.setForeground(new Color(120, 130, 145));
        pie.setAlignmentX(Component.CENTER_ALIGNMENT);
        tarjeta.add(pie);

        fondo.add(tarjeta, BorderLayout.CENTER);
        setContentPane(fondo);
    }

    private void estilizarBoton(JButton boton, Color colorFondo) {
        boton.setFont(new Font("SansSerif", Font.BOLD, 13));
        boton.setForeground(Color.WHITE);
        boton.setBackground(colorFondo);
        boton.setOpaque(true);
        boton.setBorderPainted(false);
        boton.setFocusPainted(false);
        boton.setMaximumSize(new Dimension(Integer.MAX_VALUE, 48));
        boton.setAlignmentX(Component.CENTER_ALIGNMENT);
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    private void abrirModuloRecolector() {
        dispose();
        // Abre la ventana de citas pendientes correspondiente al rol de recolector
        new VentanaCitasPendientes().setVisible(true);
    }

    private void abrirModuloEncuestado() {
        dispose();
        // Abre la ventana de captura de gastos del cuadernillo 2
        new VentanaEncuestado().setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() ->
                new VentanaLogin().setVisible(true));
    }
}