package com.dao;

import com.conexion.ConexionOracle;
import com.modelo.Hogar;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;

public class HogarDAO {

    public boolean insertarHogar(Hogar hogar) {
        String sql = "INSERT INTO HOGAR (ID_HOGAR, TOTAL_PERSONAS, ID_VIVIENDA, DOCUMENTO_RECOLECTOR, FECHA_INICIO, FECHA_FIN, FECHA_PRIMERA_VISITA) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection con = ConexionOracle.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setLong(1, hogar.getIdHogar());
            ps.setLong(2, hogar.getTotalPersonas());
            ps.setLong(3, hogar.getIdVivienda());
            
            if (hogar.getDocumentoRecolector() != null) {
                ps.setLong(4, hogar.getDocumentoRecolector());
            } else {
                ps.setNull(4, java.sql.Types.NUMERIC);
            }
            
            ps.setTimestamp(5, new Timestamp(hogar.getFechaInicio().getTime()));
            ps.setTimestamp(6, new Timestamp(hogar.getFechaFin().getTime()));
            ps.setTimestamp(7, new Timestamp(hogar.getFechaPrimeraVisita().getTime()));

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Error al insertar hogar en Oracle: " + e.getMessage());
            return false;
        }
    }
}