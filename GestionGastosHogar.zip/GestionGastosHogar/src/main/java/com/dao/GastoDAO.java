package com.dao;

import com.conexion.ConexionOracle;
import com.modelo.Gasto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;

public class GastoDAO {

    public boolean insertarGasto(Gasto gasto) {
        String sql = "INSERT INTO Gastos (Id_gasto, Articulo, Cantidad, Valor_producto, Fecha_registro, Estado, " +
                     "Id_hogar, Id_encuestado, Id_forma, Id_tipo, Id_unidad, Id_frecuencia) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection con = ConexionOracle.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setLong(1, gasto.getIdGasto());
            ps.setString(2, gasto.getArticulo());
            ps.setDouble(3, gasto.getCantidad());
            ps.setDouble(4, gasto.getValorProducto());
            ps.setTimestamp(5, new Timestamp(gasto.getFechaRegistro().getTime()));
            ps.setString(6, gasto.getEstado() != null ? gasto.getEstado() : "REGISTRADO");
            ps.setLong(7, gasto.getIdHogar());
            ps.setString(8, gasto.getIdEncuestado());
            ps.setLong(9, gasto.getIdForma());
            ps.setLong(10, gasto.getIdTipo());
            ps.setLong(11, gasto.getIdUnidad());
            ps.setLong(12, gasto.getIdFrecuencia());

            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("Error al insertar el gasto en la base de datos: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
}