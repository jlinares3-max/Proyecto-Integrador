package com.dao;

import com.conexion.ConexionOracle;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class VisitaDAO {

    /**
     * Consulta la base de datos Oracle para obtener el día activo de un hogar.
     * Si no existen registros, retorna 1.
     */
    public int obtenerDiaActual(String idHogar) {
        int diaActual = 1;
        String sql = "SELECT NVL(MAX(num_dia), 0) + 1 AS proximo_dia FROM visita WHERE id_hogar = ?";

        Connection conn = ConexionOracle.obtenerConexion();
        if (conn != null) {
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, idHogar);
                
                try (ResultSet rs = pstmt.executeQuery()) {
                    if (rs.next()) {
                        diaActual = rs.getInt("proximo_dia");
                        if (diaActual > 14) {
                            diaActual = 14; // Límite de 14 días para la encuesta ENPH
                        }
                    }
                }
            } catch (SQLException e) {
                System.err.println("Error al consultar el día actual en VisitaDAO: " + e.getMessage());
            } finally {
                ConexionOracle.cerrarConexion(conn);
            }
        }
        return diaActual;
    }

    /**
     * Inserta la visita en Oracle DB con COMMIT explícito.
     */
    public boolean registrarVisita(String idHogar, int numDia, String observacion) {
        String sql = "INSERT INTO visita (id_hogar, num_dia, fecha_visita, observacion) VALUES (?, ?, SYSDATE, ?)";
        boolean guardado = false;

        Connection conn = ConexionOracle.obtenerConexion();
        if (conn != null) {
            try {
                conn.setAutoCommit(false); // Transacción manual

                try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                    pstmt.setString(1, idHogar);
                    pstmt.setInt(2, numDia);
                    pstmt.setString(3, observacion);

                    int filas = pstmt.executeUpdate();
                    if (filas > 0) {
                        conn.commit(); // Confirmación en Oracle
                        System.out.println("Visita del día " + numDia + " guardada exitosamente.");
                        guardado = true;
                    } else {
                        conn.rollback();
                    }
                } catch (SQLException e) {
                    conn.rollback();
                    System.err.println("Error en la inserción de la visita: " + e.getMessage());
                }
            } catch (SQLException e) {
                System.err.println("Error en la transacción Oracle: " + e.getMessage());
            } finally {
                ConexionOracle.cerrarConexion(conn);
            }
        }
        return guardado;
    }
}