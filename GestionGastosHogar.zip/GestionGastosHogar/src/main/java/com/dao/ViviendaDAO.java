package com.dao;

import com.conexion.ConexionOracle;
import com.modelo.Vivienda; // Asegúrate de tener tu modelo Vivienda
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ViviendaDAO {

    public boolean insertarVivienda(Vivienda vivienda) {
        String sql = "INSERT INTO VIVIENDA (ID_VIVIENDA, DIRECCION, CANT_HOGARES, ESTADO, ID_BARRIO) VALUES (?, ?, ?, ?, ?)";

        try (Connection con = ConexionOracle.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setLong(1, vivienda.getIdVivienda());
            ps.setString(2, vivienda.getDireccion());
            ps.setLong(3, vivienda.getCantHogares());
            ps.setString(4, vivienda.getEstado() != null ? vivienda.getEstado() : "ACTIVA");
            ps.setLong(5, vivienda.getIdBarrio());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Error al insertar vivienda en Oracle: " + e.getMessage());
            return false;
        }
    }
}