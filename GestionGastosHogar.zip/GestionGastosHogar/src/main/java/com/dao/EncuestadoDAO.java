package com.dao;

import com.conexion.ConexionOracle;
import com.modelo.Encuestado;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;

public class EncuestadoDAO {

    public boolean insertarEncuestado(Encuestado enc) {
        String sql = "INSERT INTO ENCUESTADO (DOCUMENTO, NOMBRE, APELLIDO, PARENTESCO, TELEFONO, CORREO, ID_HOGAR, ID_DISPOSITIVO, FECHA_ENTREGA, FECHA_RECOGIDA) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection con = ConexionOracle.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, enc.getDocumento());
            ps.setString(2, enc.getNombre());
            ps.setString(3, enc.getApellido());
            ps.setString(4, enc.getParentesco());
            ps.setLong(5, enc.getTelefono());
            ps.setString(6, enc.getCorreo());
            ps.setLong(7, enc.getIdHogar());
            ps.setLong(8, enc.getIdDispositivo());
            ps.setTimestamp(9, enc.getFechaEntrega() != null ? new Timestamp(enc.getFechaEntrega().getTime()) : new Timestamp(System.currentTimeMillis()));
            
            if (enc.getFechaRecogida() != null) {
                ps.setTimestamp(10, new Timestamp(enc.getFechaRecogida().getTime()));
            } else {
                ps.setNull(10, java.sql.Types.DATE);
            }

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Error al insertar encuestado: " + e.getMessage());
            return false;
        }
    }
}