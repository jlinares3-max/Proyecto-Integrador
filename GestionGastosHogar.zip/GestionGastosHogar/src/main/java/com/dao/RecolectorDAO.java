package com.dao;

import com.conexion.ConexionOracle;
import com.modelo.Recolector;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class RecolectorDAO {

    public boolean insertarRecolector(Recolector recolector) {
        String sql = "INSERT INTO Recolector (Documento, Credencial, Nombre, Apellido) VALUES (?, ?, ?, ?)";

        try (Connection con = ConexionOracle.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setLong(1, recolector.getDocumento());
            ps.setString(2, recolector.getCredencial());
            ps.setString(3, recolector.getNombre());
            ps.setString(4, recolector.getApellido());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Error al insertar el recolector: " + e.getMessage());
            return false;
        }
    }
}