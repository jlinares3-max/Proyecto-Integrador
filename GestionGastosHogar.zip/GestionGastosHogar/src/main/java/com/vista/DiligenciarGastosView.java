package com.vista;

import com.conexion.ConexionOracle;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class DiligenciarGastosView extends JFrame {

    private long idHogar;
    private int dia;
    private String documentoEncuestado = null;

    // Componentes del formulario
    private JLabel lblEncabezado;
    private JTextField txtNombreArticulo;
    private JTextField txtCantidad;
    private JComboBox<String> cmbUnidadMedida;
    private JComboBox<String> cmbFormaAdquisicion;
    private JComboBox<String> cmbLugarCompra;
    private JTextField txtValor;
    private JComboBox<String> cmbFrecuenciaCompra;
    private JRadioButton rbPersonal;
    private JRadioButton rbDelHogar;
    private ButtonGroup bgTipoGasto;

    // Mapeos para relacionar los nombres con los IDs reales de Oracle
    private Map<String, Long> mapaLugaresCompra;
    private Map<String, Long> mapaUnidadesMedida;
    private Map<String, Long> mapaFormasAdquisicion;
    private Map<String, Long> mapaFrecuencias;

    public DiligenciarGastosView(long idHogar, int dia) {
        this.idHogar = idHogar;
        this.dia = dia;
        this.mapaLugaresCompra = new HashMap<>();
        this.mapaUnidadesMedida = new HashMap<>();
        this.mapaFormasAdquisicion = new HashMap<>();
        this.mapaFrecuencias = new HashMap<>();

        initComponentsCustom();
        cargarDatosEncabezado();
        cargarLugaresCompraDesdeBD();
        cargarFormasAdquisicionDesdeBD();
        cargarFrecuenciasDesdeBD();
        cargarUnidadesMedidaDesdeBD();
    }

    private void initComponentsCustom() {
        setTitle("ENPH - Diligenciar Gastos Diarios [HOGAR " + idHogar + "]");
        setSize(700, 680);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panelPrincipal = new JPanel(new BorderLayout(15, 15));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(20, 25, 20, 25));
        panelPrincipal.setBackground(new Color(245, 245, 245));

        // Encabezado Superior
        lblEncabezado = new JLabel("HOGAR " + String.format("%03d", idHogar) + " - Cargando encuestado... (Día " + dia + " de 14)", SwingConstants.CENTER);
        lblEncabezado.setFont(new Font("Arial", Font.BOLD, 16));
        panelPrincipal.add(lblEncabezado, BorderLayout.NORTH);

        // Panel de Formulario
        JPanel panelForm = new JPanel(new GridLayout(8, 2, 10, 15));
        panelForm.setBackground(new Color(245, 245, 245));

        // 1. Nombre del artículo
        panelForm.add(new JLabel("Nombre del artículo:"));
        txtNombreArticulo = new JTextField();
        panelForm.add(txtNombreArticulo);

        // 2. Cantidad
        panelForm.add(new JLabel("Cantidad:"));
        txtCantidad = new JTextField();
        panelForm.add(txtCantidad);

        // 3. Unidad de medida
        panelForm.add(new JLabel("Unidad de medida:"));
        cmbUnidadMedida = new JComboBox<>();
        panelForm.add(cmbUnidadMedida);

        // 4. Forma de adquisición
        panelForm.add(new JLabel("Forma de adquisición:"));
        cmbFormaAdquisicion = new JComboBox<>();
        panelForm.add(cmbFormaAdquisicion);

        // 5. Lugar de compra
        panelForm.add(new JLabel("Lugar de compra:"));
        cmbLugarCompra = new JComboBox<>();
        panelForm.add(cmbLugarCompra);

        // 6. Valor pagado o estimado
        panelForm.add(new JLabel("Valor pagado o estimado ($):"));
        txtValor = new JTextField();
        panelForm.add(txtValor);

        // 7. Frecuencia de compra
        panelForm.add(new JLabel("Frecuencia de compra:"));
        cmbFrecuenciaCompra = new JComboBox<>();
        panelForm.add(cmbFrecuenciaCompra);

        // 8. Tipo de gasto
        panelForm.add(new JLabel("Tipo de gasto:"));
        JPanel panelRadio = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 0));
        panelRadio.setOpaque(false);
        rbPersonal = new JRadioButton("Personal");
        rbDelHogar = new JRadioButton("Del hogar");
        rbDelHogar.setSelected(true);
        bgTipoGasto = new ButtonGroup();
        bgTipoGasto.add(rbPersonal);
        bgTipoGasto.add(rbDelHogar);
        panelRadio.add(rbPersonal);
        panelRadio.add(rbDelHogar);
        panelForm.add(panelRadio);

        panelPrincipal.add(panelForm, BorderLayout.CENTER);

        // Panel de Botones inferiores
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        panelBotones.setOpaque(false);

        JButton btnAgregar = new JButton("+ Agregar artículo");
        JButton btnGuardar = new JButton("Guardar");
        btnGuardar.setBackground(new Color(40, 120, 220));
        btnGuardar.setForeground(Color.WHITE);
        btnGuardar.setFocusPainted(false);

        JButton btnFinalizarDia = new JButton("Finalizar día");
        btnFinalizarDia.setBackground(new Color(40, 160, 80));
        btnFinalizarDia.setForeground(Color.WHITE);
        btnFinalizarDia.setFocusPainted(false);

        // Eventos de los botones
        btnGuardar.addActionListener(e -> guardarGastoBD());
        btnAgregar.addActionListener(e -> guardarGastoBD());

        btnFinalizarDia.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(
                this, 
                "¿Estás seguro de finalizar el Día " + dia + " y regresar al Menú Principal?", 
                "Confirmar cierre de día", 
                JOptionPane.YES_NO_OPTION
            );

            if (confirm == JOptionPane.YES_OPTION) {
                JOptionPane.showMessageDialog(this, "¡Día " + dia + " finalizado exitosamente!");
                new MenuPrincipal().setVisible(true);
                dispose();
            }
        });

        panelBotones.add(btnAgregar);
        panelBotones.add(btnGuardar);
        panelBotones.add(btnFinalizarDia);

        panelPrincipal.add(panelBotones, BorderLayout.SOUTH);
        add(panelPrincipal);
    }

    // 1. Cargar el nombre y documento del encuestado según el idHogar
    private void cargarDatosEncabezado() {
        String sql = "SELECT DOCUMENTO, NOMBRE, APELLIDO FROM ENCUESTADO WHERE ID_HOGAR = ?";
        try (Connection con = ConexionOracle.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setLong(1, idHogar);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    documentoEncuestado = rs.getString("DOCUMENTO");
                    String nombreCompleto = rs.getString("NOMBRE") + " " + (rs.getString("APELLIDO") != null ? rs.getString("APELLIDO") : "");
                    lblEncabezado.setText("HOGAR " + String.format("%03d", idHogar) + " - Encuestado: " + nombreCompleto + " (Día " + dia + " de 14)");
                } else {
                    lblEncabezado.setText("HOGAR " + String.format("%03d", idHogar) + " (Día " + dia + " de 14)");
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al cargar encuestado: " + e.getMessage());
            lblEncabezado.setText("HOGAR " + String.format("%03d", idHogar) + " (Día " + dia + " de 14)");
        }
    }

    // 2. Cargar lugares de compra
    private void cargarLugaresCompraDesdeBD() {
        String sql = "SELECT ID_LUGAR, NOMBRE FROM LUGAR_COMPRA ORDER BY ID_LUGAR";
        cmbLugarCompra.removeAllItems();
        mapaLugaresCompra.clear();

        try (Connection con = ConexionOracle.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                long id = rs.getLong("ID_LUGAR");
                String nombre = rs.getString("NOMBRE");
                cmbLugarCompra.addItem(nombre);
                mapaLugaresCompra.put(nombre, id);
            }
        } catch (SQLException e) {
            System.err.println("Error al cargar lugares de compra: " + e.getMessage());
        }
    }

    // 3. Cargar formas de adquisición desde la BD
    private void cargarFormasAdquisicionDesdeBD() {
        String sql = "SELECT ID_FORMA, NOMBRE FROM FORMA_ADQUISICION ORDER BY ID_FORMA";
        cmbFormaAdquisicion.removeAllItems();
        mapaFormasAdquisicion.clear();

        try (Connection con = ConexionOracle.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                long id = rs.getLong("ID_FORMA");
                String nombre = rs.getString("NOMBRE");
                cmbFormaAdquisicion.addItem(nombre);
                mapaFormasAdquisicion.put(nombre, id);
            }
        } catch (SQLException e) {
            System.err.println("Error al cargar formas de adquisición: " + e.getMessage());
        }
    }

    // 4. Cargar frecuencias desde la BD
    private void cargarFrecuenciasDesdeBD() {
        String sql = "SELECT ID_FRECUENCIA, NOMBRE FROM FRECUENCIA_COMPRA ORDER BY ID_FRECUENCIA";
        cmbFrecuenciaCompra.removeAllItems();
        mapaFrecuencias.clear();

        try (Connection con = ConexionOracle.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                long id = rs.getLong("ID_FRECUENCIA");
                String nombre = rs.getString("NOMBRE");
                cmbFrecuenciaCompra.addItem(nombre);
                mapaFrecuencias.put(nombre, id);
            }
        } catch (SQLException e) {
            System.err.println("Error al cargar frecuencias: " + e.getMessage());
        }
    }

    // 5. Cargar unidades de medida desde la BD
    private void cargarUnidadesMedidaDesdeBD() {
        String sql = "SELECT ID_UNIDAD, NOMBRE FROM UNIDAD_MEDIDA ORDER BY ID_UNIDAD";
        cmbUnidadMedida.removeAllItems();
        mapaUnidadesMedida.clear();

        try (Connection con = ConexionOracle.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                long id = rs.getLong("ID_UNIDAD");
                String nombre = rs.getString("NOMBRE");
                cmbUnidadMedida.addItem(nombre);
                mapaUnidadesMedida.put(nombre, id);
            }
        } catch (SQLException e) {
            System.err.println("Error al cargar unidades de medida: " + e.getMessage());
        }
    }

    // 6. Inserción correcta del gasto en la tabla GASTOS de Oracle
    private void guardarGastoBD() {
        String articulo = txtNombreArticulo.getText().trim();
        String cantidadText = txtCantidad.getText().trim();
        String unidadSel = (String) cmbUnidadMedida.getSelectedItem();
        String formaSel = (String) cmbFormaAdquisicion.getSelectedItem();
        String lugarSel = (String) cmbLugarCompra.getSelectedItem();
        String valorText = txtValor.getText().trim();
        String frecuenciaSel = (String) cmbFrecuenciaCompra.getSelectedItem();
        
        // ID_TIPO: 1 = Gasto del hogar, 2 = Gasto personal (según los tipos en tu tabla TIPO_GASTO)
        long idTipo = rbPersonal.isSelected() ? 2 : 1;

        // Validaciones
        if (articulo.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor ingrese el nombre del artículo.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (cantidadText.isEmpty() || valorText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Debe ingresar la cantidad y el valor del artículo.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (documentoEncuestado == null || documentoEncuestado.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No se encontró un encuestado asociado a este hogar para registrar el gasto.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        double cantidad;
        double valorProducto;

        try {
            cantidad = Double.parseDouble(cantidadText);
            valorProducto = Double.parseDouble(valorText);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "La cantidad y el valor deben ser números válidos.", "Error de Formato", JOptionPane.ERROR_MESSAGE);
            return;
        }

        long idLugar = mapaLugaresCompra.getOrDefault(lugarSel, 1L);
        long idForma = mapaFormasAdquisicion.getOrDefault(formaSel, 1L);
        long idUnidad = mapaUnidadesMedida.getOrDefault(unidadSel, 1L);
        long idFrecuencia = mapaFrecuencias.getOrDefault(frecuenciaSel, 1L);

        // Sentencia SQL apuntando a la tabla GASTOS con la secuencia SEQ_GASTOS
        String sql = "INSERT INTO GASTOS (ID_GASTO, ARTICULO, CANTIDAD, VALOR_PRODUCTO, FECHA_REGISTRO, ESTADO, ID_HOGAR, ID_ENCUESTADO, ID_LUGAR, ID_FORMA, ID_TIPO, ID_UNIDAD, ID_FRECUENCIA) " +
                     "VALUES (SEQ_GASTOS.NEXTVAL, ?, ?, ?, SYSDATE, 'REGISTRADO', ?, ?, ?, ?, ?, ?, ?)";

        try (Connection con = ConexionOracle.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, articulo);
            ps.setDouble(2, cantidad);
            ps.setDouble(3, valorProducto);
            ps.setLong(4, idHogar);
            ps.setString(5, documentoEncuestado);
            ps.setLong(6, idLugar);
            ps.setLong(7, idForma);
            ps.setLong(8, idTipo);
            ps.setLong(9, idUnidad);
            ps.setLong(10, idFrecuencia);

            int filas = ps.executeUpdate();
            if (filas > 0) {
                JOptionPane.showMessageDialog(this, "¡Gasto registrado exitosamente en Oracle!\n" +
                        "Artículo: " + articulo + "\n" +
                        "Valor: $" + valorProducto, "Éxito", JOptionPane.INFORMATION_MESSAGE);

                txtNombreArticulo.setText("");
                txtCantidad.setText("");
                txtValor.setText("");
                txtNombreArticulo.requestFocus();
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al guardar el gasto en Oracle: " + e.getMessage(), "Error BD", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
}