package com.vista;

import com.conexion.ConexionOracle;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class DiligenciarGastosView extends JFrame {

    private long idHogar;
    private int dia;
    private String documentoEncuestado = null;

    private JLabel lblEncabezado;
    private JTextField txtNombreArticulo;
    private JTextField txtCantidad;
    private JComboBox<String> cmbUnidadMedida;
    private JComboBox<String> cmbFormaAdquisicion;
    private JComboBox<String> cmbLugarCompra;
    private JTextField txtValor;
    private JComboBox<String> cmbFrecuenciaCompra;
    private JRadioButton rbPersonal;
    private JRadioButton rbDelHogar;
    private ButtonGroup bgTipoGasto;

    private Map<String, Long> mapaLugaresCompra;
    private Map<String, Long> mapaUnidadesMedida;
    private Map<String, Long> mapaFormasAdquisicion;
    private Map<String, Long> mapaFrecuencias;

    public DiligenciarGastosView(long idHogar) {
        this.idHogar = idHogar;
        this.mapaLugaresCompra = new HashMap<>();
        this.mapaUnidadesMedida = new HashMap<>();
        this.mapaFormasAdquisicion = new HashMap<>();
        this.mapaFrecuencias = new HashMap<>();

        // DETECTAR EL DÍA AUTOMÁTICAMENTE DESDE LA BASE DE DATOS
        this.dia = calcularDiaActualBD();

        initComponentsCustom();
        cargarDatosEncabezado();
        cargarLugaresCompraDesdeBD();
        cargarFormasAdquisicionDesdeBD();
        cargarFrecuenciasDesdeBD();
        cargarUnidadesMedidaDesdeBD();
    }

    private int calcularDiaActualBD() {
        String sql = "SELECT NVL(TRUNC(SYSDATE) - TRUNC(FECHA_PRIMERA_VISITA) + 1, 1) AS DIA_CALCULADO FROM HOGAR WHERE ID_HOGAR = ?";
        try (Connection con = ConexionOracle.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setLong(1, idHogar);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    int d = rs.getInt("DIA_CALCULADO");
                    if (d < 1) return 1;
                    if (d > 14) return 14;
                    return d;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al calcular el día automático: " + e.getMessage());
        }
        return 1;
    }

    private void initComponentsCustom() {
        setTitle("ENPH - Diligenciar Gastos Diarios [HOGAR " + idHogar + "]");
        setSize(700, 680);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panelPrincipal = new JPanel(new BorderLayout(15, 15));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(20, 25, 20, 25));
        panelPrincipal.setBackground(new Color(245, 245, 245));

        lblEncabezado = new JLabel("HOGAR " + String.format("%03d", idHogar) + " - Cargando encuestado... (Día " + dia + " de 14)", SwingConstants.CENTER);
        lblEncabezado.setFont(new Font("Arial", Font.BOLD, 16));
        panelPrincipal.add(lblEncabezado, BorderLayout.NORTH);

        JPanel panelForm = new JPanel(new GridLayout(8, 2, 10, 15));
        panelForm.setBackground(new Color(245, 245, 245));

        panelForm.add(new JLabel("Nombre del artículo:"));
        txtNombreArticulo = new JTextField();
        panelForm.add(txtNombreArticulo);

        panelForm.add(new JLabel("Cantidad:"));
        txtCantidad = new JTextField();
        panelForm.add(txtCantidad);

        panelForm.add(new JLabel("Unidad de medida:"));
        cmbUnidadMedida = new JComboBox<>();
        panelForm.add(cmbUnidadMedida);

        panelForm.add(new JLabel("Forma de adquisición:"));
        cmbFormaAdquisicion = new JComboBox<>();
        panelForm.add(cmbFormaAdquisicion);

        panelForm.add(new JLabel("Lugar de compra:"));
        cmbLugarCompra = new JComboBox<>();
        panelForm.add(cmbLugarCompra);

        panelForm.add(new JLabel("Valor pagado o estimado ($):"));
        txtValor = new JTextField();
        panelForm.add(txtValor);

        panelForm.add(new JLabel("Frecuencia de compra:"));
        cmbFrecuenciaCompra = new JComboBox<>();
        panelForm.add(cmbFrecuenciaCompra);

        panelForm.add(new JLabel("Tipo de gasto:"));
        JPanel panelRadio = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 0));
        panelRadio.setOpaque(false);
        rbPersonal = new JRadioButton("Personal");
        rbDelHogar = new JRadioButton("Del hogar");
        rbDelHogar.setSelected(true);
        bgTipoGasto = new ButtonGroup();
        bgTipoGasto.add(rbPersonal);
        bgTipoGasto.add(rbDelHogar);
        panelRadio.add(rbPersonal);
        panelRadio.add(rbDelHogar);
        panelForm.add(panelRadio);

        panelPrincipal.add(panelForm, BorderLayout.CENTER);

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        panelBotones.setOpaque(false);

        JButton btnAgregar = new JButton("+ Agregar artículo");
        JButton btnGuardar = new JButton("Guardar");
        btnGuardar.setBackground(new Color(40, 120, 220));
        btnGuardar.setForeground(Color.WHITE);
        btnGuardar.setFocusPainted(false);

        JButton btnFinalizarDia = new JButton("Finalizar día");
        btnFinalizarDia.setBackground(new Color(40, 160, 80));
        btnFinalizarDia.setForeground(Color.WHITE);
        btnFinalizarDia.setFocusPainted(false);

        btnGuardar.addActionListener(e -> guardarGastoBD());
        btnAgregar.addActionListener(e -> guardarGastoBD());

        btnFinalizarDia.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(
                this, 
                "¿Estás seguro de finalizar el Día " + dia + " y regresar al Menú Principal?", 
                "Confirmar cierre de día", 
                JOptionPane.YES_NO_OPTION
            );

            if (confirm == JOptionPane.YES_OPTION) {
                JOptionPane.showMessageDialog(this, "¡Día " + dia + " finalizado exitosamente!");
                new MenuPrincipal().setVisible(true);
                dispose();
            }
        });

        panelBotones.add(btnAgregar);
        panelBotones.add(btnGuardar);
        panelBotones.add(btnFinalizarDia);

        panelPrincipal.add(panelBotones, BorderLayout.SOUTH);
        add(panelPrincipal);
    }

    private void cargarDatosEncabezado() {
        String sql = "SELECT DOCUMENTO, NOMBRE, APELLIDO FROM ENCUESTADO WHERE ID_HOGAR = ?";
        try (Connection con = ConexionOracle.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setLong(1, idHogar);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    documentoEncuestado = rs.getString("DOCUMENTO");
                    String nombreCompleto = rs.getString("NOMBRE") + " " + (rs.getString("APELLIDO") != null ? rs.getString("APELLIDO") : "");
                    lblEncabezado.setText("HOGAR " + String.format("%03d", idHogar) + " - Encuestado: " + nombreCompleto + " (Día " + dia + " de 14)");
                } else {
                    lblEncabezado.setText("HOGAR " + String.format("%03d", idHogar) + " (Día " + dia + " de 14)");
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al cargar encuestado: " + e.getMessage());
        }
    }

    private void cargarLugaresCompraDesdeBD() {
        String sql = "SELECT ID_LUGAR, NOMBRE FROM LUGAR_COMPRA ORDER BY ID_LUGAR";
        cmbLugarCompra.removeAllItems();
        mapaLugaresCompra.clear();

        try (Connection con = ConexionOracle.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                long id = rs.getLong("ID_LUGAR");
                String nombre = rs.getString("NOMBRE");
                cmbLugarCompra.addItem(nombre);
                mapaLugaresCompra.put(nombre, id);
            }
        } catch (SQLException e) {
            System.err.println("Error al cargar lugares de compra: " + e.getMessage());
        }
    }

    private void cargarFormasAdquisicionDesdeBD() {
        String sql = "SELECT ID_FORMA, NOMBRE FROM FORMA_ADQUISICION ORDER BY ID_FORMA";
        cmbFormaAdquisicion.removeAllItems();
        mapaFormasAdquisicion.clear();

        try (Connection con = ConexionOracle.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                long id = rs.getLong("ID_FORMA");
                String nombre = rs.getString("NOMBRE");
                cmbFormaAdquisicion.addItem(nombre);
                mapaFormasAdquisicion.put(nombre, id);
            }
        } catch (SQLException e) {
            System.err.println("Error al cargar formas de adquisición: " + e.getMessage());
        }
    }

    private void cargarFrecuenciasDesdeBD() {
        String sql = "SELECT ID_FRECUENCIA, NOMBRE FROM FRECUENCIA_COMPRA ORDER BY ID_FRECUENCIA";
        cmbFrecuenciaCompra.removeAllItems();
        mapaFrecuencias.clear();

        try (Connection con = ConexionOracle.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                long id = rs.getLong("ID_FRECUENCIA");
                String nombre = rs.getString("NOMBRE");
                cmbFrecuenciaCompra.addItem(nombre);
                mapaFrecuencias.put(nombre, id);
            }
        } catch (SQLException e) {
            System.err.println("Error al cargar frecuencias: " + e.getMessage());
        }
    }

    private void cargarUnidadesMedidaDesdeBD() {
        String sql = "SELECT ID_UNIDAD, NOMBRE FROM UNIDAD_MEDIDA ORDER BY ID_UNIDAD";
        cmbUnidadMedida.removeAllItems();
        mapaUnidadesMedida.clear();

        try (Connection con = ConexionOracle.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                long id = rs.getLong("ID_UNIDAD");
                String nombre = rs.getString("NOMBRE");
                cmbUnidadMedida.addItem(nombre);
                mapaUnidadesMedida.put(nombre, id);
            }
        } catch (SQLException e) {
            System.err.println("Error al cargar unidades de medida: " + e.getMessage());
        }
    }

    private void guardarGastoBD() {
        String articulo = txtNombreArticulo.getText().trim();
        String cantidadText = txtCantidad.getText().trim();
        String unidadSel = (String) cmbUnidadMedida.getSelectedItem();
        String formaSel = (String) cmbFormaAdquisicion.getSelectedItem();
        String lugarSel = (String) cmbLugarCompra.getSelectedItem();
        String valorText = txtValor.getText().trim();
        String frecuenciaSel = (String) cmbFrecuenciaCompra.getSelectedItem();
        
        long idTipo = rbPersonal.isSelected() ? 2 : 1;

        if (articulo.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor ingrese el nombre del artículo.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (cantidadText.isEmpty() || valorText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Debe ingresar la cantidad y el valor del artículo.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (documentoEncuestado == null || documentoEncuestado.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No se encontró un encuestado asociado a este hogar para registrar el gasto.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        double cantidad;
        double valorProducto;

        try {
            cantidad = Double.parseDouble(cantidadText);
            valorProducto = Double.parseDouble(valorText);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "La cantidad y el valor deben ser números válidos.", "Error de Formato", JOptionPane.ERROR_MESSAGE);
            return;
        }

        long idLugar = mapaLugaresCompra.getOrDefault(lugarSel, 1L);
        long idForma = mapaFormasAdquisicion.getOrDefault(formaSel, 1L);
        long idUnidad = mapaUnidadesMedida.getOrDefault(unidadSel, 1L);
        long idFrecuencia = mapaFrecuencias.getOrDefault(frecuenciaSel, 1L);

        String sql = "INSERT INTO GASTOS (ID_GASTO, ARTICULO, CANTIDAD, VALOR_PRODUCTO, FECHA_REGISTRO, ESTADO, ID_HOGAR, ID_ENCUESTADO, ID_LUGAR, ID_FORMA, ID_TIPO, ID_UNIDAD, ID_FRECUENCIA) " +
                     "VALUES (SEQ_GASTOS.NEXTVAL, ?, ?, ?, SYSDATE, 'REGISTRADO', ?, ?, ?, ?, ?, ?, ?)";

        try (Connection con = ConexionOracle.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, articulo);
            ps.setDouble(2, cantidad);
            ps.setDouble(3, valorProducto);
            ps.setLong(4, idHogar);
            ps.setString(5, documentoEncuestado);
            ps.setLong(6, idLugar);
            ps.setLong(7, idForma);
            ps.setLong(8, idTipo);
            ps.setLong(9, idUnidad);
            ps.setLong(10, idFrecuencia);

            int filas = ps.executeUpdate();
            if (filas > 0) {
                JOptionPane.showMessageDialog(this, "¡Gasto registrado exitosamente en Oracle!\n" +
                        "Artículo: " + articulo + "\n" +
                        "Valor: $" + valorProducto, "Éxito", JOptionPane.INFORMATION_MESSAGE);

                txtNombreArticulo.setText("");
                txtCantidad.setText("");
                txtValor.setText("");
                txtNombreArticulo.requestFocus();
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al guardar el gasto en Oracle: " + e.getMessage(), "Error BD", JOptionPane.ERROR_MESSAGE);
        }
    }
}