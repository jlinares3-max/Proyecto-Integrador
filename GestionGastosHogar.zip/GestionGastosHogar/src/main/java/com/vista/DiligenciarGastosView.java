package com.vista;

import com.conexion.ConexionOracle;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class DiligenciarGastosView extends JFrame {

    private long idHogar;
    private int dia;

    // Componentes del formulario
    private JLabel lblEncabezado;
    private JTextField txtNombreArticulo;
    private JTextField txtCantidad;
    private JComboBox<String> cmbUnidadMedida;
    private JComboBox<String> cmbFormaAdquisicion;
    private JComboBox<String> cmbLugarCompra; // Desplegable de lugares de compra
    private JTextField txtValor;
    private JComboBox<String> cmbFrecuenciaCompra;
    private JRadioButton rbPersonal;
    private JRadioButton rbDelHogar;
    private ButtonGroup bgTipoGasto;

    // Mapeo para relacionar los nombres con los IDs reales de Oracle
    private Map<String, Long> mapaLugaresCompra;

    public DiligenciarGastosView(long idHogar, int dia) {
        this.idHogar = idHogar;
        this.dia = dia;
        this.mapaLugaresCompra = new HashMap<>();

        initComponentsCustom();
        cargarDatosEncabezado();
        cargarLugaresCompraDesdeBD();
        cargarFormasAdquisicion();
        cargarFrecuencias();
        cargarUnidadesMedida();
    }

    private void initComponentsCustom() {
        setTitle("ENPH - Diligenciar Gastos Diarios [HOGAR " + idHogar + "]");
        setSize(700, 680);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panelPrincipal = new JPanel(new BorderLayout(15, 15));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(20, 25, 20, 25));
        panelPrincipal.setBackground(new Color(245, 245, 245));

        // Encabezado Superior
        lblEncabezado = new JLabel("HOGAR " + String.format("%03d", idHogar) + " - Cargando encuestado... (Día " + dia + " de 14)", SwingConstants.CENTER);
        lblEncabezado.setFont(new Font("Arial", Font.BOLD, 16));
        panelPrincipal.add(lblEncabezado, BorderLayout.NORTH);

        // Panel de Formulario
        JPanel panelForm = new JPanel(new GridLayout(8, 2, 10, 15));
        panelForm.setBackground(new Color(245, 245, 245));

        // 1. Nombre del artículo
        panelForm.add(new JLabel("Nombre del artículo:"));
        txtNombreArticulo = new JTextField();
        panelForm.add(txtNombreArticulo);

        // 2. Cantidad
        panelForm.add(new JLabel("Cantidad:"));
        txtCantidad = new JTextField();
        panelForm.add(txtCantidad);

        // 3. Unidad de medida
        panelForm.add(new JLabel("Unidad de medida:"));
        cmbUnidadMedida = new JComboBox<>();
        panelForm.add(cmbUnidadMedida);

        // 4. Forma de adquisición
        panelForm.add(new JLabel("Forma de adquisición:"));
        cmbFormaAdquisicion = new JComboBox<>();
        panelForm.add(cmbFormaAdquisicion);

        // 5. Lugar de compra (Lista desplegable)
        panelForm.add(new JLabel("Lugar de compra:"));
        cmbLugarCompra = new JComboBox<>();
        panelForm.add(cmbLugarCompra);

        // 6. Valor pagado o estimado
        panelForm.add(new JLabel("Valor pagado o estimado ($):"));
        txtValor = new JTextField();
        panelForm.add(txtValor);

        // 7. Frecuencia de compra
        panelForm.add(new JLabel("Frecuencia de compra:"));
        cmbFrecuenciaCompra = new JComboBox<>();
        panelForm.add(cmbFrecuenciaCompra);

        // 8. Tipo de gasto
        panelForm.add(new JLabel("Tipo de gasto:"));
        JPanel panelRadio = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 0));
        panelRadio.setOpaque(false);
        rbPersonal = new JRadioButton("Personal");
        rbDelHogar = new JRadioButton("Del hogar");
        rbDelHogar.setSelected(true);
        bgTipoGasto = new ButtonGroup();
        bgTipoGasto.add(rbPersonal);
        bgTipoGasto.add(rbDelHogar);
        panelRadio.add(rbPersonal);
        panelRadio.add(rbDelHogar);
        panelForm.add(panelRadio);

        panelPrincipal.add(panelForm, BorderLayout.CENTER);

        // Panel de Botones inferiores
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        panelBotones.setOpaque(false);

        JButton btnAgregar = new JButton("+ Agregar artículo");
        JButton btnGuardar = new JButton("Guardar");
        btnGuardar.setBackground(new Color(40, 120, 220));
        btnGuardar.setForeground(Color.WHITE);
        btnGuardar.setFocusPainted(false);

        JButton btnFinalizarDia = new JButton("Finalizar día");
        btnFinalizarDia.setBackground(new Color(40, 160, 80));
        btnFinalizarDia.setForeground(Color.WHITE);
        btnFinalizarDia.setFocusPainted(false);

        // Eventos de los botones
        btnGuardar.addActionListener(e -> guardarGastoBD());
        btnAgregar.addActionListener(e -> guardarGastoBD());

        btnFinalizarDia.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(
                this, 
                "¿Estás seguro de finalizar el Día " + dia + " y regresar al Menú Principal?", 
                "Confirmar cierre de día", 
                JOptionPane.YES_NO_OPTION
            );

            if (confirm == JOptionPane.YES_OPTION) {
                JOptionPane.showMessageDialog(this, "¡Día " + dia + " finalizado exitosamente!");
                new MenuPrincipal().setVisible(true);
                dispose();
            }
        });

        panelBotones.add(btnAgregar);
        panelBotones.add(btnGuardar);
        panelBotones.add(btnFinalizarDia);

        panelPrincipal.add(panelBotones, BorderLayout.SOUTH);
        add(panelPrincipal);
    }

    // 1. Cargar el nombre del encuestado según el idHogar
    private void cargarDatosEncabezado() {
        String sql = "SELECT E.NOMBRE, E.APELLIDO FROM ENCUESTADO E WHERE E.ID_HOGAR = ?";
        try (Connection con = ConexionOracle.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setLong(1, idHogar);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    String nombreCompleto = rs.getString("NOMBRE") + " " + (rs.getString("APELLIDO") != null ? rs.getString("APELLIDO") : "");
                    lblEncabezado.setText("HOGAR " + String.format("%03d", idHogar) + " - Encuestado: " + nombreCompleto + " (Día " + dia + " de 14)");
                } else {
                    lblEncabezado.setText("HOGAR " + String.format("%03d", idHogar) + " (Día " + dia + " de 14)");
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al cargar encuestado: " + e.getMessage());
            lblEncabezado.setText("HOGAR " + String.format("%03d", idHogar) + " (Día " + dia + " de 14)");
        }
    }

    // 2. Cargar lugares de compra desde la tabla LUGAR_COMPRA de Oracle
    private void cargarLugaresCompraDesdeBD() {
        String sql = "SELECT ID_LUGAR, NOMBRE FROM LUGAR_COMPRA ORDER BY ID_LUGAR";
        cmbLugarCompra.removeAllItems();
        mapaLugaresCompra.clear();

        try (Connection con = ConexionOracle.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                long idLugar = rs.getLong("ID_LUGAR");
                String nombre = rs.getString("NOMBRE");

                cmbLugarCompra.addItem(nombre);
                mapaLugaresCompra.put(nombre, idLugar);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar lugares de compra desde Oracle: " + e.getMessage(), "Error BD", JOptionPane.ERROR_MESSAGE);
        }
    }

    // 3. Formas de adquisición
    private void cargarFormasAdquisicion() {
        cmbFormaAdquisicion.addItem("Compra directa");
        cmbFormaAdquisicion.addItem("Intercambio / Trueque");
        cmbFormaAdquisicion.addItem("Producido por el hogar");
        cmbFormaAdquisicion.addItem("Regalo / Donación");
    }

    // 4. Frecuencias
    private void cargarFrecuencias() {
        cmbFrecuenciaCompra.addItem("Diario");
        cmbFrecuenciaCompra.addItem("Semanal");
        cmbFrecuenciaCompra.addItem("Quincenal");
        cmbFrecuenciaCompra.addItem("Mensual");
        cmbFrecuenciaCompra.addItem("Ocasional");
    }

    // 5. Unidades de medida
    private void cargarUnidadesMedida() {
        cmbUnidadMedida.addItem("Unidad");
        cmbUnidadMedida.addItem("Kilogramo (kg)");
        cmbUnidadMedida.addItem("Gramo (g)");
        cmbUnidadMedida.addItem("Litro (L)");
        cmbUnidadMedida.addItem("Paquete");
        cmbUnidadMedida.addItem("Lata");
    }

    // 6. Inserción del gasto en Oracle (Manejando posibles variaciones de nombre de tabla)
    private void guardarGastoBD() {
        String articulo = txtNombreArticulo.getText().trim();
        String cantidadText = txtCantidad.getText().trim();
        String unidad = (String) cmbUnidadMedida.getSelectedItem();
        String forma = (String) cmbFormaAdquisicion.getSelectedItem();
        String lugarSel = (String) cmbLugarCompra.getSelectedItem();
        String valorText = txtValor.getText().trim();
        String frecuencia = (String) cmbFrecuenciaCompra.getSelectedItem();
        String tipoGasto = rbPersonal.isSelected() ? "Personal" : "Del hogar";

        // Validaciones
        if (articulo.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor ingrese el nombre del artículo.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (cantidadText.isEmpty() || valorText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Debe ingresar la cantidad y el valor del artículo.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (lugarSel == null || !mapaLugaresCompra.containsKey(lugarSel)) {
            JOptionPane.showMessageDialog(this, "Seleccione un lugar de compra válido.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        double cantidad;
        double valor;

        try {
            cantidad = Double.parseDouble(cantidadText);
            valor = Double.parseDouble(valorText);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "La cantidad y el valor deben ser números válidos.", "Error de Formato", JOptionPane.ERROR_MESSAGE);
            return;
        }

        long idLugarReal = mapaLugaresCompra.get(lugarSel);

        // Lista de tablas posibles
        String[] tablasPosibles = {"GASTO", "GASTO_DIARIO", "ARTICULO_GASTO", "GASTOS_DIARIOS"};
        boolean guardadoExitoso = false;
        String errorFinal = "";

        for (String nombreTabla : tablasPosibles) {
            String sql = "INSERT INTO " + nombreTabla + " (NOMBRE_ARTICULO, CANTIDAD, UNIDAD_MEDIDA, FORMA_ADQUISICION, ID_LUGAR, VALOR, FRECUENCIA, TIPO_GASTO, DIA, ID_HOGAR) " +
                         "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            try (Connection con = ConexionOracle.obtenerConexion();
                 PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setString(1, articulo);
                ps.setDouble(2, cantidad);
                ps.setString(3, unidad);
                ps.setString(4, forma);
                ps.setLong(5, idLugarReal);
                ps.setDouble(6, valor);
                ps.setString(7, frecuencia);
                ps.setString(8, tipoGasto);
                ps.setInt(9, dia);
                ps.setLong(10, idHogar);

                int filas = ps.executeUpdate();
                if (filas > 0) {
                    guardadoExitoso = true;
                    break;
                }

            } catch (SQLException e) {
                errorFinal = e.getMessage();
            }
        }

        if (guardadoExitoso) {
            JOptionPane.showMessageDialog(this, "¡Gasto registrado exitosamente en Oracle!\n" +
                    "Artículo: " + articulo + "\n" +
                    "Valor: $" + valor, "Éxito", JOptionPane.INFORMATION_MESSAGE);

            txtNombreArticulo.setText("");
            txtCantidad.setText("");
            txtValor.setText("");
            txtNombreArticulo.requestFocus();
        } else {
            JOptionPane.showMessageDialog(this, "Error al guardar el gasto en Oracle: " + errorFinal, "Error BD", JOptionPane.ERROR_MESSAGE);
        }
    }
}