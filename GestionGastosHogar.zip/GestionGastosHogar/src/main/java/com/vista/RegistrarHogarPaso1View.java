package com.vista;

import javax.swing.*;
import java.awt.*;

public class RegistrarHogarPaso1View extends JFrame {
    private long idVivienda;
    private String direccionVivienda;
    private JTextField txtTotalPersonas, txtCedula, txtNombre, txtApellido, txtCorreo;

    public RegistrarHogarPaso1View(long idVivienda, String direccionVivienda) {
        this.idVivienda = idVivienda;
        this.direccionVivienda = direccionVivienda;
        initComponentsCustom();
    }

    private void initComponentsCustom() {
        setTitle("ENPH - Registrar hogar y encuestado (Paso 1 de 2)");
        setSize(750, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panelPrincipal = new JPanel(new BorderLayout(10, 15));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));
        panelPrincipal.setBackground(new Color(245, 245, 245));

        // Botón volver
        JButton btnVolver = new JButton("← Volver al detalle de la vivienda");
        btnVolver.setBorderPainted(false);
        btnVolver.setContentAreaFilled(false);
        btnVolver.setForeground(Color.GRAY);
        btnVolver.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnVolver.addActionListener(e -> {
            new DetalleViviendaView(idVivienda, direccionVivienda).setVisible(true);
            dispose();
        });

        JPanel panelTop = new JPanel(new BorderLayout(5, 5));
        panelTop.setOpaque(false);
        panelTop.add(btnVolver, BorderLayout.NORTH);

        JLabel lblTitulo = new JLabel("Registrar hogar y encuestado — Paso 1 de 2");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 22));
        JLabel lblSub = new JLabel("Ingresa los datos del hogar y de la persona que responderá la encuesta.");
        lblSub.setForeground(Color.GRAY);

        JPanel pHeadText = new JPanel(new GridLayout(2, 1, 2, 2));
        pHeadText.setOpaque(false);
        pHeadText.add(lblTitulo);
        pHeadText.add(lblSub);
        panelTop.add(pHeadText, BorderLayout.SOUTH);
        panelPrincipal.add(panelTop, BorderLayout.NORTH);

        // Contenedor central desplazable (Scroll)
        JPanel panelCentro = new JPanel();
        panelCentro.setLayout(new BoxLayout(panelCentro, BoxLayout.Y_AXIS));
        panelCentro.setOpaque(false);

        // Tarjeta informativa de la vivienda
        JPanel cardVivienda = new JPanel(new BorderLayout());
        cardVivienda.setBackground(new Color(230, 240, 255));
        cardVivienda.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(180, 210, 245)),
                BorderFactory.createEmptyBorder(12, 15, 12, 15)
        ));
        JLabel lblInfoViv = new JLabel("<html><b>Vivienda seleccionada: " + direccionVivienda + "</b><br><font color='gray'>ID Vivienda: " + idVivienda + "</font></html>");
        cardVivienda.add(lblInfoViv, BorderLayout.CENTER);
        cardVivienda.setMaximumSize(new Dimension(Integer.MAX_VALUE, 60));
        panelCentro.add(cardVivienda);
        panelCentro.add(Box.createVerticalStrut(15));

        // Tarjeta Datos del Hogar
        JPanel cardHogar = new JPanel(new BorderLayout());
        cardHogar.setBackground(Color.WHITE);
        cardHogar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 220, 220)),
                BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        JLabel lblHogarTit = new JLabel("Datos del hogar");
        lblHogarTit.setFont(new Font("Arial", Font.BOLD, 14));
        
        JPanel pFormHogar = new JPanel(new GridLayout(1, 2, 10, 10));
        pFormHogar.setBackground(Color.WHITE);
        pFormHogar.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
        txtTotalPersonas = new JTextField();
        txtTotalPersonas.setBorder(BorderFactory.createTitledBorder("Total de personas *"));
        pFormHogar.add(txtTotalPersonas);
        
        cardHogar.add(lblHogarTit, BorderLayout.NORTH);
        cardHogar.add(pFormHogar, BorderLayout.CENTER);
        cardHogar.setMaximumSize(new Dimension(Integer.MAX_VALUE, 110));
        panelCentro.add(cardHogar);
        panelCentro.add(Box.createVerticalStrut(15));

        // Tarjeta Encuestado
        JPanel cardEnc = new JPanel(new BorderLayout());
        cardEnc.setBackground(Color.WHITE);
        cardEnc.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 220, 220)),
                BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        JLabel lblEncTit = new JLabel("Encuestado");
        lblEncTit.setFont(new Font("Arial", Font.BOLD, 14));

        JPanel pFormEnc = new JPanel(new GridLayout(2, 2, 12, 12));
        pFormEnc.setBackground(Color.WHITE);
        pFormEnc.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));

        txtCedula = new JTextField();
        txtCedula.setBorder(BorderFactory.createTitledBorder("Cédula *"));
        txtNombre = new JTextField();
        txtNombre.setBorder(BorderFactory.createTitledBorder("Nombre *"));
        txtApellido = new JTextField();
        txtApellido.setBorder(BorderFactory.createTitledBorder("Apellido *"));
        txtCorreo = new JTextField();
        txtCorreo.setBorder(BorderFactory.createTitledBorder("Correo (opcional)"));

        pFormEnc.add(txtCedula);
        pFormEnc.add(txtNombre);
        pFormEnc.add(txtApellido);
        pFormEnc.add(txtCorreo);

        cardEnc.add(lblEncTit, BorderLayout.NORTH);
        cardEnc.add(pFormEnc, BorderLayout.CENTER);
        cardEnc.setMaximumSize(new Dimension(Integer.MAX_VALUE, 180));
        panelCentro.add(cardEnc);

        JScrollPane scroll = new JScrollPane(panelCentro);
        scroll.setBorder(null);
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);
        panelPrincipal.add(scroll, BorderLayout.CENTER);

        // Panel Inferior con Botones
        JPanel panelBotones = new JPanel(new BorderLayout());
        panelBotones.setOpaque(false);
        panelBotones.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));

        JButton btnCancelar = new JButton("Cancelar");
        JButton btnSiguiente = new JButton("Siguiente →");
        btnSiguiente.setBackground(new Color(20, 60, 140));
        btnSiguiente.setForeground(Color.WHITE);
        btnSiguiente.setFocusPainted(false);

        btnCancelar.addActionListener(e -> {
            new DetalleViviendaView(idVivienda, direccionVivienda).setVisible(true);
            dispose();
        });

        btnSiguiente.addActionListener(e -> {
            String totP = txtTotalPersonas.getText();
            String doc = txtCedula.getText();
            String nom = txtNombre.getText();
            String ape = txtApellido.getText();
            String corr = txtCorreo.getText();

            if (totP.isEmpty() || doc.isEmpty() || nom.isEmpty() || ape.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Por favor complete todos los campos obligatorios (*).", "Campos requeridos", JOptionPane.WARNING_MESSAGE);
                return;
            }

            try {
                Long.parseLong(totP);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "El total de personas debe ser un número válido.", "Error de formato", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Pasar al Paso 2
            new RegistrarHogarPaso2View(idVivienda, direccionVivienda, totP, doc, nom, ape, corr).setVisible(true);
            dispose();
        });

        panelBotones.add(btnCancelar, BorderLayout.WEST);
        panelBotones.add(btnSiguiente, BorderLayout.EAST);
        panelPrincipal.add(panelBotones, BorderLayout.SOUTH);

        add(panelPrincipal);
    }
}