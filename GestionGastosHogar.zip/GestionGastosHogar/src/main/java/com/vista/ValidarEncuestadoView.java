package com.vista;

import com.conexion.ConexionOracle;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ValidarEncuestadoView extends JFrame {

    private JTextField txtCedula;

    public ValidarEncuestadoView() {
        initComponentsCustom();
    }

    private void initComponentsCustom() {
        setTitle("ENPH - Validar Encuestado");
        setSize(450, 380);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panelPrincipal = new JPanel(new BorderLayout(15, 15));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(25, 30, 25, 30));
        panelPrincipal.setBackground(new Color(245, 245, 245));

        // Enlace superior Volver
        JButton btnVolver = new JButton("← Volver al Menú Principal");
        btnVolver.setBorderPainted(false);
        btnVolver.setContentAreaFilled(false);
        btnVolver.setForeground(Color.GRAY);
        btnVolver.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnVolver.addActionListener(e -> {
            new MenuPrincipal().setVisible(true);
            dispose();
        });

        JPanel panelTop = new JPanel(new BorderLayout());
        panelTop.setOpaque(false);
        panelTop.add(btnVolver, BorderLayout.NORTH);

        JLabel lblTitulo = new JLabel("Ingreso Encuestado", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 20));
        panelTop.add(lblTitulo, BorderLayout.SOUTH);

        panelPrincipal.add(panelTop, BorderLayout.NORTH);

        // Tarjeta central blanca
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 220, 220)),
                BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));

        JLabel lblInstruccion = new JLabel("Ingresa tu número de documento:");
        lblInstruccion.setAlignmentX(Component.CENTER_ALIGNMENT);
        card.add(lblInstruccion);
        card.add(Box.createVerticalStrut(15));

        txtCedula = new JTextField();
        txtCedula.setMaximumSize(new Dimension(300, 35));
        txtCedula.setBorder(BorderFactory.createTitledBorder("Cédula / Documento *"));
        txtCedula.setAlignmentX(Component.CENTER_ALIGNMENT);
        card.add(txtCedula);
        card.add(Box.createVerticalStrut(20));

        JButton btnIngresar = new JButton("Ingresar");
        btnIngresar.setBackground(new Color(20, 60, 130));
        btnIngresar.setForeground(Color.WHITE);
        btnIngresar.setFocusPainted(false);
        btnIngresar.setAlignmentX(Component.CENTER_ALIGNMENT);

        btnIngresar.addActionListener(e -> {
            String cedula = txtCedula.getText().trim();
            if (cedula.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Ingresa tu cédula.", "Advertencia", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // Consultar en Oracle el idHogar asociado a este número de documento
            long idHogarEncontrado = obtenerIdHogarPorCedula(cedula);

            if (idHogarEncontrado != -1) {
                // Abre DiligenciarGastosView enviando el ID del hogar encontrado y el Día 1
                new DiligenciarGastosView(idHogarEncontrado, 1).setVisible(true);
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "La cédula ingresada no se encuentra registrada como encuestado en ningún hogar.", "Documento No Encontrado", JOptionPane.ERROR_MESSAGE);
            }
        });

        card.add(btnIngresar);

        panelPrincipal.add(card, BorderLayout.CENTER);
        add(panelPrincipal);
    }

    // Método que consulta Oracle para obtener el ID del hogar
    private long obtenerIdHogarPorCedula(String cedula) {
        String sql = "SELECT ID_HOGAR FROM ENCUESTADO WHERE DOCUMENTO = ?";
        try (Connection con = ConexionOracle.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, cedula);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getLong("ID_HOGAR");
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al buscar hogar por cédula: " + e.getMessage());
        }
        return -1; // Retorna -1 si la cédula no existe en la BD
    }
}