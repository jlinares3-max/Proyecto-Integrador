package com.vista;

import com.dao.HogarDAO;
import com.dao.EncuestadoDAO;
import com.modelo.Hogar;
import com.modelo.Encuestado;

import javax.swing.*;
import java.awt.*;
import java.util.Date;

public class RegistrarHogarView extends JFrame {

    private JTextField txtIdHogar, txtNumHogar, txtDireccion, txtIdVivienda;
    private JTextField txtDocEncuestado, txtNombreEnc, txtApellidoEnc;

    public RegistrarHogarView() {
        initComponentsCustom();
    }

    private void initComponentsCustom() {
        setTitle("ENPH - Registrar Hogar y Encuestado");
        setSize(550, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panelPrincipal = new JPanel();
        panelPrincipal.setLayout(new BoxLayout(panelPrincipal, BoxLayout.Y_AXIS));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JLabel lblTitulo = new JLabel("Registrar Hogar y Encuestado");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 16));
        lblTitulo.setAlignmentX(Component.LEFT_ALIGNMENT);
        panelPrincipal.add(lblTitulo);
        panelPrincipal.add(Box.createVerticalStrut(15));

        JPanel panelForm = new JPanel(new GridLayout(7, 2, 10, 10));

        panelForm.add(new JLabel("ID Hogar (Numérico):"));
        txtIdHogar = new JTextField();
        panelForm.add(txtIdHogar);

        panelForm.add(new JLabel("Número de Hogar:"));
        txtNumHogar = new JTextField();
        panelForm.add(txtNumHogar);

        panelForm.add(new JLabel("Dirección:"));
        txtDireccion = new JTextField();
        panelForm.add(txtDireccion);

        panelForm.add(new JLabel("ID Vivienda:"));
        txtIdVivienda = new JTextField();
        panelForm.add(txtIdVivienda);

        panelForm.add(new JLabel("Documento Encuestado:"));
        txtDocEncuestado = new JTextField();
        panelForm.add(txtDocEncuestado);

        panelForm.add(new JLabel("Nombre Encuestado:"));
        txtNombreEnc = new JTextField();
        panelForm.add(txtNombreEnc);

        panelForm.add(new JLabel("Apellido Encuestado:"));
        txtApellidoEnc = new JTextField();
        panelForm.add(txtApellidoEnc);

        panelPrincipal.add(panelForm);
        panelPrincipal.add(Box.createVerticalStrut(20));

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnGuardar = new JButton("Guardar Registro");
        JButton btnVolver = new JButton("Volver");

        btnGuardar.setBackground(new Color(40, 120, 220));
        btnGuardar.setForeground(Color.WHITE);

        btnGuardar.addActionListener(e -> guardarHogarYEncuestadoBD());
        btnVolver.addActionListener(e -> dispose());

        panelBotones.add(btnVolver);
        panelBotones.add(btnGuardar);

        panelPrincipal.add(panelBotones);
        add(panelPrincipal);
    }

    private void guardarHogarYEncuestadoBD() {
        try {
            if (txtIdHogar.getText().isEmpty() || txtDocEncuestado.getText().isEmpty()) {
                JOptionPane.showMessageDialog(this, "El ID del Hogar y el Documento del Encuestado son obligatorios.", "Advertencia", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // 1. Guardar Hogar en Oracle (según la nueva estructura)
            Hogar hogar = new Hogar();
            hogar.setIdHogar(Long.parseLong(txtIdHogar.getText()));
            hogar.setTotalPersonas(4); // O puedes crear un JTextField para capturar el total de personas
            hogar.setIdVivienda(Long.parseLong(txtIdVivienda.getText().isEmpty() ? "1" : txtIdVivienda.getText()));
            hogar.setDocumentoRecolector(1093433066L); // Documento del recolector asignado
            // Reemplaza hogar.setFechaAsignacion(...) por esto:
long unDiaEnMillis = 24 * 60 * 60 * 1000L;
java.util.Date fechaInicio = new java.util.Date();
hogar.setFechaInicio(fechaInicio);
hogar.setFechaPrimeraVisita(new java.util.Date(fechaInicio.getTime() + unDiaEnMillis)); // +1 día
hogar.setFechaFin(new java.util.Date(fechaInicio.getTime() + (13 * unDiaEnMillis))); // +13 días

            HogarDAO hogarDAO = new HogarDAO();
            boolean exitoHogar = hogarDAO.insertarHogar(hogar);

            // 2. Guardar Encuestado asociado en Oracle con los nuevos campos
            Encuestado enc = new Encuestado();
            enc.setDocumento(txtDocEncuestado.getText());
            enc.setNombre(txtNombreEnc.getText());
            enc.setApellido(txtApellidoEnc.getText());
            enc.setParentesco("Jefe/a de hogar"); 
            enc.setTelefono(3001234567L); 
            enc.setIdHogar(hogar.getIdHogar());
            enc.setIdDispositivo(1L); 
            enc.setFechaEntrega(new Date());

            EncuestadoDAO encDAO = new EncuestadoDAO();
            boolean exitoEnc = encDAO.insertarEncuestado(enc);

            if (exitoHogar && exitoEnc) {
                JOptionPane.showMessageDialog(this, "¡Hogar y encuestado guardados exitosamente en Oracle!");
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Error al registrar en la base de datos. Revisa la consola.", "Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Por favor verifica que los campos numéricos tengan valores válidos.", "Error de formato", JOptionPane.ERROR_MESSAGE);
        }
    }
}