package com.vista;

import com.conexion.ConexionOracle;
import com.dao.HogarDAO;
import com.dao.EncuestadoDAO;
import com.modelo.Hogar;
import com.modelo.Encuestado;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class RegistrarHogarPaso2View extends JFrame {
    private long idVivienda;
    private String direccionVivienda;
    private String totalPersonas, docEncuestado, nombre, apellido, correo;
    private JComboBox<String> cmbRecolector;
    private JTextField txtFechaCita;
    private Map<String, Long> mapaRecolectores;

    public RegistrarHogarPaso2View(long idVivienda, String direccionVivienda, String totalPersonas, String docEncuestado, String nombre, String apellido, String correo) {
        this.idVivienda = idVivienda;
        this.direccionVivienda = direccionVivienda;
        this.totalPersonas = totalPersonas;
        this.docEncuestado = docEncuestado;
        this.nombre = nombre;
        this.apellido = apellido;
        this.correo = correo;
        this.mapaRecolectores = new HashMap<>();
        initComponentsCustom();
        cargarRecolectoresDesdeBD();
    }

    private void initComponentsCustom() {
        setTitle("ENPH - Registrar hogar y encuestado — Paso 2 de 2");
        setSize(700, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panelPrincipal = new JPanel(new BorderLayout(10, 15));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));
        panelPrincipal.setBackground(new Color(245, 245, 245));

        // Enlace superior Volver
        JButton btnVolver = new JButton("← Volver");
        btnVolver.setBorderPainted(false);
        btnVolver.setContentAreaFilled(false);
        btnVolver.setForeground(Color.GRAY);
        btnVolver.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnVolver.addActionListener(e -> {
            new RegistrarHogarPaso1View(idVivienda, direccionVivienda).setVisible(true);
            dispose();
        });

        JPanel panelTop = new JPanel(new BorderLayout(5, 5));
        panelTop.setOpaque(false);
        panelTop.add(btnVolver, BorderLayout.NORTH);

        JLabel lblTitulo = new JLabel("Registrar hogar y encuestado — Paso 2 de 2");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 22));
        JLabel lblSub = new JLabel("Asigna el hogar a un recolector y define la fecha de la primera cita.");
        lblSub.setForeground(Color.GRAY);

        JPanel pHeadText = new JPanel(new GridLayout(2, 1, 2, 2));
        pHeadText.setOpaque(false);
        pHeadText.add(lblTitulo);
        pHeadText.add(lblSub);
        panelTop.add(pHeadText, BorderLayout.SOUTH);
        panelPrincipal.add(panelTop, BorderLayout.NORTH);

        // Tarjeta central blanca
        JPanel panelCard = new JPanel(new BorderLayout());
        panelCard.setBackground(Color.WHITE);
        panelCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 220, 220)),
                BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));

        JLabel lblSeccion = new JLabel("Asignar Hogar");
        lblSeccion.setFont(new Font("Arial", Font.BOLD, 14));

        JPanel panelForm = new JPanel(new GridLayout(1, 2, 15, 15));
        panelForm.setBackground(Color.WHITE);
        panelForm.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));

        cmbRecolector = new JComboBox<>();
        cmbRecolector.setBorder(BorderFactory.createTitledBorder("Recolectores disponibles *"));

        txtFechaCita = new JTextField("2026-10-15");
        txtFechaCita.setBorder(BorderFactory.createTitledBorder("Fecha de la primera cita (yyyy-MM-dd) *"));

        panelForm.add(cmbRecolector);
        panelForm.add(txtFechaCita);

        panelCard.add(lblSeccion, BorderLayout.NORTH);
        panelCard.add(panelForm, BorderLayout.CENTER);
        panelPrincipal.add(panelCard, BorderLayout.CENTER);

        // Botones inferiores (Anterior a la izquierda, Asignar Hogar a la derecha)
        JPanel panelBotones = new JPanel(new BorderLayout());
        panelBotones.setOpaque(false);

        JButton btnAnterior = new JButton("← Anterior");
        JButton btnAsignar = new JButton("Asignar Hogar");

        btnAsignar.setBackground(new Color(20, 60, 140));
        btnAsignar.setForeground(Color.WHITE);
        btnAsignar.setFocusPainted(false);

        btnAnterior.addActionListener(e -> {
            new RegistrarHogarPaso1View(idVivienda, direccionVivienda).setVisible(true);
            dispose();
        });

        btnAsignar.addActionListener(e -> guardarEnBaseDeDatos());

        panelBotones.add(btnAnterior, BorderLayout.WEST);
        panelBotones.add(btnAsignar, BorderLayout.EAST);
        panelPrincipal.add(panelBotones, BorderLayout.SOUTH);

        add(panelPrincipal);
    }

    private void cargarRecolectoresDesdeBD() {
        String sql = "SELECT DOCUMENTO, NOMBRE, APELLIDO FROM RECOLECTOR ORDER BY NOMBRE";
        try (Connection con = ConexionOracle.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            cmbRecolector.addItem("- Seleccione Recolector -");
            while (rs.next()) {
                long documento = rs.getLong("DOCUMENTO");
                String nombreCompleto = rs.getString("NOMBRE") + " " + rs.getString("APELLIDO") + " (" + documento + ")";
                
                cmbRecolector.addItem(nombreCompleto);
                mapaRecolectores.put(nombreCompleto, documento);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar recolectores: " + e.getMessage(), "Error BD", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void guardarEnBaseDeDatos() {
        try {
            String recolectorSeleccionado = (String) cmbRecolector.getSelectedItem();
            if (recolectorSeleccionado == null || recolectorSeleccionado.startsWith("-")) {
                JOptionPane.showMessageDialog(this, "Debe seleccionar un recolector disponible.", "Advertencia", JOptionPane.WARNING_MESSAGE);
                return;
            }

            String strFecha = txtFechaCita.getText().trim();
            if (strFecha.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Debe ingresar la fecha de la primera cita.", "Advertencia", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // Validar y convertir la fecha ingresada
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date fechaSeleccionada;
            try {
                fechaSeleccionada = sdf.parse(strFecha);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "El formato de fecha debe ser aaaa-mm-dd (Ej. 2026-10-15).", "Error de formato", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Cálculo requerido por las restricciones de la base de datos (HOG_PRI_CK y HOG_FIN_CK)
            long unDiaEnMillis = 24 * 60 * 60 * 1000L;
            Date fechaInicio = fechaSeleccionada; 
            Date fechaPrimeraVisita = new Date(fechaInicio.getTime() + unDiaEnMillis); 
            Date fechaFin = new Date(fechaInicio.getTime() + (13 * unDiaEnMillis)); 

            long docRecolectorReal = mapaRecolectores.get(recolectorSeleccionado);
            long idHogarGenerado = System.currentTimeMillis() / 1000;

            // 1. Guardar Hogar en Oracle cumpliendo los campos obligatorios y reglas CHECK
            Hogar hogar = new Hogar();
            hogar.setIdHogar(idHogarGenerado);
            hogar.setTotalPersonas(Long.parseLong(totalPersonas));
            hogar.setIdVivienda(idVivienda);
            hogar.setDocumentoRecolector(docRecolectorReal);
            hogar.setFechaInicio(fechaInicio);
            hogar.setFechaFin(fechaFin);
            hogar.setFechaPrimeraVisita(fechaPrimeraVisita);

            HogarDAO hogarDAO = new HogarDAO();
            boolean exitoHogar = hogarDAO.insertarHogar(hogar);

            // 2. Asegurar que el dispositivo 1 exista automáticamente en la BD
            verificarYCrearDispositivoPorDefecto(1L, docRecolectorReal);

            // 3. Guardar Encuestado asociado en Oracle
            Encuestado enc = new Encuestado();
            enc.setDocumento(docEncuestado);
            enc.setNombre(nombre);
            enc.setApellido(apellido);
            enc.setParentesco("Jefe/a de hogar");
            enc.setTelefono(3001234567L);
            enc.setCorreo(correo);
            enc.setIdHogar(idHogarGenerado);
            enc.setIdDispositivo(1L);
            enc.setFechaEntrega(new Date());

            EncuestadoDAO encDAO = new EncuestadoDAO();
            boolean exitoEnc = encDAO.insertarEncuestado(enc);

            if (exitoHogar && exitoEnc) {
                // Abrir la pantalla de éxito con todos los datos correspondientes
                new HogarRegistradoExitoView(
                    idVivienda, 
                    direccionVivienda, 
                    idHogarGenerado, 
                    totalPersonas, 
                    nombre + " " + apellido, 
                    recolectorSeleccionado, 
                    fechaPrimeraVisita
                ).setVisible(true);
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Error al registrar en la base de datos. Revisa la consola.", "Error BD", JOptionPane.ERROR_MESSAGE);
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error de excepción: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Método auxiliar para verificar si el dispositivo existe; si no, lo crea automáticamente
    private void verificarYCrearDispositivoPorDefecto(long idDispositivo, long documentoRecolector) {
        String sqlCheck = "SELECT COUNT(*) FROM DISPOSITIVO WHERE ID_DISPOSITIVO = ?";
        String sqlInsert = "INSERT INTO DISPOSITIVO (ID_DISPOSITIVO, ESTADO, DOCUMENTO_RECOLECTOR) VALUES (?, 'ACTIVO', ?)";

        try (Connection con = ConexionOracle.obtenerConexion();
             PreparedStatement psCheck = con.prepareStatement(sqlCheck)) {
            
            psCheck.setLong(1, idDispositivo);
            try (ResultSet rs = psCheck.executeQuery()) {
                if (rs.next() && rs.getInt(1) == 0) {
                    try (PreparedStatement psInsert = con.prepareStatement(sqlInsert)) {
                        psInsert.setLong(1, idDispositivo);
                        psInsert.setLong(2, documentoRecolector);
                        psInsert.executeUpdate();
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al verificar/crear dispositivo automático: " + e.getMessage());
        }
    }
}