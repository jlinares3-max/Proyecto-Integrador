package com.vista;

import com.conexion.ConexionOracle;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class SeguimientoGastosDiariosView extends JFrame {

    private long idHogar;
    private int dia;
    private long documentoRecolector;
    private String nombreRecolector;

    private JLabel lblHogar;
    private JLabel lblRecolectorFecha;
    private JLabel lblDireccion;
    private JLabel lblBarrio;
    private JLabel lblTotalPersonas;
    private JLabel lblEncuestado;
    private JLabel lblTelefono;

    private JTable tablaGastos;
    private DefaultTableModel modeloTabla;
    
    // Lista para almacenar los ID_GASTO reales de cada fila
    private List<Long> listaIdGastos;

    public SeguimientoGastosDiariosView(long idHogar, long documentoRecolector, String nombreRecolector) {
        this.idHogar = idHogar;
        this.documentoRecolector = documentoRecolector;
        this.nombreRecolector = nombreRecolector;
        this.listaIdGastos = new ArrayList<>();
        
        // Calcular el día automáticamente desde la BD
        this.dia = calcularDiaActualBD();

        initComponentsCustom();
        cargarInformacionHogar();
        cargarGastosRealesDesdeBD();
    }

    private int calcularDiaActualBD() {
        String sql = "SELECT NVL(TRUNC(SYSDATE) - TRUNC(FECHA_PRIMERA_VISITA) + 1, 1) AS DIA_CALCULADO FROM HOGAR WHERE ID_HOGAR = ?";
        try (Connection con = ConexionOracle.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setLong(1, idHogar);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    int d = rs.getInt("DIA_CALCULADO");
                    if (d < 1) return 1;
                    if (d > 14) return 14;
                    return d;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al calcular el día automático: " + e.getMessage());
        }
        return 1;
    }

    private void initComponentsCustom() {
        setTitle("ENPH - Seguimiento Gastos Diarios");
        setSize(980, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panelPrincipal = new JPanel(new BorderLayout(15, 15));
        panelPrincipal.setBackground(new Color(245, 245, 245));
        panelPrincipal.setBorder(new EmptyBorder(20, 30, 20, 30));

        JPanel panelTop = new JPanel(new BorderLayout(5, 5));
        panelTop.setOpaque(false);

        JLabel lblLogo = new JLabel("ENPH");
        lblLogo.setFont(new Font("Arial", Font.BOLD, 18));
        JLabel lblCuadernillo = new JLabel("Cuadernillo 2 urbano");
        lblCuadernillo.setForeground(Color.GRAY);

        JPanel panelHeaderTop = new JPanel(new BorderLayout());
        panelHeaderTop.setOpaque(false);
        panelHeaderTop.add(lblLogo, BorderLayout.WEST);
        panelHeaderTop.add(lblCuadernillo, BorderLayout.EAST);
        panelTop.add(panelHeaderTop, BorderLayout.NORTH);

        JButton btnVolver = new JButton("← Volver a citas pendientes");
        btnVolver.setBorderPainted(false);
        btnVolver.setContentAreaFilled(false);
        btnVolver.setForeground(Color.GRAY);
        btnVolver.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnVolver.setHorizontalAlignment(SwingConstants.LEFT);
        btnVolver.addActionListener(e -> {
            new CitasPendientesView(documentoRecolector, nombreRecolector).setVisible(true);
            dispose();
        });

        JLabel lblTitulo = new JLabel("Seguimiento Gastos Diarios");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 24));

        JPanel panelTitulos = new JPanel();
        panelTitulos.setLayout(new BoxLayout(panelTitulos, BoxLayout.Y_AXIS));
        panelTitulos.setOpaque(false);
        panelTitulos.add(btnVolver);
        panelTitulos.add(Box.createVerticalStrut(10));
        panelTitulos.add(lblTitulo);

        panelTop.add(panelTitulos, BorderLayout.SOUTH);
        panelPrincipal.add(panelTop, BorderLayout.NORTH);

        JPanel panelCentro = new JPanel();
        panelCentro.setLayout(new BoxLayout(panelCentro, BoxLayout.Y_AXIS));
        panelCentro.setOpaque(false);

        JPanel cardInfo = new JPanel(new BorderLayout(10, 10));
        cardInfo.setBackground(Color.WHITE);
        cardInfo.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 220, 220)),
                new EmptyBorder(15, 20, 15, 20)
        ));
        cardInfo.setMaximumSize(new Dimension(920, 110));

        JPanel pCardRow1 = new JPanel(new BorderLayout());
        pCardRow1.setOpaque(false);

        lblHogar = new JLabel("HOGAR " + String.format("%03d", idHogar));
        lblHogar.setFont(new Font("Arial", Font.BOLD, 18));

        JPanel pBadges = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        pBadges.setOpaque(false);

        lblRecolectorFecha = new JLabel("Recolector: " + nombreRecolector + "  2026-10-19");
        lblRecolectorFecha.setForeground(Color.GRAY);
        lblRecolectorFecha.setFont(new Font("Arial", Font.PLAIN, 12));

        JLabel lblActivo = new JLabel("Activo", SwingConstants.CENTER);
        lblActivo.setFont(new Font("Arial", Font.BOLD, 11));
        lblActivo.setForeground(new Color(40, 140, 70));
        lblActivo.setBackground(new Color(210, 240, 220));
        lblActivo.setOpaque(true);
        lblActivo.setBorder(new EmptyBorder(3, 10, 3, 10));

        JLabel lblDiaBadge = new JLabel("Día (" + dia + ") de 14", SwingConstants.CENTER);
        lblDiaBadge.setFont(new Font("Arial", Font.BOLD, 11));
        lblDiaBadge.setForeground(Color.GRAY);
        lblDiaBadge.setBackground(new Color(235, 235, 235));
        lblDiaBadge.setOpaque(true);
        lblDiaBadge.setBorder(new EmptyBorder(3, 10, 3, 10));

        pBadges.add(lblRecolectorFecha);
        pBadges.add(lblActivo);
        pBadges.add(lblDiaBadge);

        pCardRow1.add(lblHogar, BorderLayout.WEST);
        pCardRow1.add(pBadges, BorderLayout.EAST);

        JPanel pCardRow2 = new JPanel(new GridLayout(1, 5, 10, 0));
        pCardRow2.setOpaque(false);

        lblDireccion = crearLabelValor("Cargando...");
        lblBarrio = crearLabelValor("Cargando...");
        lblTotalPersonas = crearLabelValor("-");
        lblEncuestado = crearLabelValor("Cargando...");
        lblTelefono = crearLabelValor("-");

        pCardRow2.add(crearColumnaInfo("Dirección", lblDireccion));
        pCardRow2.add(crearColumnaInfo("Barrio", lblBarrio));
        pCardRow2.add(crearColumnaInfo("Total de personas", lblTotalPersonas));
        pCardRow2.add(crearColumnaInfo("Encuestado", lblEncuestado));
        pCardRow2.add(crearColumnaInfo("Teléfono", lblTelefono));

        cardInfo.add(pCardRow1, BorderLayout.NORTH);
        cardInfo.add(pCardRow2, BorderLayout.SOUTH);

        panelCentro.add(cardInfo);
        panelCentro.add(Box.createVerticalStrut(15));

        JPanel cardTabla = new JPanel(new BorderLayout(10, 10));
        cardTabla.setBackground(Color.WHITE);
        cardTabla.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 220, 220)),
                new EmptyBorder(15, 20, 15, 20)
        ));

        JPanel panelTituloTabla = new JPanel(new BorderLayout());
        panelTituloTabla.setOpaque(false);
        JLabel lblSubGastos = new JLabel("Gastos diligenciados — Día (" + dia + ")");
        lblSubGastos.setFont(new Font("Arial", Font.BOLD, 14));
        panelTituloTabla.add(lblSubGastos, BorderLayout.WEST);

        JButton btnIrDiligenciar = new JButton("+ Registrar nuevo gasto");
        btnIrDiligenciar.setBackground(new Color(40, 120, 220));
        btnIrDiligenciar.setForeground(Color.WHITE);
        btnIrDiligenciar.setFont(new Font("Arial", Font.BOLD, 11));
        btnIrDiligenciar.setFocusPainted(false);
        btnIrDiligenciar.addActionListener(e -> {
            new DiligenciarGastosView(idHogar).setVisible(true);
            dispose();
        });
        panelTituloTabla.add(btnIrDiligenciar, BorderLayout.EAST);

        cardTabla.add(panelTituloTabla, BorderLayout.NORTH);

        String[] columnas = {"Nombre", "Cantidad", "Unidad de medida", "Equivalencia", "Forma de adquisición", "Lugar de compra", "Frecuencia", "Valor", "Acción"};
        modeloTabla = new DefaultTableModel(null, columnas) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 8; 
            }
        };

        tablaGastos = new JTable(modeloTabla);
        tablaGastos.setRowHeight(38);
        tablaGastos.setFont(new Font("Arial", Font.PLAIN, 12));
        tablaGastos.getTableHeader().setFont(new Font("Arial", Font.BOLD, 12));
        tablaGastos.getTableHeader().setBackground(new Color(245, 247, 250));
        tablaGastos.setShowGrid(false);
        tablaGastos.setIntercellSpacing(new Dimension(0, 0));

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.LEFT);
        for (int i = 0; i < tablaGastos.getColumnCount() - 1; i++) {
            tablaGastos.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }

        tablaGastos.getColumnModel().getColumn(8).setCellRenderer((table, value, isSelected, hasFocus, row, column) -> {
            JButton btn = new JButton("Corregir");
            btn.setFont(new Font("Arial", Font.BOLD, 11));
            btn.setForeground(new Color(20, 60, 140));
            btn.setBackground(new Color(230, 240, 255));
            btn.setBorderPainted(false);
            btn.setFocusPainted(false);
            return btn;
        });

        // Evento clic para abrir la vista completa de edición al presionar "Corregir"
        tablaGastos.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int fila = tablaGastos.rowAtPoint(e.getPoint());
                int columna = tablaGastos.columnAtPoint(e.getPoint());

                if (columna == 8 && fila >= 0 && fila < listaIdGastos.size()) {
                    long idGastoAModificar = listaIdGastos.get(fila);
                    abrirFormularioCorreccion(idGastoAModificar);
                }
            }
        });

        JScrollPane scrollTabla = new JScrollPane(tablaGastos);
        scrollTabla.setBorder(BorderFactory.createLineBorder(new Color(235, 235, 235)));
        cardTabla.add(scrollTabla, BorderLayout.CENTER);

        panelCentro.add(cardTabla);
        panelPrincipal.add(panelCentro, BorderLayout.CENTER);

        JPanel panelSur = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelSur.setOpaque(false);

        JButton btnConfirmar = new JButton("Confirmar verificación");
        btnConfirmar.setBackground(new Color(20, 60, 140));
        btnConfirmar.setForeground(Color.WHITE);
        btnConfirmar.setFont(new Font("Arial", Font.BOLD, 13));
        btnConfirmar.setFocusPainted(false);
        btnConfirmar.setPreferredSize(new Dimension(190, 38));

        btnConfirmar.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "¡Verificación del Día (" + dia + ") confirmada exitosamente!", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            new CitasPendientesView(documentoRecolector, nombreRecolector).setVisible(true);
            dispose();
        });

        panelSur.add(btnConfirmar);
        panelPrincipal.add(panelSur, BorderLayout.SOUTH);

        add(panelPrincipal);
    }

    // Abre una ventana idéntica al formulario de diligenciamiento cargada con los datos del gasto a corregir
    private void abrirFormularioCorreccion(long idGasto) {
        JDialog dialog = new JDialog(this, "ENPH - Corregir Gasto [ID: " + idGasto + "]", true);
        dialog.setSize(650, 600);
        dialog.setLocationRelativeTo(this);

        JPanel panelForm = new JPanel(new GridLayout(8, 2, 10, 15));
        panelForm.setBorder(BorderFactory.createEmptyBorder(20, 25, 20, 25));
        panelForm.setBackground(new Color(245, 245, 245));

        JTextField txtNombreArticulo = new JTextField();
        JTextField txtCantidad = new JTextField();
        JComboBox<String> cmbUnidadMedida = new JComboBox<>();
        JComboBox<String> cmbFormaAdquisicion = new JComboBox<>();
        JComboBox<String> cmbLugarCompra = new JComboBox<>();
        JTextField txtValor = new JTextField();
        JComboBox<String> cmbFrecuenciaCompra = new JComboBox<>();
        JRadioButton rbPersonal = new JRadioButton("Personal");
        JRadioButton rbDelHogar = new JRadioButton("Del hogar");
        ButtonGroup bgTipoGasto = new ButtonGroup();
        bgTipoGasto.add(rbPersonal);
        bgTipoGasto.add(rbDelHogar);

        Map<String, Long> mapaLugares = new HashMap<>();
        Map<String, Long> mapaUnidades = new HashMap<>();
        Map<String, Long> mapaFormas = new HashMap<>();
        Map<String, Long> mapaFrecuencias = new HashMap<>();

        // Cargar Combos desde BD
        cargarComboBD("SELECT ID_LUGAR, NOMBRE FROM LUGAR_COMPRA", cmbLugarCompra, mapaLugares);
        cargarComboBD("SELECT ID_UNIDAD, NOMBRE FROM UNIDAD_MEDIDA", cmbUnidadMedida, mapaUnidades);
        cargarComboBD("SELECT ID_FORMA, NOMBRE FROM FORMA_ADQUISICION", cmbFormaAdquisicion, mapaFormas);
        cargarComboBD("SELECT ID_FRECUENCIA, NOMBRE FROM FRECUENCIA_COMPRA", cmbFrecuenciaCompra, mapaFrecuencias);

        // Cargar los datos actuales del gasto en los campos
        String sql = "SELECT * FROM GASTOS WHERE ID_GASTO = ?";
        try (Connection con = ConexionOracle.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setLong(1, idGasto);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    txtNombreArticulo.setText(rs.getString("ARTICULO"));
                    txtCantidad.setText(String.valueOf(rs.getDouble("CANTIDAD")));
                    txtValor.setText(String.valueOf(rs.getDouble("VALOR_PRODUCTO")));
                    
                    long idTipo = rs.getLong("ID_TIPO");
                    if (idTipo == 2) rbPersonal.setSelected(true);
                    else rbDelHogar.setSelected(true);

                    seleccionarComboPorId(cmbLugarCompra, mapaLugares, rs.getLong("ID_LUGAR"));
                    seleccionarComboPorId(cmbUnidadMedida, mapaUnidades, rs.getLong("ID_UNIDAD"));
                    seleccionarComboPorId(cmbFormaAdquisicion, mapaFormas, rs.getLong("ID_FORMA"));
                    seleccionarComboPorId(cmbFrecuenciaCompra, mapaFrecuencias, rs.getLong("ID_FRECUENCIA"));
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(dialog, "Error al cargar datos del gasto: " + e.getMessage(), "Error BD", JOptionPane.ERROR_MESSAGE);
            return;
        }

        panelForm.add(new JLabel("Nombre del artículo:"));
        panelForm.add(txtNombreArticulo);
        panelForm.add(new JLabel("Cantidad:"));
        panelForm.add(txtCantidad);
        panelForm.add(new JLabel("Unidad de medida:"));
        panelForm.add(cmbUnidadMedida);
        panelForm.add(new JLabel("Forma de adquisición:"));
        panelForm.add(cmbFormaAdquisicion);
        panelForm.add(new JLabel("Lugar de compra:"));
        panelForm.add(cmbLugarCompra);
        panelForm.add(new JLabel("Valor pagado o estimado ($):"));
        panelForm.add(txtValor);
        panelForm.add(new JLabel("Frecuencia de compra:"));
        panelForm.add(cmbFrecuenciaCompra);
        
        panelForm.add(new JLabel("Tipo de gasto:"));
        JPanel pRadio = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 0));
        pRadio.setOpaque(false);
        pRadio.add(rbPersonal);
        pRadio.add(rbDelHogar);
        panelForm.add(pRadio);

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        JButton btnGuardar = new JButton("Guardar Cambios");
        btnGuardar.setBackground(new Color(40, 120, 220));
        btnGuardar.setForeground(Color.WHITE);

        btnGuardar.addActionListener(e -> {
            String articulo = txtNombreArticulo.getText().trim();
            String cantStr = txtCantidad.getText().trim();
            String valStr = txtValor.getText().trim();

            if (articulo.isEmpty() || cantStr.isEmpty() || valStr.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "Por favor complete todos los campos obligatorios.", "Advertencia", JOptionPane.WARNING_MESSAGE);
                return;
            }

            try {
                double cantidad = Double.parseDouble(cantStr);
                double valor = Double.parseDouble(valStr);
                long idLugar = mapaLugares.get((String) cmbLugarCompra.getSelectedItem());
                long idUnidad = mapaUnidades.get((String) cmbUnidadMedida.getSelectedItem());
                long idForma = mapaFormas.get((String) cmbFormaAdquisicion.getSelectedItem());
                long idFrecuencia = mapaFrecuencias.get((String) cmbFrecuenciaCompra.getSelectedItem());
                long idTipo = rbPersonal.isSelected() ? 2 : 1;

                String sqlUpdate = "UPDATE GASTOS SET ARTICULO = ?, CANTIDAD = ?, VALOR_PRODUCTO = ?, ID_LUGAR = ?, ID_UNIDAD = ?, ID_FORMA = ?, ID_FRECUENCIA = ?, ID_TIPO = ?, ESTADO = 'CORREGIDO' WHERE ID_GASTO = ?";
                
                try (Connection con = ConexionOracle.obtenerConexion();
                     PreparedStatement ps = con.prepareStatement(sqlUpdate)) {
                    ps.setString(1, articulo);
                    ps.setDouble(2, cantidad);
                    ps.setDouble(3, valor);
                    ps.setLong(4, idLugar);
                    ps.setLong(5, idUnidad);
                    ps.setLong(6, idForma);
                    ps.setLong(7, idFrecuencia);
                    ps.setLong(8, idTipo);
                    ps.setLong(9, idGasto);

                    ps.executeUpdate();
                    JOptionPane.showMessageDialog(dialog, "¡Gasto corregido y actualizado con éxito!");
                    dialog.dispose();
                    cargarGastosRealesDesdeBD(); // Recargar la tabla principal
                }

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dialog, "La cantidad y el valor deben ser números válidos.", "Error de formato", JOptionPane.ERROR_MESSAGE);
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(dialog, "Error al actualizar en la base de datos: " + ex.getMessage(), "Error BD", JOptionPane.ERROR_MESSAGE);
            }
        });

        panelBotones.add(btnGuardar);

        dialog.add(panelForm, BorderLayout.CENTER);
        dialog.add(panelBotones, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }

    private void cargarComboBD(String sql, JComboBox<String> combo, Map<String, Long> mapa) {
        combo.removeAllItems();
        mapa.clear();
        try (Connection con = ConexionOracle.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                long id = rs.getLong(1);
                String nombre = rs.getString(2);
                combo.addItem(nombre);
                mapa.put(nombre, id);
            }
        } catch (SQLException e) {
            System.err.println("Error al cargar combo: " + e.getMessage());
        }
    }

    private void seleccionarComboPorId(JComboBox<String> combo, Map<String, Long> mapa, long idBuscado) {
        for (Map.Entry<String, Long> entry : mapa.entrySet()) {
            if (entry.getValue() == idBuscado) {
                combo.setSelectedItem(entry.getKey());
                break;
            }
        }
    }

    private JPanel crearColumnaInfo(String titulo, JLabel lblValor) {
        JPanel p = new JPanel(new GridLayout(2, 1, 0, 2));
        p.setOpaque(false);
        JLabel lblT = new JLabel(titulo);
        lblT.setFont(new Font("Arial", Font.PLAIN, 11));
        lblT.setForeground(Color.GRAY);
        p.add(lblT);
        p.add(lblValor);
        return p;
    }

    private JLabel crearLabelValor(String texto) {
        JLabel l = new JLabel(texto);
        l.setFont(new Font("Arial", Font.BOLD, 12));
        return l;
    }

    private void cargarInformacionHogar() {
        String sql = "SELECT V.DIRECCION, B.NOMBRE AS BARRIO_NOMBRE, H.TOTAL_PERSONAS, E.NOMBRE, E.APELLIDO, E.TELEFONO " +
                     "FROM HOGAR H " +
                     "JOIN VIVIENDA V ON H.ID_VIVIENDA = V.ID_VIVIENDA " +
                     "JOIN BARRIO B ON V.ID_BARRIO = B.ID_BARRIO " +
                     "LEFT JOIN ENCUESTADO E ON H.ID_HOGAR = E.ID_HOGAR " +
                     "WHERE H.ID_HOGAR = ?";

        try (Connection con = ConexionOracle.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setLong(1, idHogar);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    String dir = rs.getString("DIRECCION");
                    String barrio = rs.getString("BARRIO_NOMBRE");
                    long totalPer = rs.getLong("TOTAL_PERSONAS");
                    String nombre = rs.getString("NOMBRE");
                    String apellido = rs.getString("APELLIDO");
                    long tel = rs.getLong("TELEFONO");

                    lblDireccion.setText(dir != null ? dir : "N/A");
                    lblBarrio.setText(barrio != null ? barrio : "N/A");
                    lblTotalPersonas.setText(String.valueOf(totalPer > 0 ? totalPer : 1));
                    lblEncuestado.setText((nombre != null ? nombre : "") + " " + (apellido != null ? apellido : "Sin encuestado"));
                    lblTelefono.setText(tel != 0 ? String.valueOf(tel) : "N/A");
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al cargar datos del hogar: " + e.getMessage());
        }
    }

    private void cargarGastosRealesDesdeBD() {
        modeloTabla.setRowCount(0);
        listaIdGastos.clear();

        String sql = "SELECT G.ID_GASTO, G.ARTICULO, G.CANTIDAD, U.NOMBRE AS UNIDAD_MEDIDA, F.NOMBRE AS FORMA_ADQUISICION, " +
                     "L.NOMBRE AS LUGAR_COMPRA, FC.NOMBRE AS FRECUENCIA, G.VALOR_PRODUCTO " +
                     "FROM GASTOS G " +
                     "JOIN LUGAR_COMPRA L ON G.ID_LUGAR = L.ID_LUGAR " +
                     "JOIN UNIDAD_MEDIDA U ON G.ID_UNIDAD = U.ID_UNIDAD " +
                     "JOIN FORMA_ADQUISICION F ON G.ID_FORMA = F.ID_FORMA " +
                     "JOIN FRECUENCIA_COMPRA FC ON G.ID_FRECUENCIA = FC.ID_FRECUENCIA " +
                     "WHERE G.ID_HOGAR = ? " +
                     "ORDER BY G.ID_GASTO";

        NumberFormat formatoMoneda = NumberFormat.getCurrencyInstance(new Locale("es", "CO"));

        try (Connection con = ConexionOracle.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setLong(1, idHogar);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    long idGasto = rs.getLong("ID_GASTO");
                    String nombre = rs.getString("ARTICULO");
                    double cantidad = rs.getDouble("CANTIDAD");
                    String unidad = rs.getString("UNIDAD_MEDIDA");
                    String forma = rs.getString("FORMA_ADQUISICION");
                    String lugar = rs.getString("LUGAR_COMPRA");
                    String frecuencia = rs.getString("FRECUENCIA");
                    double valor = rs.getDouble("VALOR_PRODUCTO");

                    listaIdGastos.add(idGasto);

                    String cantidadStr = (cantidad % 1 == 0) ? String.valueOf((int) cantidad) : String.valueOf(cantidad);
                    String equivalenciaStr = cantidadStr + " " + (unidad != null ? unidad : "");
                    String valorFormateado = formatoMoneda.format(valor);

                    modeloTabla.addRow(new Object[]{
                        nombre,
                        cantidadStr,
                        unidad != null ? unidad : "-",
                        equivalenciaStr,
                        forma != null ? forma : "Compra",
                        lugar,
                        frecuencia != null ? frecuencia : "Diario",
                        valorFormateado,
                        "Corregir"
                    });
                }
            }

        } catch (SQLException e) {
            System.err.println("Error al cargar gastos desde la BD: " + e.getMessage());
        }
    }
}