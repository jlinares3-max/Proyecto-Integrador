package com.vista;

import com.conexion.ConexionOracle;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.NumberFormat;
import java.util.Locale;

public class SeguimientoGastosDiariosView extends JFrame {

    private long idHogar;
    private int dia;
    private long documentoRecolector;
    private String nombreRecolector;

    // Componentes de la tarjeta de información
    private JLabel lblHogar;
    private JLabel lblRecolectorFecha;
    private JLabel lblDireccion;
    private JLabel lblBarrio;
    private JLabel lblTotalPersonas;
    private JLabel lblEncuestado;
    private JLabel lblTelefono;

    // Tabla de gastos
    private JTable tablaGastos;
    private DefaultTableModel modeloTabla;

    public SeguimientoGastosDiariosView(long idHogar, int dia, long documentoRecolector, String nombreRecolector) {
        this.idHogar = idHogar;
        this.dia = dia;
        this.documentoRecolector = documentoRecolector;
        this.nombreRecolector = nombreRecolector;

        initComponentsCustom();
        cargarInformacionHogar();
        cargarGastosRealesDesdeBD();
    }

    private void initComponentsCustom() {
        setTitle("ENPH - Seguimiento Gastos Diarios");
        setSize(980, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panelPrincipal = new JPanel(new BorderLayout(15, 15));
        panelPrincipal.setBackground(new Color(245, 245, 245));
        panelPrincipal.setBorder(new EmptyBorder(20, 30, 20, 30));

        // --- ENCABEZADO SUPERIOR ---
        JPanel panelTop = new JPanel(new BorderLayout(5, 5));
        panelTop.setOpaque(false);

        JLabel lblLogo = new JLabel("ENPH");
        lblLogo.setFont(new Font("Arial", Font.BOLD, 18));
        JLabel lblCuadernillo = new JLabel("Cuadernillo 2 urbano");
        lblCuadernillo.setForeground(Color.GRAY);

        JPanel panelHeaderTop = new JPanel(new BorderLayout());
        panelHeaderTop.setOpaque(false);
        panelHeaderTop.add(lblLogo, BorderLayout.WEST);
        panelHeaderTop.add(lblCuadernillo, BorderLayout.EAST);
        panelTop.add(panelHeaderTop, BorderLayout.NORTH);

        JButton btnVolver = new JButton("← Volver a citas pendientes");
        btnVolver.setBorderPainted(false);
        btnVolver.setContentAreaFilled(false);
        btnVolver.setForeground(Color.GRAY);
        btnVolver.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnVolver.setHorizontalAlignment(SwingConstants.LEFT);
        btnVolver.addActionListener(e -> {
            new CitasPendientesView(documentoRecolector, nombreRecolector).setVisible(true);
            dispose();
        });

        JLabel lblTitulo = new JLabel("Seguimiento Gastos Diarios");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 24));

        JPanel panelTitulos = new JPanel();
        panelTitulos.setLayout(new BoxLayout(panelTitulos, BoxLayout.Y_AXIS));
        panelTitulos.setOpaque(false);
        panelTitulos.add(btnVolver);
        panelTitulos.add(Box.createVerticalStrut(10));
        panelTitulos.add(lblTitulo);

        panelTop.add(panelTitulos, BorderLayout.SOUTH);
        panelPrincipal.add(panelTop, BorderLayout.NORTH);

        // --- CONTENIDO CENTRAL ---
        JPanel panelCentro = new JPanel();
        panelCentro.setLayout(new BoxLayout(panelCentro, BoxLayout.Y_AXIS));
        panelCentro.setOpaque(false);

        // 1. Tarjeta resumen superior con información del hogar
        JPanel cardInfo = new JPanel(new BorderLayout(10, 10));
        cardInfo.setBackground(Color.WHITE);
        cardInfo.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 220, 220)),
                new EmptyBorder(15, 20, 15, 20)
        ));
        cardInfo.setMaximumSize(new Dimension(920, 110));

        JPanel pCardRow1 = new JPanel(new BorderLayout());
        pCardRow1.setOpaque(false);

        lblHogar = new JLabel("HOGAR " + String.format("%03d", idHogar));
        lblHogar.setFont(new Font("Arial", Font.BOLD, 18));

        JPanel pBadges = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        pBadges.setOpaque(false);

        lblRecolectorFecha = new JLabel("Recolector: " + nombreRecolector + "  2026-10-19");
        lblRecolectorFecha.setForeground(Color.GRAY);
        lblRecolectorFecha.setFont(new Font("Arial", Font.PLAIN, 12));

        JLabel lblActivo = new JLabel("Activo", SwingConstants.CENTER);
        lblActivo.setFont(new Font("Arial", Font.BOLD, 11));
        lblActivo.setForeground(new Color(40, 140, 70));
        lblActivo.setBackground(new Color(210, 240, 220));
        lblActivo.setOpaque(true);
        lblActivo.setBorder(new EmptyBorder(3, 10, 3, 10));

        JLabel lblDiaBadge = new JLabel("Día (" + dia + ") de 14", SwingConstants.CENTER);
        lblDiaBadge.setFont(new Font("Arial", Font.BOLD, 11));
        lblDiaBadge.setForeground(Color.GRAY);
        lblDiaBadge.setBackground(new Color(235, 235, 235));
        lblDiaBadge.setOpaque(true);
        lblDiaBadge.setBorder(new EmptyBorder(3, 10, 3, 10));

        pBadges.add(lblRecolectorFecha);
        pBadges.add(lblActivo);
        pBadges.add(lblDiaBadge);

        pCardRow1.add(lblHogar, BorderLayout.WEST);
        pCardRow1.add(pBadges, BorderLayout.EAST);

        JPanel pCardRow2 = new JPanel(new GridLayout(1, 5, 10, 0));
        pCardRow2.setOpaque(false);

        lblDireccion = crearLabelValor("Cargando...");
        lblBarrio = crearLabelValor("Cargando...");
        lblTotalPersonas = crearLabelValor("-");
        lblEncuestado = crearLabelValor("Cargando...");
        lblTelefono = crearLabelValor("-");

        pCardRow2.add(crearColumnaInfo("Dirección", lblDireccion));
        pCardRow2.add(crearColumnaInfo("Barrio", lblBarrio));
        pCardRow2.add(crearColumnaInfo("Total de personas", lblTotalPersonas));
        pCardRow2.add(crearColumnaInfo("Encuestado", lblEncuestado));
        pCardRow2.add(crearColumnaInfo("Teléfono", lblTelefono));

        cardInfo.add(pCardRow1, BorderLayout.NORTH);
        cardInfo.add(pCardRow2, BorderLayout.SOUTH);

        panelCentro.add(cardInfo);
        panelCentro.add(Box.createVerticalStrut(15));

        // 2. Tarjeta con la Tabla de Gastos Reales
        JPanel cardTabla = new JPanel(new BorderLayout(10, 10));
        cardTabla.setBackground(Color.WHITE);
        cardTabla.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 220, 220)),
                new EmptyBorder(15, 20, 15, 20)
        ));

        JPanel panelTituloTabla = new JPanel(new BorderLayout());
        panelTituloTabla.setOpaque(false);
        JLabel lblSubGastos = new JLabel("Gastos diligenciados — Día (" + dia + ")");
        lblSubGastos.setFont(new Font("Arial", Font.BOLD, 14));
        panelTituloTabla.add(lblSubGastos, BorderLayout.WEST);

        JButton btnIrDiligenciar = new JButton("+ Registrar nuevo gasto");
        btnIrDiligenciar.setBackground(new Color(40, 120, 220));
        btnIrDiligenciar.setForeground(Color.WHITE);
        btnIrDiligenciar.setFont(new Font("Arial", Font.BOLD, 11));
        btnIrDiligenciar.setFocusPainted(false);
        btnIrDiligenciar.addActionListener(e -> {
            new DiligenciarGastosView(idHogar, dia).setVisible(true);
            dispose();
        });
        panelTituloTabla.add(btnIrDiligenciar, BorderLayout.EAST);

        cardTabla.add(panelTituloTabla, BorderLayout.NORTH);

        String[] columnas = {"Nombre", "Cantidad", "Unidad de medida", "Equivalencia", "Forma de adquisición", "Lugar de compra", "Frecuencia", "Valor", "Acción"};
        modeloTabla = new DefaultTableModel(null, columnas) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 8; 
            }
        };

        tablaGastos = new JTable(modeloTabla);
        tablaGastos.setRowHeight(38);
        tablaGastos.setFont(new Font("Arial", Font.PLAIN, 12));
        tablaGastos.getTableHeader().setFont(new Font("Arial", Font.BOLD, 12));
        tablaGastos.getTableHeader().setBackground(new Color(245, 247, 250));
        tablaGastos.setShowGrid(false);
        tablaGastos.setIntercellSpacing(new Dimension(0, 0));

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.LEFT);
        for (int i = 0; i < tablaGastos.getColumnCount() - 1; i++) {
            tablaGastos.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }

        tablaGastos.getColumnModel().getColumn(8).setCellRenderer((table, value, isSelected, hasFocus, row, column) -> {
            JButton btn = new JButton("Corregir");
            btn.setFont(new Font("Arial", Font.BOLD, 11));
            btn.setForeground(new Color(20, 60, 140));
            btn.setBackground(new Color(230, 240, 255));
            btn.setBorderPainted(false);
            btn.setFocusPainted(false);
            return btn;
        });

        JScrollPane scrollTabla = new JScrollPane(tablaGastos);
        scrollTabla.setBorder(BorderFactory.createLineBorder(new Color(235, 235, 235)));
        cardTabla.add(scrollTabla, BorderLayout.CENTER);

        panelCentro.add(cardTabla);
        panelPrincipal.add(panelCentro, BorderLayout.CENTER);

        // --- BOTÓN INFERIOR DE CONFIRMACIÓN ---
        JPanel panelSur = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelSur.setOpaque(false);

        JButton btnConfirmar = new JButton("Confirmar verificación");
        btnConfirmar.setBackground(new Color(20, 60, 140));
        btnConfirmar.setForeground(Color.WHITE);
        btnConfirmar.setFont(new Font("Arial", Font.BOLD, 13));
        btnConfirmar.setFocusPainted(false);
        btnConfirmar.setPreferredSize(new Dimension(190, 38));

        btnConfirmar.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "¡Verificación del Día (" + dia + ") confirmada exitosamente!", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            new CitasPendientesView(documentoRecolector, nombreRecolector).setVisible(true);
            dispose();
        });

        panelSur.add(btnConfirmar);
        panelPrincipal.add(panelSur, BorderLayout.SOUTH);

        add(panelPrincipal);
    }

    private JPanel crearColumnaInfo(String titulo, JLabel lblValor) {
        JPanel p = new JPanel(new GridLayout(2, 1, 0, 2));
        p.setOpaque(false);
        JLabel lblT = new JLabel(titulo);
        lblT.setFont(new Font("Arial", Font.PLAIN, 11));
        lblT.setForeground(Color.GRAY);
        p.add(lblT);
        p.add(lblValor);
        return p;
    }

    private JLabel crearLabelValor(String texto) {
        JLabel l = new JLabel(texto);
        l.setFont(new Font("Arial", Font.BOLD, 12));
        return l;
    }

    // Carga los datos del Hogar, Dirección, Barrio y Encuestado
    private void cargarInformacionHogar() {
        String sql = "SELECT V.DIRECCION, B.NOMBRE AS BARRIO_NOMBRE, H.TOTAL_PERSONAS, E.NOMBRE, E.APELLIDO, E.TELEFONO " +
                     "FROM HOGAR H " +
                     "JOIN VIVIENDA V ON H.ID_VIVIENDA = V.ID_VIVIENDA " +
                     "JOIN BARRIO B ON V.ID_BARRIO = B.ID_BARRIO " +
                     "LEFT JOIN ENCUESTADO E ON H.ID_HOGAR = E.ID_HOGAR " +
                     "WHERE H.ID_HOGAR = ?";

        try (Connection con = ConexionOracle.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setLong(1, idHogar);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    String dir = rs.getString("DIRECCION");
                    String barrio = rs.getString("BARRIO_NOMBRE");
                    long totalPer = rs.getLong("TOTAL_PERSONAS");
                    String nombre = rs.getString("NOMBRE");
                    String apellido = rs.getString("APELLIDO");
                    long tel = rs.getLong("TELEFONO");

                    lblDireccion.setText(dir != null ? dir : "N/A");
                    lblBarrio.setText(barrio != null ? barrio : "N/A");
                    lblTotalPersonas.setText(String.valueOf(totalPer > 0 ? totalPer : 1));
                    lblEncuestado.setText((nombre != null ? nombre : "") + " " + (apellido != null ? apellido : "Sin encuestado"));
                    lblTelefono.setText(tel != 0 ? String.valueOf(tel) : "N/A");
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al cargar datos del hogar: " + e.getMessage());
        }
    }

    // CARGA LOS GASTOS REALES REGISTRADOS EN LA TABLA GASTOS DE ORACLE
    private void cargarGastosRealesDesdeBD() {
        modeloTabla.setRowCount(0);

        String sql = "SELECT G.ARTICULO, G.CANTIDAD, U.NOMBRE AS UNIDAD_MEDIDA, F.NOMBRE AS FORMA_ADQUISICION, " +
                     "L.NOMBRE AS LUGAR_COMPRA, FC.NOMBRE AS FRECUENCIA, G.VALOR_PRODUCTO " +
                     "FROM GASTOS G " +
                     "JOIN LUGAR_COMPRA L ON G.ID_LUGAR = L.ID_LUGAR " +
                     "JOIN UNIDAD_MEDIDA U ON G.ID_UNIDAD = U.ID_UNIDAD " +
                     "JOIN FORMA_ADQUISICION F ON G.ID_FORMA = F.ID_FORMA " +
                     "JOIN FRECUENCIA_COMPRA FC ON G.ID_FRECUENCIA = FC.ID_FRECUENCIA " +
                     "WHERE G.ID_HOGAR = ? " +
                     "ORDER BY G.ID_GASTO";

        NumberFormat formatoMoneda = NumberFormat.getCurrencyInstance(new Locale("es", "CO"));

        try (Connection con = ConexionOracle.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setLong(1, idHogar);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String nombre = rs.getString("ARTICULO");
                    double cantidad = rs.getDouble("CANTIDAD");
                    String unidad = rs.getString("UNIDAD_MEDIDA");
                    String forma = rs.getString("FORMA_ADQUISICION");
                    String lugar = rs.getString("LUGAR_COMPRA");
                    String frecuencia = rs.getString("FRECUENCIA");
                    double valor = rs.getDouble("VALOR_PRODUCTO");

                    String cantidadStr = (cantidad % 1 == 0) ? String.valueOf((int) cantidad) : String.valueOf(cantidad);
                    String equivalenciaStr = cantidadStr + " " + (unidad != null ? unidad : "");
                    String valorFormateado = formatoMoneda.format(valor);

                    modeloTabla.addRow(new Object[]{
                        nombre,
                        cantidadStr,
                        unidad != null ? unidad : "-",
                        equivalenciaStr,
                        forma != null ? forma : "Compra",
                        lugar,
                        frecuencia != null ? frecuencia : "Diario",
                        valorFormateado,
                        "Corregir"
                    });
                }
            }

        } catch (SQLException e) {
            System.err.println("Error al cargar gastos desde la BD: " + e.getMessage());
            e.printStackTrace();
        }
    }
}