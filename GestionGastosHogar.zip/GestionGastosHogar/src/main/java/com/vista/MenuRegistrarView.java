package com.vista;

import javax.swing.*;
import java.awt.*;

public class MenuRegistrarView extends JFrame {

    public MenuRegistrarView() {
        initComponentsCustom();
    }

    private void initComponentsCustom() {
        setTitle("ENPH - Menú Registrar");
        setSize(550, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panelPrincipal = new JPanel(new BorderLayout(15, 20));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(25, 40, 25, 40));
        panelPrincipal.setBackground(new Color(245, 245, 245));

        JButton btnVolver = new JButton("← Volver al menú principal");
        btnVolver.setBorderPainted(false);
        btnVolver.setContentAreaFilled(false);
        btnVolver.setForeground(Color.GRAY);
        btnVolver.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnVolver.addActionListener(e -> {
            new MenuPrincipal().setVisible(true);
            dispose();
        });

        JPanel panelTop = new JPanel(new BorderLayout());
        panelTop.setOpaque(false);
        panelTop.add(btnVolver, BorderLayout.NORTH);

        JLabel lblTitulo = new JLabel("Registrar");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 22));
        JLabel lblSub = new JLabel("Selecciona el tipo de registro que vas a realizar.");
        lblSub.setForeground(Color.GRAY);

        JPanel pText = new JPanel(new GridLayout(2, 1));
        pText.setOpaque(false);
        pText.add(lblTitulo);
        pText.add(lblSub);
        panelTop.add(pText, BorderLayout.SOUTH);

        panelPrincipal.add(panelTop, BorderLayout.NORTH);

        JPanel panelBotones = new JPanel(new GridLayout(3, 1, 15, 15));
        panelBotones.setOpaque(false);

        JButton btnRecolector = crearBotonMenu("Recolector   >");
        JButton btnVivienda = crearBotonMenu("Vivienda   >");
        JButton btnHogar = crearBotonMenu("Hogar y encuestado   >");

        btnRecolector.addActionListener(e -> {
            new RegistrarRecolectorView().setVisible(true);
            dispose();
        });

        btnVivienda.addActionListener(e -> {
            new RegistrarViviendaView().setVisible(true);
            dispose();
        });

        btnHogar.addActionListener(e -> {
            new SeleccionarViviendaView().setVisible(true);
            dispose();
        });

        panelBotones.add(btnRecolector);
        panelBotones.add(btnVivienda);
        panelBotones.add(btnHogar);

        panelPrincipal.add(panelBotones, BorderLayout.CENTER);
        add(panelPrincipal);
    }

    private JButton crearBotonMenu(String texto) {
        JButton btn = new JButton(texto);
        btn.setFont(new Font("Arial", Font.BOLD, 14));
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setBackground(Color.WHITE);
        btn.setForeground(new Color(20, 60, 140));
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 220, 220), 1),
                BorderFactory.createEmptyBorder(15, 20, 15, 20)
        ));
        return btn;
    }
}