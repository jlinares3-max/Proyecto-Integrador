package com.vista;

import javax.swing.*;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class HogarRegistradoExitoView extends JFrame {
    private long idVivienda;
    private String direccionVivienda;
    private long idHogar;
    private String totalPersonas;
    private String nombreEncuestado;
    private String nombreRecolector;
    private Date fechaPrimeraCita;

    public HogarRegistradoExitoView(long idVivienda, String direccionVivienda, long idHogar, String totalPersonas, String nombreEncuestado, String nombreRecolector, Date fechaPrimeraCita) {
        this.idVivienda = idVivienda;
        this.direccionVivienda = direccionVivienda;
        this.idHogar = idHogar;
        this.totalPersonas = totalPersonas;
        this.nombreEncuestado = nombreEncuestado;
        this.nombreRecolector = nombreRecolector;
        this.fechaPrimeraCita = fechaPrimeraCita;
        initComponentsCustom();
    }

    private void initComponentsCustom() {
        setTitle("ENPH - Hogar registrado correctamente");
        setSize(700, 550);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panelPrincipal = new JPanel(new BorderLayout(15, 15));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(25, 30, 25, 30));
        panelPrincipal.setBackground(new Color(245, 245, 245));

        // Cabecera superior
        JLabel lblLogo = new JLabel("ENPH");
        lblLogo.setFont(new Font("Arial", Font.BOLD, 18));
        JLabel lblCuadernillo = new JLabel("Cuadernillo 2 urbano");
        lblCuadernillo.setForeground(Color.GRAY);

        JPanel panelTop = new JPanel(new BorderLayout());
        panelTop.setOpaque(false);
        panelTop.add(lblLogo, BorderLayout.WEST);
        panelTop.add(lblCuadernillo, BorderLayout.EAST);
        panelPrincipal.add(panelTop, BorderLayout.NORTH);

        // Contenedor central
        JPanel panelCentro = new JPanel();
        panelCentro.setLayout(new BoxLayout(panelCentro, BoxLayout.Y_AXIS));
        panelCentro.setOpaque(false);

        // Icono de éxito verde
        JLabel lblCheck = new JLabel("✓", SwingConstants.CENTER);
        lblCheck.setFont(new Font("Arial", Font.BOLD, 22));
        lblCheck.setForeground(new Color(40, 140, 70));
        lblCheck.setOpaque(true);
        lblCheck.setBackground(new Color(210, 240, 220));
        lblCheck.setPreferredSize(new Dimension(45, 45));
        lblCheck.setMaximumSize(new Dimension(45, 45));
        lblCheck.setAlignmentX(Component.CENTER_ALIGNMENT);

        JPanel pIcon = new JPanel(new GridBagLayout());
        pIcon.setOpaque(false);
        pIcon.add(lblCheck);
        panelCentro.add(pIcon);
        panelCentro.add(Box.createVerticalStrut(10));

        JLabel lblTitulo = new JLabel("Hogar registrado correctamente");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 22));
        lblTitulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        panelCentro.add(lblTitulo);

        JLabel lblSub = new JLabel("El HOGAR " + idHogar + " quedó registrado y asignado al recolector.");
        lblSub.setForeground(Color.GRAY);
        lblSub.setAlignmentX(Component.CENTER_ALIGNMENT);
        panelCentro.add(lblSub);
        panelCentro.add(Box.createVerticalStrut(20));

        // Tarjeta resumen blanca
        JPanel cardResumen = new JPanel(new GridLayout(6, 2, 10, 12));
        cardResumen.setBackground(Color.WHITE);
        cardResumen.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 220, 220)),
                BorderFactory.createEmptyBorder(20, 25, 20, 25)
        ));
        cardResumen.setMaximumSize(new Dimension(600, 230));

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String fechaStr = fechaPrimeraCita != null ? sdf.format(fechaPrimeraCita) : "";

        cardResumen.add(crearLabelGris("Vivienda"));
        cardResumen.add(crearLabelNegrita(direccionVivienda));

        cardResumen.add(crearLabelGris("Hogar"));
        cardResumen.add(crearLabelNegrita("HOGAR " + idHogar));

        cardResumen.add(crearLabelGris("Total de personas"));
        cardResumen.add(crearLabelNegrita(totalPersonas));

        cardResumen.add(crearLabelGris("Encuestado"));
        cardResumen.add(crearLabelNegrita(nombreEncuestado));

        cardResumen.add(crearLabelGris("Recolector"));
        cardResumen.add(crearLabelNegrita(nombreRecolector));

        cardResumen.add(crearLabelGris("Fecha de la primera cita"));
        cardResumen.add(crearLabelNegrita(fechaStr));

        panelCentro.add(cardResumen);
        panelPrincipal.add(panelCentro, BorderLayout.CENTER);

        // Botones inferiores
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 0));
        panelBotones.setOpaque(false);

        JButton btnOtroHogar = new JButton("Registrar otro hogar");
        JButton btnVolverDetalle = new JButton("Volver al detalle de la vivienda");

        btnVolverDetalle.setBackground(new Color(20, 60, 140));
        btnVolverDetalle.setForeground(Color.WHITE);
        btnVolverDetalle.setFocusPainted(false);

        btnOtroHogar.addActionListener(e -> {
            new RegistrarHogarPaso1View(idVivienda, direccionVivienda).setVisible(true);
            dispose();
        });

        btnVolverDetalle.addActionListener(e -> {
            new DetalleViviendaView(idVivienda, direccionVivienda).setVisible(true);
            dispose();
        });

        panelBotones.add(btnOtroHogar);
        panelBotones.add(btnVolverDetalle);

        panelPrincipal.add(panelBotones, BorderLayout.SOUTH);
        add(panelPrincipal);
    }

    private JLabel crearLabelGris(String texto) {
        JLabel l = new JLabel(texto);
        l.setForeground(new Color(110, 110, 110));
        return l;
    }

    private JLabel crearLabelNegrita(String texto) {
        JLabel l = new JLabel(texto);
        l.setFont(new Font("Arial", Font.BOLD, 12));
        return l;
    }
}