package com.vista;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class DetalleViviendaView extends JFrame {
    private long idVivienda;
    private String direccionVivienda;

    public DetalleViviendaView(long idVivienda, String direccion) {
        this.idVivienda = idVivienda;
        this.direccionVivienda = direccion;
        initComponentsCustom();
    }

    private void initComponentsCustom() {
        setTitle("ENPH - Detalle de vivienda");
        setSize(750, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panelPrincipal = new JPanel(new BorderLayout(10, 15));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(20, 25, 20, 25));
        panelPrincipal.setBackground(new Color(245, 245, 245));

        JButton btnVolver = new JButton("← Volver a viviendas");
        btnVolver.setBorderPainted(false);
        btnVolver.setContentAreaFilled(false);
        btnVolver.setForeground(Color.GRAY);
        btnVolver.addActionListener(e -> {
            new SeleccionarViviendaView().setVisible(true);
            dispose();
        });

        JPanel panelTop = new JPanel(new BorderLayout());
        panelTop.setOpaque(false);
        panelTop.add(btnVolver, BorderLayout.NORTH);

        JLabel lblTitulo = new JLabel("Detalle de vivienda");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 22));
        JLabel lblSub = new JLabel("Información de la vivienda seleccionada y sus hogares.");
        lblSub.setForeground(Color.GRAY);

        JPanel pHead = new JPanel(new GridLayout(2, 1));
        pHead.setOpaque(false);
        pHead.add(lblTitulo);
        pHead.add(lblSub);
        panelTop.add(pHead, BorderLayout.SOUTH);

        panelPrincipal.add(panelTop, BorderLayout.NORTH);

        JPanel panelCentro = new JPanel();
        panelCentro.setLayout(new BoxLayout(panelCentro, BoxLayout.Y_AXIS));
        panelCentro.setOpaque(false);

        JPanel ficha = new JPanel(new BorderLayout());
        ficha.setBackground(Color.WHITE);
        ficha.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 220, 220)),
                BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        ficha.add(new JLabel("<html><b>" + direccionVivienda + "</b><br><font color='gray'>ID Vivienda: " + idVivienda + "</font></html>"), BorderLayout.CENTER);
        ficha.setMaximumSize(new Dimension(Integer.MAX_VALUE, 65));
        panelCentro.add(ficha);
        panelCentro.add(Box.createVerticalStrut(15));

        JPanel panelTablaHeader = new JPanel(new BorderLayout());
        panelTablaHeader.setOpaque(false);
        JLabel lblTablaTit = new JLabel("Lista de Hogares Asignados");
        lblTablaTit.setFont(new Font("Arial", Font.BOLD, 14));

        JButton btnRegHogar = new JButton("+ Registrar hogar y encuestado");
        btnRegHogar.setBackground(new Color(20, 60, 130));
        btnRegHogar.setForeground(Color.WHITE);
        btnRegHogar.addActionListener(e -> {
            new RegistrarHogarPaso1View(idVivienda, direccionVivienda).setVisible(true);
            dispose();
        });

        panelTablaHeader.add(lblTablaTit, BorderLayout.WEST);
        panelTablaHeader.add(btnRegHogar, BorderLayout.EAST);
        panelCentro.add(panelTablaHeader);
        panelCentro.add(Box.createVerticalStrut(10));

        String[] cols = {"Hogar ID", "Encuestado", "Total de personas", "Recolector", "Fecha asignación"};
        Object[][] datos = {
            {"101", "Juan Linares", "4", "1093433066", "2026-10-19"},
            {"102", "[Sin encuestado]", "2", "Sin recolector", "—"}
        };
        JTable tabla = new JTable(new DefaultTableModel(datos, cols));
        JScrollPane scrollTabla = new JScrollPane(tabla);
        panelCentro.add(scrollTabla);

        panelPrincipal.add(panelCentro, BorderLayout.CENTER);
        add(panelPrincipal);
    }
}