package com.vista;

import com.conexion.ConexionOracle;
import com.dao.ViviendaDAO;
import com.modelo.Vivienda;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class RegistrarViviendaView extends JFrame {

    private JTextField txtDireccion, txtTipoVivienda;
    private JComboBox<String> cmbDepartamento, cmbMunicipio, cmbBarrio;
    
    // Mapas para almacenar los IDs reales de la base de datos
    private Map<String, Long> mapaDepartamentos = new HashMap<>();
    private Map<String, Long> mapaMunicipios = new HashMap<>();
    private Map<String, Long> mapaBarrios = new HashMap<>();

    public RegistrarViviendaView() {
        initComponentsCustom();
        cargarDepartamentosDesdeBD();
    }

    private void initComponentsCustom() {
        setTitle("ENPH - Registrar vivienda");
        setSize(750, 520);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panelPrincipal = new JPanel(new BorderLayout(10, 15));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));
        panelPrincipal.setBackground(new Color(245, 245, 245));

        // Enlace superior de retroceso
        JButton btnVolver = new JButton("← Volver al menú Registrar");
        btnVolver.setBorderPainted(false);
        btnVolver.setContentAreaFilled(false);
        btnVolver.setForeground(Color.GRAY);
        btnVolver.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnVolver.addActionListener(e -> {
            new MenuRegistrarView().setVisible(true);
            dispose();
        });

        JPanel panelTop = new JPanel(new BorderLayout());
        panelTop.setOpaque(false);
        panelTop.add(btnVolver, BorderLayout.NORTH);

        JLabel lblTitulo = new JLabel("Registrar vivienda");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 22));
        JLabel lblSub = new JLabel("Ingresa la información de la vivienda y su ubicación.");
        lblSub.setForeground(Color.GRAY);

        JPanel pHeadText = new JPanel(new GridLayout(2, 1, 2, 2));
        pHeadText.setOpaque(false);
        pHeadText.add(lblTitulo);
        pHeadText.add(lblSub);
        panelTop.add(pHeadText, BorderLayout.SOUTH);
        panelPrincipal.add(panelTop, BorderLayout.NORTH);

        // Tarjeta central blanca
        JPanel panelCard = new JPanel(new BorderLayout());
        panelCard.setBackground(Color.WHITE);
        panelCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 220, 220)),
                BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));

        JLabel lblSeccion = new JLabel("Datos de la vivienda");
        lblSeccion.setFont(new Font("Arial", Font.BOLD, 14));

        JPanel panelForm = new JPanel(new GridLayout(3, 2, 15, 15));
        panelForm.setBackground(Color.WHITE);
        panelForm.setBorder(BorderFactory.createEmptyBorder(15, 0, 15, 0));

        txtDireccion = new JTextField();
        txtDireccion.setBorder(BorderFactory.createTitledBorder("Dirección *"));
        
        txtTipoVivienda = new JTextField();
        txtTipoVivienda.setBorder(BorderFactory.createTitledBorder("Tipo de vivienda *"));
        
        cmbDepartamento = new JComboBox<>();
        cmbDepartamento.setBorder(BorderFactory.createTitledBorder("Departamento *"));
        
        cmbMunicipio = new JComboBox<>();
        cmbMunicipio.setBorder(BorderFactory.createTitledBorder("Municipio *"));

        cmbBarrio = new JComboBox<>();
        cmbBarrio.setBorder(BorderFactory.createTitledBorder("Barrio *"));

        panelForm.add(txtDireccion);
        panelForm.add(txtTipoVivienda);
        panelForm.add(cmbDepartamento);
        panelForm.add(cmbMunicipio);
        panelForm.add(cmbBarrio);

        // Listeners para los ComboBox en cascada
        cmbDepartamento.addActionListener(e -> {
            String depSeleccionado = (String) cmbDepartamento.getSelectedItem();
            if (depSeleccionado != null && mapaDepartamentos.containsKey(depSeleccionado)) {
                cargarMunicipiosDesdeBD(mapaDepartamentos.get(depSeleccionado));
            }
        });

        cmbMunicipio.addActionListener(e -> {
            String munSeleccionado = (String) cmbMunicipio.getSelectedItem();
            if (munSeleccionado != null && mapaMunicipios.containsKey(munSeleccionado)) {
                cargarBarriosDesdeBD(mapaMunicipios.get(munSeleccionado));
            }
        });

        // Panel inferior con botones
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        panelBotones.setBackground(Color.WHITE);

        JButton btnCancelar = new JButton("Cancelar");
        JButton btnGuardar = new JButton("Guardar vivienda");

        btnGuardar.setBackground(new Color(20, 60, 140));
        btnGuardar.setForeground(Color.WHITE);
        btnGuardar.setFocusPainted(false);

        btnCancelar.addActionListener(e -> {
            new MenuRegistrarView().setVisible(true);
            dispose();
        });

        btnGuardar.addActionListener(e -> guardarViviendaBD());

        panelBotones.add(btnCancelar);
        panelBotones.add(btnGuardar);

        panelCard.add(lblSeccion, BorderLayout.NORTH);
        panelCard.add(panelForm, BorderLayout.CENTER);
        panelCard.add(panelBotones, BorderLayout.SOUTH);

        panelPrincipal.add(panelCard, BorderLayout.CENTER);
        add(panelPrincipal);
    }

    private void cargarDepartamentosDesdeBD() {
        cmbDepartamento.removeAllItems();
        mapaDepartamentos.clear();
        
        String sql = "SELECT ID_DEPARTAMENTO, NOMBRE FROM DEPARTAMENTO ORDER BY NOMBRE";
        try (Connection con = ConexionOracle.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                long id = rs.getLong("ID_DEPARTAMENTO");
                String nombre = rs.getString("NOMBRE");
                cmbDepartamento.addItem(nombre);
                mapaDepartamentos.put(nombre, id);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar departamentos: " + e.getMessage());
        }
    }

    private void cargarMunicipiosDesdeBD(long idDepartamento) {
        cmbMunicipio.removeAllItems();
        mapaMunicipios.clear();
        
        String sql = "SELECT ID_MUNICIPIO, NOMBRE FROM MUNICIPIO WHERE ID_DEPARTAMENTO = ? ORDER BY NOMBRE";
        try (Connection con = ConexionOracle.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setLong(1, idDepartamento);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    long id = rs.getLong("ID_MUNICIPIO");
                    String nombre = rs.getString("NOMBRE");
                    cmbMunicipio.addItem(nombre);
                    mapaMunicipios.put(nombre, id);
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar municipios: " + e.getMessage());
        }
    }

    private void cargarBarriosDesdeBD(long idMunicipio) {
        cmbBarrio.removeAllItems();
        mapaBarrios.clear();
        
        String sql = "SELECT ID_BARRIO, NOMBRE FROM BARRIO WHERE ID_MUNICIPIO = ? ORDER BY NOMBRE";
        try (Connection con = ConexionOracle.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setLong(1, idMunicipio);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    long id = rs.getLong("ID_BARRIO");
                    String nombre = rs.getString("NOMBRE");
                    cmbBarrio.addItem(nombre);
                    mapaBarrios.put(nombre, id);
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar barrios: " + e.getMessage());
        }
    }

    private void guardarViviendaBD() {
        try {
            if (txtDireccion.getText().isEmpty() || txtTipoVivienda.getText().isEmpty()) {
                JOptionPane.showMessageDialog(this, "La Dirección y el Tipo de vivienda son obligatorios.", "Advertencia", JOptionPane.WARNING_MESSAGE);
                return;
            }

            String barrioSeleccionado = (String) cmbBarrio.getSelectedItem();
            if (barrioSeleccionado == null || !mapaBarrios.containsKey(barrioSeleccionado)) {
                JOptionPane.showMessageDialog(this, "Debe seleccionar un barrio válido.", "Advertencia", JOptionPane.WARNING_MESSAGE);
                return;
            }

            long idBarrioReal = mapaBarrios.get(barrioSeleccionado);
            long idViviendaGenerado = System.currentTimeMillis() / 1000;

            Vivienda viv = new Vivienda();
            viv.setIdVivienda(idViviendaGenerado);
            viv.setDireccion(txtDireccion.getText());
            viv.setCantHogares(1L);
            viv.setIdBarrio(idBarrioReal);
            viv.setEstado("ACTIVA");

            ViviendaDAO dao = new ViviendaDAO();
            boolean exito = dao.insertarVivienda(viv);

            if (exito) {
                JOptionPane.showMessageDialog(this, "¡Vivienda guardada correctamente en Oracle!");
                new MenuRegistrarView().setVisible(true);
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Error al registrar la vivienda en la BD.", "Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Excepción", JOptionPane.ERROR_MESSAGE);
        }
    }
}