package com.vista;

import javax.swing.*;
import java.awt.*;

public class MenuPrincipal extends JFrame {

    public MenuPrincipal() {
        initComponentsCustom();
    }

    private void initComponentsCustom() {
        setTitle("ENPH - Gastos Diarios del Hogar");
        setSize(550, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panelPrincipal = new JPanel(new BorderLayout(15, 25));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));
        panelPrincipal.setBackground(new Color(245, 245, 245));

        // Encabezado
        JPanel panelHeader = new JPanel(new GridLayout(2, 1, 5, 5));
        panelHeader.setOpaque(false);
        
        JLabel lblTitulo = new JLabel("Gastos Diarios del Hogar", JLabel.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 22));
        lblTitulo.setForeground(new Color(20, 30, 50));
        
        JLabel lblSubtitulo = new JLabel("Selecciona el módulo con el que vas a trabajar.", JLabel.CENTER);
        lblSubtitulo.setFont(new Font("Arial", Font.PLAIN, 13));
        lblSubtitulo.setForeground(Color.GRAY);

        panelHeader.add(lblTitulo);
        panelHeader.add(lblSubtitulo);
        panelPrincipal.add(panelHeader, BorderLayout.NORTH);

        // Panel de botones
        JPanel panelBotones = new JPanel(new GridLayout(3, 1, 15, 15));
        panelBotones.setOpaque(false);

        JButton btnRegistrar = crearBotonMenu("Registrar   >");
        JButton btnDiligenciar = crearBotonMenu("Diligenciar Gastos Diarios   >");
        JButton btnSupervisar = crearBotonMenu("Supervisar Gastos Diarios   >");

        btnRegistrar.addActionListener(e -> {
            new MenuRegistrarView().setVisible(true);
            dispose();
        });

        btnDiligenciar.addActionListener(e -> {
            new ValidarEncuestadoView().setVisible(true);
            dispose();
        });

        btnSupervisar.addActionListener(e -> {
            new ValidarRecolectorView().setVisible(true);
            dispose();
        });

        panelBotones.add(btnRegistrar);
        panelBotones.add(btnDiligenciar);
        panelBotones.add(btnSupervisar);

        panelPrincipal.add(panelBotones, BorderLayout.CENTER);
        add(panelPrincipal);
    }

    private JButton crearBotonMenu(String texto) {
        JButton btn = new JButton(texto);
        btn.setFont(new Font("Arial", Font.BOLD, 14));
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setBackground(Color.WHITE);
        btn.setForeground(new Color(20, 60, 140));
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 220, 220), 1),
                BorderFactory.createEmptyBorder(15, 20, 15, 20)
        ));
        return btn;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MenuPrincipal().setVisible(true));
    }
}