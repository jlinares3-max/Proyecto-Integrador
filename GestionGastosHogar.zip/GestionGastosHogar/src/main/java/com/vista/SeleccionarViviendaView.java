package com.vista;

import com.conexion.ConexionOracle;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SeleccionarViviendaView extends JFrame {

    private JPanel panelLista;

    public SeleccionarViviendaView() {
        initComponentsCustom();
        cargarViviendasDesdeBD();
    }

    private void initComponentsCustom() {
        setTitle("ENPH - Seleccionar vivienda");
        setSize(750, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panelPrincipal = new JPanel(new BorderLayout(10, 15));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(20, 25, 20, 25));
        panelPrincipal.setBackground(new Color(245, 245, 245));

        JButton btnVolver = new JButton("← Volver al menú Registrar");
        btnVolver.setBorderPainted(false);
        btnVolver.setContentAreaFilled(false);
        btnVolver.setForeground(Color.GRAY);
        btnVolver.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnVolver.addActionListener(e -> {
            new MenuRegistrarView().setVisible(true);
            dispose();
        });

        JPanel panelTop = new JPanel(new BorderLayout());
        panelTop.setOpaque(false);
        panelTop.add(btnVolver, BorderLayout.NORTH);

        JLabel lblTitulo = new JLabel("Seleccionar vivienda");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 22));
        JLabel lblSub = new JLabel("Elige la vivienda real en la que se registrará el hogar y su encuestado.");
        lblSub.setForeground(Color.GRAY);

        JPanel panelTitulos = new JPanel(new GridLayout(2, 1));
        panelTitulos.setOpaque(false);
        panelTitulos.add(lblTitulo);
        panelTitulos.add(lblSub);
        panelTop.add(panelTitulos, BorderLayout.SOUTH);

        panelPrincipal.add(panelTop, BorderLayout.NORTH);

        // Panel contenedor de las fichas de viviendas
        panelLista = new JPanel();
        panelLista.setLayout(new BoxLayout(panelLista, BoxLayout.Y_AXIS));
        panelLista.setOpaque(false);

        JScrollPane scroll = new JScrollPane(panelLista);
        scroll.setBorder(null);
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);

        panelPrincipal.add(scroll, BorderLayout.CENTER);
        add(panelPrincipal);
    }

    // Consulta las viviendas reales directamente desde Oracle
    private void cargarViviendasDesdeBD() {
        String sql = "SELECT ID_VIVIENDA, DIRECCION, ESTADO FROM VIVIENDA ORDER BY ID_VIVIENDA DESC";
        
        try (Connection con = ConexionOracle.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            boolean hayViviendas = false;
            while (rs.next()) {
                hayViviendas = true;
                long idVivienda = rs.getLong("ID_VIVIENDA");
                String direccion = rs.getString("DIRECCION");
                String estado = rs.getString("ESTADO");

                panelLista.add(crearFichaVivienda(idVivienda, direccion, "Estado: " + estado + " • ID: " + idVivienda));
                panelLista.add(Box.createVerticalStrut(10));
            }

            if (!hayViviendas) {
                JLabel lblVacio = new JLabel("No hay viviendas registradas en la base de datos.");
                lblVacio.setForeground(Color.GRAY);
                panelLista.add(lblVacio);
            }

            panelLista.revalidate();
            panelLista.repaint();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar viviendas desde Oracle: " + e.getMessage(), "Error BD", JOptionPane.ERROR_MESSAGE);
        }
    }

    private JPanel crearFichaVivienda(long idVivienda, String direccion, String info) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 220, 220)),
                BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));

        JLabel lblInfo = new JLabel("<html><b>" + direccion + "</b><br><font color='gray'>" + info + "</font></html>");
        JButton btnSeleccionar = new JButton("Seleccionar");
        
        btnSeleccionar.setBackground(new Color(220, 235, 255));
        btnSeleccionar.setForeground(new Color(20, 60, 130));
        btnSeleccionar.setFocusPainted(false);
        btnSeleccionar.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Al hacer clic, pasa el ID y dirección REALES de Oracle a la siguiente ventana
        btnSeleccionar.addActionListener(e -> {
            new DetalleViviendaView(idVivienda, direccion).setVisible(true);
            dispose();
        });

        panel.add(lblInfo, BorderLayout.CENTER);
        panel.add(btnSeleccionar, BorderLayout.EAST);
        
        panel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 75));
        return panel;
    }
}