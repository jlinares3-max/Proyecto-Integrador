package com.vista;

import com.conexion.ConexionOracle;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

public class CitasPendientesView extends JFrame {

    private long documentoRecolector;
    private String nombreRecolector;
    private JPanel panelListaCitas;

    public CitasPendientesView(long documentoRecolector, String nombreRecolector) {
        this.documentoRecolector = documentoRecolector;
        this.nombreRecolector = nombreRecolector;
        initComponentsCustom();
        cargarCitasDesdeBD();
    }

    private void initComponentsCustom() {
        setTitle("ENPH - Citas pendientes");
        setSize(900, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panelPrincipal = new JPanel(new BorderLayout(15, 15));
        panelPrincipal.setBackground(new Color(245, 245, 245));
        panelPrincipal.setBorder(new EmptyBorder(20, 30, 20, 30));

        JPanel panelTop = new JPanel(new BorderLayout(5, 5));
        panelTop.setOpaque(false);

        JLabel lblLogo = new JLabel("ENPH");
        lblLogo.setFont(new Font("Arial", Font.BOLD, 18));
        JLabel lblCuadernillo = new JLabel("Cuadernillo 2 urbano");
        lblCuadernillo.setForeground(Color.GRAY);

        JPanel panelHeaderTop = new JPanel(new BorderLayout());
        panelHeaderTop.setOpaque(false);
        panelHeaderTop.add(lblLogo, BorderLayout.WEST);
        panelHeaderTop.add(lblCuadernillo, BorderLayout.EAST);
        panelTop.add(panelHeaderTop, BorderLayout.NORTH);

        JButton btnSalir = new JButton("← Salir");
        btnSalir.setBorderPainted(false);
        btnSalir.setContentAreaFilled(false);
        btnSalir.setForeground(Color.GRAY);
        btnSalir.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnSalir.setHorizontalAlignment(SwingConstants.LEFT);
        btnSalir.addActionListener(e -> {
            new MenuPrincipal().setVisible(true);
            dispose();
        });

        JLabel lblTitulo = new JLabel("Citas pendientes");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 24));

        JLabel lblSubtitulo = new JLabel("Recolector: " + nombreRecolector + " · Selecciona un hogar para revisar sus gastos.");
        lblSubtitulo.setForeground(Color.GRAY);

        JPanel panelTitulos = new JPanel();
        panelTitulos.setLayout(new BoxLayout(panelTitulos, BoxLayout.Y_AXIS));
        panelTitulos.setOpaque(false);
        panelTitulos.add(btnSalir);
        panelTitulos.add(Box.createVerticalStrut(10));
        panelTitulos.add(lblTitulo);
        panelTitulos.add(Box.createVerticalStrut(4));
        panelTitulos.add(lblSubtitulo);

        panelTop.add(panelTitulos, BorderLayout.SOUTH);
        panelPrincipal.add(panelTop, BorderLayout.NORTH);

        panelListaCitas = new JPanel();
        panelListaCitas.setLayout(new BoxLayout(panelListaCitas, BoxLayout.Y_AXIS));
        panelListaCitas.setOpaque(false);

        JScrollPane scrollPane = new JScrollPane(panelListaCitas);
        scrollPane.setBorder(null);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);

        panelPrincipal.add(scrollPane, BorderLayout.CENTER);
        add(panelPrincipal);
    }

    private void cargarCitasDesdeBD() {
        panelListaCitas.removeAll();

        String sql = "SELECT H.ID_HOGAR, H.FECHA_PRIMERA_VISITA, V.DIRECCION, " +
                     "E.NOMBRE AS ENC_NOMBRE, E.APELLIDO AS ENC_APELLIDO " +
                     "FROM HOGAR H " +
                     "JOIN VIVIENDA V ON H.ID_VIVIENDA = V.ID_VIVIENDA " +
                     "LEFT JOIN ENCUESTADO E ON H.ID_HOGAR = E.ID_HOGAR " +
                     "WHERE H.DOCUMENTO_RECOLECTOR = ? " +
                     "ORDER BY H.ID_HOGAR";

        try (Connection con = ConexionOracle.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setLong(1, documentoRecolector);
            try (ResultSet rs = ps.executeQuery()) {
                boolean hayCitas = false;

                while (rs.next()) {
                    hayCitas = true;
                    long idHogar = rs.getLong("ID_HOGAR");
                    Date fechaCita = rs.getDate("FECHA_PRIMERA_VISITA");
                    String direccion = rs.getString("DIRECCION");
                    String encNombre = rs.getString("ENC_NOMBRE");
                    String encApellido = rs.getString("ENC_APELLIDO");

                    String encuestadoFull = (encNombre != null ? encNombre + " " + encApellido : "[Sin encuestado]");
                    if (direccion == null || direccion.isEmpty()) direccion = "[Dirección]";

                    JPanel tarjeta = crearTarjetaCita(idHogar, fechaCita, direccion, encuestadoFull);
                    panelListaCitas.add(tarjeta);
                    panelListaCitas.add(Box.createVerticalStrut(12));
                }

                if (!hayCitas) {
                    JLabel lblVacio = new JLabel("No tienes citas pendientes asignadas.");
                    lblVacio.setForeground(Color.GRAY);
                    lblVacio.setFont(new Font("Arial", Font.ITALIC, 14));
                    panelListaCitas.add(lblVacio);
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar citas pendientes: " + e.getMessage(), "Error BD", JOptionPane.ERROR_MESSAGE);
        }

        panelListaCitas.revalidate();
        panelListaCitas.repaint();
    }

    private JPanel crearTarjetaCita(long idHogar, Date fecha, String direccion, String encuestado) {
        JPanel card = new JPanel(new BorderLayout(15, 0));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(230, 230, 230), 1),
                new EmptyBorder(12, 15, 12, 15)
        ));
        card.setMaximumSize(new Dimension(820, 65));

        JPanel pCentro = new JPanel(new GridLayout(2, 1, 0, 2));
        pCentro.setOpaque(false);

        JLabel lblHogarDir = new JLabel("HOGAR " + String.format("%03d", idHogar) + " · " + direccion);
        lblHogarDir.setFont(new Font("Arial", Font.BOLD, 14));

        JLabel lblBarrioEnc = new JLabel("Encuestado: " + encuestado);
        lblBarrioEnc.setFont(new Font("Arial", Font.PLAIN, 11));
        lblBarrioEnc.setForeground(Color.GRAY);

        pCentro.add(lblHogarDir);
        pCentro.add(lblBarrioEnc);
        card.add(pCentro, BorderLayout.CENTER);

        JPanel pDerecha = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 5));
        pDerecha.setOpaque(false);

        JButton btnRevisar = new JButton("Revisar gastos");
        btnRevisar.setBackground(new Color(20, 60, 140));
        btnRevisar.setForeground(Color.WHITE);
        btnRevisar.setFont(new Font("Arial", Font.BOLD, 11));
        btnRevisar.setFocusPainted(false);
        
        // Abre la vista calculando automáticamente el día en la BD
        btnRevisar.addActionListener(e -> {
            new SeguimientoGastosDiariosView(idHogar, documentoRecolector, nombreRecolector).setVisible(true);
            dispose();
        });

        pDerecha.add(btnRevisar);
        card.add(pDerecha, BorderLayout.EAST);

        return card;
    }
}