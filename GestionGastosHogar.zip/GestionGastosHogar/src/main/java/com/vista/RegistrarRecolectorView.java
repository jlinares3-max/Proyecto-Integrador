package com.vista;

import com.dao.RecolectorDAO;
import com.modelo.Recolector;

import javax.swing.*;
import java.awt.*;

public class RegistrarRecolectorView extends JFrame {

    private JTextField txtNombre, txtApellido, txtCedula, txtCredencial, txtTelefono;

    public RegistrarRecolectorView() {
        initComponentsCustom();
    }

    private void initComponentsCustom() {
        setTitle("ENPH - Registrar Recolector");
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panelPrincipal = new JPanel(new BorderLayout(10, 15));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));
        panelPrincipal.setBackground(new Color(245, 245, 245));

        JButton btnVolver = new JButton("← Volver al menú Registrar");
        btnVolver.setBorderPainted(false);
        btnVolver.setContentAreaFilled(false);
        btnVolver.setForeground(Color.GRAY);
        btnVolver.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnVolver.addActionListener(e -> {
            new MenuRegistrarView().setVisible(true);
            dispose();
        });

        JPanel panelTop = new JPanel(new BorderLayout());
        panelTop.setOpaque(false);
        panelTop.add(btnVolver, BorderLayout.NORTH);

        JLabel lblTitulo = new JLabel("Registrar Recolector");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 22));
        JLabel lblSub = new JLabel("Ingresa la información del nuevo recolector.");
        lblSub.setForeground(Color.GRAY);

        JPanel pHeadText = new JPanel(new GridLayout(2, 1, 2, 2));
        pHeadText.setOpaque(false);
        pHeadText.add(lblTitulo);
        pHeadText.add(lblSub);
        panelTop.add(pHeadText, BorderLayout.SOUTH);
        panelPrincipal.add(panelTop, BorderLayout.NORTH);

        JPanel panelCard = new JPanel(new BorderLayout());
        panelCard.setBackground(Color.WHITE);
        panelCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 220, 220)),
                BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));

        JLabel lblSeccion = new JLabel("Datos del Recolector");
        lblSeccion.setFont(new Font("Arial", Font.BOLD, 14));

        JPanel panelForm = new JPanel(new GridLayout(3, 2, 15, 15));
        panelForm.setBackground(Color.WHITE);
        panelForm.setBorder(BorderFactory.createEmptyBorder(15, 0, 15, 0));

        txtNombre = new JTextField();
        txtNombre.setBorder(BorderFactory.createTitledBorder("Nombre *"));
        txtApellido = new JTextField();
        txtApellido.setBorder(BorderFactory.createTitledBorder("Apellido *"));
        txtCedula = new JTextField();
        txtCedula.setBorder(BorderFactory.createTitledBorder("Cédula *"));
        txtCredencial = new JTextField();
        txtCredencial.setBorder(BorderFactory.createTitledBorder("Credencial DANE *"));
        txtTelefono = new JTextField();
        txtTelefono.setBorder(BorderFactory.createTitledBorder("Teléfono celular *"));

        panelForm.add(txtNombre);
        panelForm.add(txtApellido);
        panelForm.add(txtCedula);
        panelForm.add(txtCredencial);
        panelForm.add(txtTelefono);

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelBotones.setBackground(Color.WHITE);

        JButton btnCancelar = new JButton("Cancelar");
        JButton btnGuardar = new JButton("Guardar recolector");

        btnGuardar.setBackground(new Color(20, 60, 140));
        btnGuardar.setForeground(Color.WHITE);

        btnCancelar.addActionListener(e -> {
            new MenuRegistrarView().setVisible(true);
            dispose();
        });

        btnGuardar.addActionListener(e -> guardarRecolectorBD());

        panelBotones.add(btnCancelar);
        panelBotones.add(btnGuardar);

        panelCard.add(lblSeccion, BorderLayout.NORTH);
        panelCard.add(panelForm, BorderLayout.CENTER);
        panelCard.add(panelBotones, BorderLayout.SOUTH);

        panelPrincipal.add(panelCard, BorderLayout.CENTER);
        add(panelPrincipal);
    }

    private void guardarRecolectorBD() {
        try {
            if (txtCedula.getText().isEmpty() || txtNombre.getText().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Cédula y Nombre son obligatorios.", "Advertencia", JOptionPane.WARNING_MESSAGE);
                return;
            }

            Recolector rec = new Recolector();
            rec.setDocumento(Long.parseLong(txtCedula.getText()));
            rec.setCredencial(txtCredencial.getText());
            rec.setNombre(txtNombre.getText());
            rec.setApellido(txtApellido.getText());

            RecolectorDAO dao = new RecolectorDAO();
            boolean exito = dao.insertarRecolector(rec);

            if (exito) {
                JOptionPane.showMessageDialog(this, "¡Recolector registrado con éxito en Oracle!");
                new MenuRegistrarView().setVisible(true);
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Error al registrar en la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "La cédula debe ser numérica.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}