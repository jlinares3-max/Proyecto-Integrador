package com.modelo;

public class Recolector {
    private long documento;
    private String credencial;
    private String nombre;
    private String apellido;

    public Recolector() {}

    public Recolector(long documento, String credencial, String nombre, String apellido) {
        this.documento = documento;
        this.credencial = credencial;
        this.nombre = nombre;
        this.apellido = apellido;
    }

    // Getters y Setters
    public long getDocumento() { return documento; }
    public void setDocumento(long documento) { this.documento = documento; }

    public String getCredencial() { return credencial; }
    public void setCredencial(String credencial) { this.credencial = credencial; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getApellido() { return apellido; }
    public void setApellido(String apellido) { this.apellido = apellido; }
}