package com.modelo;

public class Vivienda {
    private long idVivienda;
    private String direccion;
    private long cantHogares;
    private String estado;
    private long idBarrio;

    public Vivienda() {}

    // Getters y Setters
    public long getIdVivienda() { return idVivienda; }
    public void setIdVivienda(long idVivienda) { this.idVivienda = idVivienda; }

    public String getDireccion() { return direccion; }
    public void setDireccion(String direccion) { this.direccion = direccion; }

    public long getCantHogares() { return cantHogares; }
    public void setCantHogares(long cantHogares) { this.cantHogares = cantHogares; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public long getIdBarrio() { return idBarrio; }
    public void setIdBarrio(long idBarrio) { this.idBarrio = idBarrio; }
}