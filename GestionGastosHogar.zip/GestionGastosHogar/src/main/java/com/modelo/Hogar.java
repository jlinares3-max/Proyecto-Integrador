package com.modelo;

import java.util.Date;

public class Hogar {
    private long idHogar;
    private long totalPersonas;
    private long idVivienda;
    private Long documentoRecolector;
    private Date fechaInicio;
    private Date fechaFin;
    private Date fechaPrimeraVisita;

    public Hogar() {}

    // Getters y Setters
    public long getIdHogar() { return idHogar; }
    public void setIdHogar(long idHogar) { this.idHogar = idHogar; }

    public long getTotalPersonas() { return totalPersonas; }
    public void setTotalPersonas(long totalPersonas) { this.totalPersonas = totalPersonas; }

    public long getIdVivienda() { return idVivienda; }
    public void setIdVivienda(long idVivienda) { this.idVivienda = idVivienda; }

    public Long getDocumentoRecolector() { return documentoRecolector; }
    public void setDocumentoRecolector(Long documentoRecolector) { this.documentoRecolector = documentoRecolector; }

    public Date getFechaInicio() { return fechaInicio; }
    public void setFechaInicio(Date fechaInicio) { this.fechaInicio = fechaInicio; }

    public Date getFechaFin() { return fechaFin; }
    public void setFechaFin(Date fechaFin) { this.fechaFin = fechaFin; }

    public Date getFechaPrimeraVisita() { return fechaPrimeraVisita; }
    public void setFechaPrimeraVisita(Date fechaPrimeraVisita) { this.fechaPrimeraVisita = fechaPrimeraVisita; }
}