package com.modelo;

import java.util.Date;

public class Gasto {
    private long idGasto;
    private String articulo;
    private double cantidad;
    private double valorProducto;
    private Date fechaRegistro;
    private String estado;
    private long idHogar;
    private String idEncuestado;
    private long idLugar;
    private long idForma;
    private long idTipo;
    private long idUnidad;
    private long idFrecuencia;
    private Long documentoRecolector;
    private Date fechaModificacion;
    private String modificacion;

    public Gasto() {}

    // Getters y Setters
    public long getIdGasto() { return idGasto; }
    public void setIdGasto(long idGasto) { this.idGasto = idGasto; }

    public String getArticulo() { return articulo; }
    public void setArticulo(String articulo) { this.articulo = articulo; }

    public double getCantidad() { return cantidad; }
    public void setCantidad(double cantidad) { this.cantidad = cantidad; }

    public double getValorProducto() { return valorProducto; }
    public void setValorProducto(double valorProducto) { this.valorProducto = valorProducto; }

    public Date getFechaRegistro() { return fechaRegistro; }
    public void setFechaRegistro(Date fechaRegistro) { this.fechaRegistro = fechaRegistro; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public long getIdHogar() { return idHogar; }
    public void setIdHogar(long idHogar) { this.idHogar = idHogar; }

    public String getIdEncuestado() { return idEncuestado; }
    public void setIdEncuestado(String idEncuestado) { this.idEncuestado = idEncuestado; }

    public long getIdLugar() { return idLugar; }
    public void setIdLugar(long idLugar) { this.idLugar = idLugar; }

    public long getIdForma() { return idForma; }
    public void setIdForma(long idForma) { this.idForma = idForma; }

    public long getIdTipo() { return idTipo; }
    public void setIdTipo(long idTipo) { this.idTipo = idTipo; }

    public long getIdUnidad() { return idUnidad; }
    public void setIdUnidad(long idUnidad) { this.idUnidad = idUnidad; }

    public long getIdFrecuencia() { return idFrecuencia; }
    public void setIdFrecuencia(long idFrecuencia) { this.idFrecuencia = idFrecuencia; }

    public Long getDocumentoRecolector() { return documentoRecolector; }
    public void setDocumentoRecolector(Long documentoRecolector) { this.documentoRecolector = documentoRecolector; }

    public Date getFechaModificacion() { return fechaModificacion; }
    public void setFechaModificacion(Date fechaModificacion) { this.fechaModificacion = fechaModificacion; }

    public String getModificacion() { return modificacion; }
    public void setModificacion(String modificacion) { this.modificacion = modificacion; }
}