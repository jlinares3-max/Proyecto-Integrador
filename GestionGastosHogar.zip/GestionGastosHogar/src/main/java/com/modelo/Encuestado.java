package com.modelo;

import java.util.Date;

public class Encuestado {
    private String documento;
    private String nombre;
    private String apellido;
    private String parentesco;
    private long telefono;
    private String correo;
    private long idHogar;
    private long idDispositivo;
    private Date fechaEntrega;
    private Date fechaRecogida;

    public Encuestado() {}

    // Getters y Setters
    public String getDocumento() { return documento; }
    public void setDocumento(String documento) { this.documento = documento; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getApellido() { return apellido; }
    public void setApellido(String apellido) { this.apellido = apellido; }

    public String getParentesco() { return parentesco; }
    public void setParentesco(String parentesco) { this.parentesco = parentesco; }

    public long getTelefono() { return telefono; }
    public void setTelefono(long telefono) { this.telefono = telefono; }

    public String getCorreo() { return correo; }
    public void setCorreo(String correo) { this.correo = correo; }

    public long getIdHogar() { return idHogar; }
    public void setIdHogar(long idHogar) { this.idHogar = idHogar; }

    public long getIdDispositivo() { return idDispositivo; }
    public void setIdDispositivo(long idDispositivo) { this.idDispositivo = idDispositivo; }

    public Date getFechaEntrega() { return fechaEntrega; }
    public void setFechaEntrega(Date fechaEntrega) { this.fechaEntrega = fechaEntrega; }

    public Date getFechaRecogida() { return fechaRecogida; }
    public void setFechaRecogida(Date fechaRecogida) { this.fechaRecogida = fechaRecogida; }
}