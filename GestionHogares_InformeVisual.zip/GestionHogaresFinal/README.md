# ENPH para NetBeans

Abre integrador como proyecto Maven con Java 21. Ejecuta control.Main.
Main conserva los bloques que coordinan procesos. Presentación captura y muestra
información, llama a Main, y Main llama a las clases de persistencia de cada tabla.
Java solo ejecuta llamadas a funciones y procedimientos Oracle; los disparadores
se ejecutan automáticamente en Oracle.

## Actualizar la base de datos

Como ENPH_ADMIGASCA:
- Si ya instalaste 01_conexion_netbeans.sql, ejecuta solo sql/03_roles_seguimiento_registros.sql.
- Si no lo instalaste, ejecuta 01_conexion_netbeans.sql y luego 03_roles_seguimiento_registros.sql.
- No hace falta ejecutar 02_consulta_hogares.sql para esta versión.
- Ejecuta sql/04_usuarios_demostracion.sql una sola vez para crear los accesos de ejemplo.
Los scripts requieren los procedimientos PRO_, funciones FUN_ y disparadores que
ya trabajamos. No importan el DMP ni reemplazan las tablas.
Al final de 03, USER_ERRORS debe devolver cero filas para los objetos NB_.
SHOW ERRORS muestra errores de compilación por objeto. Corrígelos antes de probar Java.

## Accesos de demostración (datos ficticios)
Recolector: recolector_demo / Recolector2026
Encuestado: encuestado_demo / Encuestado2026
El script crea ubicación, vivienda y hogar ficticios, asigna el recolector e inicia
el ciclo hoy. Genera ocho visitas mediante el procedimiento existente. No añade
gastos ni finaliza encuestas. Repetirlo no reemplaza las cuentas existentes.
El ejemplo completo con gastos reales se hará después.

## Menús
Administrador: Registrar vivienda; Registrar hogar y encuestado; Registrar
recolector; Asignar hogar e iniciar encuesta; Registros.
Registros consulta, edita y elimina viviendas, hogares, recolectores, encuestados
y usuarios. Identificadores, roles y estados del ciclo no se cambian manualmente.
No muestra contraseñas. La eliminación rechaza registros relacionados; no borra en
cascada. Los datos de vivienda incluyen barrio y cantidad de hogares, hogar incluye
total de personas y vivienda, personas incluyen datos de contacto, y usuario su login.

Recolector: Seguimiento; Finalizar encuesta e informe.
Seguimiento muestra visitas PENDIENTE de hoy, según la fecha del servidor Oracle,
de sus hogares con encuesta PROCESO. Seleccionar una permite guardar observaciones,
consultar/corregir/revisar gastos de ese hogar y marcar la visita REALIZADA. Al
marcarla, se guardan sus observaciones y desaparece de pendientes. Las visitas de
otros días no se muestran en esta pantalla, conforme al alcance acordado.
Finalizar muestra encuestas de sus hogares con fecha de cierre alcanzada y sin
gastos pendientes, junto con las finalizadas. Solo permite generar PDF si ya está
FINALIZADO. El cierre se valida nuevamente en Oracle.

Encuestado: Registrar gasto; Consultar mis gastos. No edita ni elimina gastos.
Los cambios del recolector dejan el gasto PENDIENTE hasta que lo marque REVISADO.

## Conexión interna
ConexionOracle.java contiene URL y claves técnicas por rol (las del CREATE USER
compartido). XE es el servicio de ejemplo: conserva el servicio que funciona en tu
laptop si es diferente. No hay configuración de conexión visible en las pantallas.
El login personal se verifica mediante función Oracle usando la conexión inicial
US_RECOLECTOR. Después se conecta con el usuario técnico del rol validado.
Una lectura de credenciales no activa un disparador DML.

## Verificación y límites
Java compilado con Java 21. Pruebas de llamadas JDBC con controlador simulado.
No se ha ejecutado contra el Oracle de tu laptop: esa validación sigue pendiente.
Las listas usan funciones SYS_REFCURSOR leídas como ResultSet; este mecanismo de
integración debe revisarse respecto al contenido de clase.
El cierre conserva las condiciones acordadas (fecha y cero gastos pendientes).
No hay aún registro explícito de días sin compras: cero gastos pendientes no
certifica por sí solo que se informaron los 14 días.
El catálogo de artículos/unidades/formas/lugares debe tener datos para registrar
gastos; su alta desde la interfaz sigue pendiente.
Los permisos de esta actualización se aplican a las llamadas NB_. Cualquier permiso
directo o EXECUTE anterior sobre PRO_ debe revisarse en Oracle antes de uso real.

## Ajuste visual de Registros
Ejecuta sql/05_registros_sin_identificadores.sql después de 03. Registros oculta las claves y documentos de identificación, muestra barrio y dirección de vivienda. La edición usa desplegables para esas relaciones. Todas las ventanas abiertas desde el menú tienen Cerrar abajo. Borrar fila elimina el registro seleccionado con confirmación y validación de relaciones, solo en Registros del administrador.

## GestionHogaresFinal
Ejecutar sql/06_registros_integrados.sql después de las actualizaciones anteriores. Hogares se consulta desde Viviendas, Encuestados o Recolectores. Encuestados muestra Dirección. Cuentas personales se editan desde cada persona; Administrador conserva sección propia.

## Opciones Otro
Ejecutar sql/07_catalogos_otro.sql como ENPH_ADMIGASCA. Registrar y editar gasto permiten Otro junto a artículo, unidad, forma y lugar. La caja contigua se habilita al seleccionarlo. Guardar gasto registra las opciones nuevas y el gasto juntos; ante error se revierte todo. Reutiliza nombres existentes ignorando mayúsculas y espacios extremos.
