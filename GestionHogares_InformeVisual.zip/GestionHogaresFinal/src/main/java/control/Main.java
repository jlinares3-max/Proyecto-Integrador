package control;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.io.File;
import negocio.Sesion;
import negocio.Sesion.Rol;
import negocio.Visita;
import negocio.OpcionCatalogo;
import persistencia.*;
import presentacion.PresentacionInicio;
import presentacion.PresentacionAplicacion;
import presentacion.MenuRol;

public class Main {
    public static void main(String[] args) {
        PresentacionAplicacion.iniciar();
    }

    public static void mostrarInicio() {
        PresentacionAplicacion.mostrarInicio();
    }

    // Capturar credenciales, validar en Oracle y presentar el menú.
    public static void iniciarSesion(PresentacionInicio presentacion) {
        String usuario = presentacion.capturarUsuario();
        String clave = presentacion.capturarClave();
        try {
            if (usuario.isBlank() || clave.isEmpty()) {
                presentacion.presentarMensaje("Escribe tu usuario y contraseña.");
                return;
            }
            Sesion sesion = new PersistenciaUsuario().iniciarSesion(usuario.trim(), clave);
            if (sesion == null) {
                presentacion.presentarMensaje("Usuario o contraseña incorrectos.");
                return;
            }
            PresentacionAplicacion.presentarMenu(sesion);
            presentacion.cerrar();
        } catch (SQLException error) {
            presentacion.presentarError(error);
        } finally {
            presentacion.limpiarClave();
        }
    }

    public static void cerrarSesion(MenuRol menu) {
        ConexionOracle.cerrarSesion();
        PresentacionAplicacion.cerrarSesion(menu);
        mostrarInicio();
    }

    // Consultar gastos y habilitar las acciones correspondientes al rol.
    public static void abrirGastos(MenuRol menu, Sesion sesion) {
        PresentacionAplicacion.abrirGastos(menu, sesion);
    }

    public static void abrirRegistro(MenuRol menu, String tipo) {
        PresentacionAplicacion.abrirRegistro(menu, tipo);
    }
    public static void abrirAsignacion(MenuRol menu) {
        PresentacionAplicacion.abrirAsignacion(menu);
    }
    public static void abrirVisitas(MenuRol menu, Sesion sesion) {
        PresentacionAplicacion.abrirVisitas(menu, sesion);
    }
    public static void abrirGasto(MenuRol menu, Sesion sesion, BigDecimal gasto) {
        PresentacionAplicacion.abrirGasto(menu, sesion, gasto);
    }
    public static void guardarInforme(File archivo, String texto) throws Exception {
        presentacion.InformePdf.guardar(archivo, texto);
    }

    // Proceso de listarViviendas.
    public static List<OpcionCatalogo> listarViviendas() throws SQLException {
        return new PersistenciaVivienda().listar();
    }

    // Proceso de registrarVivienda.
    public static void registrarVivienda(String direccion, BigDecimal barrio, int hogares) throws SQLException {
        new PersistenciaVivienda().registrar(direccion, barrio, hogares);
    }

    // Proceso de registrarRecolector.
    public static void registrarRecolector(BigDecimal documento, String nombre, String apellido, String telefono,
                          String login, String clave) throws SQLException {
        new PersistenciaRecolector().registrar(documento, nombre, apellido, telefono, login, clave);
    }

    // Proceso de listarRecolectores.
    public static List<OpcionCatalogo> listarRecolectores() throws SQLException {
        return new PersistenciaRecolector().listar();
    }

    // Asignar el recolector e iniciar el ciclo con ocho visitas en una operación Oracle.
    public static void asignarHogar(BigDecimal hogar, BigDecimal recolector, LocalDate inicio) throws SQLException {
        new PersistenciaHogar().asignar(hogar, recolector, inicio);
    }

    // Proceso de listarHogaresPendientes.
    public static List<OpcionCatalogo> listarHogaresPendientes() throws SQLException {
        return new PersistenciaHogar().sinAsignar();
    }

    // Proceso de registrarHogar.
    public static void registrarHogar(BigDecimal vivienda, int personas, String documento, String nombre,
                          String apellido, String telefono, String correo,
                          String login, String clave) throws SQLException {
        new PersistenciaHogar().registrar(vivienda, personas, documento, nombre, apellido, telefono, correo, login, clave);
    }

    // Proceso de listarHogares.
    public static List<Object[]> listarHogares() throws SQLException {
        return new PersistenciaHogar().listarRegistros();
    }

    // Proceso de listarGastos.
    public static List<Object[]> listarGastos(Sesion sesion) throws SQLException {
        return new PersistenciaGastos().listar(sesion);
    }

    // Proceso de consultarGasto.
    public static Object[] consultarGasto(Sesion sesion, BigDecimal id) throws SQLException {
        return new PersistenciaGastos().detalle(sesion, id);
    }

    // Proceso de editarGasto.
    public static void editarGasto(Sesion sesion, BigDecimal id, BigDecimal cantidad, BigDecimal valor,
                       String frecuencia, OpcionCatalogo forma, OpcionCatalogo unidad,
                       OpcionCatalogo articulo, OpcionCatalogo lugar) throws SQLException {
        new PersistenciaGastos().editar(sesion, id, cantidad, valor, frecuencia, forma, unidad, articulo, lugar);
    }

    // Proceso de revisarGasto.
    public static void revisarGasto(Sesion sesion, BigDecimal gasto) throws SQLException {
        new PersistenciaGastos().revisar(sesion, gasto);
    }

    // Proceso de registrarGasto.
    public static void registrarGasto(Sesion sesion, BigDecimal cantidad, BigDecimal valor,
                          String frecuencia, OpcionCatalogo forma, OpcionCatalogo unidad,
                          OpcionCatalogo articulo, OpcionCatalogo lugar) throws SQLException {
        new PersistenciaGastos().registrar(sesion, cantidad, valor, frecuencia, forma, unidad, articulo, lugar);
    }

    // Proceso de cerrarEncuesta.
    public static void cerrarEncuesta(BigDecimal hogar) throws SQLException {
        new PersistenciaEncuesta().cerrar(hogar);
    }

    // Proceso de listarVisitas.
    public static List<Visita> listarVisitas(Sesion sesion) throws SQLException {
        return new PersistenciaVisita().listar(sesion);
    }

    // Proceso de guardarObservacion.
    public static void guardarObservacion(Sesion sesion, Visita visita, String nota) throws SQLException {
        new PersistenciaVisita().guardar(sesion, visita, nota);
    }

    // Proceso de consultarInforme.
    public static String consultarInforme(Sesion sesion, Visita visita) throws SQLException {
        return new PersistenciaVisita().informe(sesion, visita);
    }

    // Proceso de listarDepartamento.
    public static List<OpcionCatalogo> listarDepartamento(Rol rol) throws SQLException {
        return new PersistenciaDepartamento().listar(rol);
    }


    // Proceso de listarMunicipio.
    public static List<OpcionCatalogo> listarMunicipio(Rol rol) throws SQLException {
        return new PersistenciaMunicipio().listar(rol);
    }

    // Proceso de listarMunicipio.
    public static List<OpcionCatalogo> listarMunicipio(Rol rol, BigDecimal padre) throws SQLException {
        return new PersistenciaMunicipio().listar(rol, padre);
    }

    // Proceso de listarBarrio.
    public static List<OpcionCatalogo> listarBarrio(Rol rol) throws SQLException {
        return new PersistenciaBarrio().listar(rol);
    }

    // Proceso de listarBarrio.
    public static List<OpcionCatalogo> listarBarrio(Rol rol, BigDecimal padre) throws SQLException {
        return new PersistenciaBarrio().listar(rol, padre);
    }

    // Proceso de listarArticulo.
    public static List<OpcionCatalogo> listarArticulo(Rol rol) throws SQLException {
        return new PersistenciaArticulo().listar(rol);
    }


    // Proceso de listarUnidadMedida.
    public static List<OpcionCatalogo> listarUnidadMedida(Rol rol) throws SQLException {
        return new PersistenciaUnidadMedida().listar(rol);
    }


    // Proceso de listarFormaAdquisicion.
    public static List<OpcionCatalogo> listarFormaAdquisicion(Rol rol) throws SQLException {
        return new PersistenciaFormaAdquisicion().listar(rol);
    }


    // Proceso de listarLugarCompra.
    public static List<OpcionCatalogo> listarLugarCompra(Rol rol) throws SQLException {
        return new PersistenciaLugarCompra().listar(rol);
    }


    // Registros: capturar la seleccion, llamar la persistencia de cada tabla y actualizar la vista.
    public static void abrirRegistros(MenuRol menu) { PresentacionAplicacion.abrirRegistros(menu); }
    public static void abrirCierre(MenuRol menu, Sesion sesion) { PresentacionAplicacion.abrirCierre(menu, sesion); }
    public static List<Object[]> encuestasDisponibles() throws SQLException {
        return new PersistenciaEncuesta().disponibles();
    }
    public static String informeHogar(BigDecimal hogar) throws SQLException {
        return presentacion.InformeGastos.texto(new PersistenciaEncuesta().gastosInforme(hogar));
    }
    public static void realizarVisita(Sesion sesion, Visita visita, String nota) throws SQLException {
        new PersistenciaVisita().realizar(sesion, visita, nota);
    }
    public static void abrirGastosVisita(MenuRol menu, Visita visita) {
        PresentacionAplicacion.abrirGastosVisita(menu, visita);
    }
    public static List<Object[]> listarGastosHogar(Sesion sesion, BigDecimal hogar) throws SQLException {
        if (hogar == null) return listarGastos(sesion);
        return new PersistenciaGastos().listarHogar(sesion, hogar);
    }
    public static List<Object[]> listarRegistros(String tipo) throws SQLException {
        switch (tipo) {
            case "VIVIENDA": return new PersistenciaVivienda().registros();
            case "HOGAR": return new PersistenciaHogar().registros();
            case "RECOLECTOR": return new PersistenciaRecolector().registros();
            case "ENCUESTADO": return new PersistenciaEncuestado().registros();
            case "USUARIO": return new PersistenciaUsuario().registros();
            default: throw new SQLException("Tipo de registro no válido.");
        }
    }
    public static void editarRegistro(String tipo, String id, String[] valores) throws SQLException {
        switch (tipo) {
            case "VIVIENDA": new PersistenciaVivienda().editarRegistro(id, valores); return;
            case "HOGAR": new PersistenciaHogar().editarRegistro(id, valores); return;
            case "RECOLECTOR": new PersistenciaRecolector().editarRegistro(id, valores); return;
            case "ENCUESTADO": new PersistenciaEncuestado().editarRegistro(id, valores); return;
            case "USUARIO": new PersistenciaUsuario().editarRegistro(id, valores); return;
            default: throw new SQLException("Tipo de registro no válido.");
        }
    }
    public static void eliminarRegistro(String tipo, String id) throws SQLException {
        switch (tipo) {
            case "VIVIENDA": new PersistenciaVivienda().eliminarRegistro(id); return;
            case "HOGAR": new PersistenciaHogar().eliminarRegistro(id); return;
            case "RECOLECTOR": new PersistenciaRecolector().eliminarRegistro(id); return;
            case "ENCUESTADO": new PersistenciaEncuestado().eliminarRegistro(id); return;
            case "USUARIO": new PersistenciaUsuario().eliminarRegistro(id); return;
            default: throw new SQLException("Tipo de registro no válido.");
        }
    }
    // Guardar las opciones nuevas y el gasto en la misma transacción Oracle.
    public static void guardarGastoConOtros(Sesion sesion, BigDecimal gasto, BigDecimal cantidad,
            BigDecimal valor, String frecuencia, BigDecimal[] ids, String[] nombres, String tipo) throws SQLException {
        new PersistenciaGastos().guardarConOtros(sesion, gasto, cantidad, valor, frecuencia, ids, nombres, tipo);
    }
    public static void cambiarClaveUsuario(String id, String nueva) throws SQLException {
        new PersistenciaUsuario().cambiarClave(id, nueva);
    }
}
