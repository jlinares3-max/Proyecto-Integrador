package negocio;

// Clase padre: tiene los datos y las reglas que comparten el recolector y el encuestado
public class Persona {

    // Número de documento de identidad (también es el usuario y la contraseña)
    private long documento;
    // Nombres completos
    private String nombre;
    // Apellidos completos
    private String apellido;
    // Teléfono celular
    private String telefono;

    // Constructor: deja la persona con valores vacíos (sin void)
    public Persona() {
        this.documento = 0;
        this.nombre = "";
        this.apellido = "";
        this.telefono = "";
    }

    // Setters: guardan un valor en el objeto
    public void setDocumento(long pDocumento) {
        this.documento = pDocumento;
    }

    public void setNombre(String pNombre) {
        this.nombre = pNombre;
    }

    public void setApellido(String pApellido) {
        this.apellido = pApellido;
    }

    public void setTelefono(String pTelefono) {
        this.telefono = pTelefono;
    }

    // Getters: leen un valor del objeto
    public long getDocumento() {
        return this.documento;
    }

    public String getNombre() {
        return this.nombre;
    }

    public String getApellido() {
        return this.apellido;
    }

    public String getTelefono() {
        return this.telefono;
    }

    // Une nombre y apellido en una sola cadena (para mostrarlo en la ventana)
    public String getNombreApellido() {
        return this.nombre + " " + this.apellido;
    }
}