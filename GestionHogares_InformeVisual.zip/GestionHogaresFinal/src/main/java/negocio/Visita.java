package negocio;
import java.math.BigDecimal;
import java.time.LocalDate;
public record Visita(BigDecimal id, BigDecimal hogar, LocalDate fecha, String tipo,
                     String estado, String direccion, String observaciones, boolean informeDisponible) {}
