package negocio;
import java.math.BigDecimal;
public record Sesion(BigDecimal id, Rol rol, String login) {
    public enum Rol { ADMINISTRADOR, RECOLECTOR, ENCUESTADO }
}
