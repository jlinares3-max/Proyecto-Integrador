package negocio;
public class Recolector extends Persona {
    private String credencial;

    public Recolector() {
        super();
        this.credencial = "";
    }

    public void setCredencial(String pCredencial) {
        this.credencial = pCredencial;
    }

    public String getCredencial() {
        return this.credencial;
    }
}
