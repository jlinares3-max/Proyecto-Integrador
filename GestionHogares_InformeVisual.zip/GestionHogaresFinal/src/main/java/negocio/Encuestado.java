package negocio;
public class Encuestado extends Persona {

    public Encuestado() {
        super();
    }
}