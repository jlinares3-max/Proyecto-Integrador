package negocio;
import java.math.BigDecimal;
public record OpcionCatalogo(BigDecimal id, String nombre) {
    @Override public String toString() { return nombre; }
}
