package persistencia;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.math.BigDecimal;
import negocio.Sesion;

public class PersistenciaUsuario {
    public Sesion iniciarSesion(String login, String clave) throws SQLException {
        String rol;
        BigDecimal id;

        // Primera conexión para que Oracle valide el login y determine el rol.
        try (Connection conexion = new ConexionOracle().conectarLogin();
             CallableStatement enunciado = conexion.prepareCall(
                     "{? = call ENPH_ADMIGASCA.nb_rol_sesion(?, ?)}")) {
            enunciado.registerOutParameter(1, Types.VARCHAR);
            enunciado.setString(2, login);
            enunciado.setString(3, clave);
            enunciado.execute();
            rol = enunciado.getString(1);
        }
        if (rol == null) return null;

        Sesion.Rol rolUsuario;
        try {
            rolUsuario = Sesion.Rol.valueOf(rol);
        } catch (IllegalArgumentException error) {
            throw new SQLException("El usuario tiene un rol que no pertenece a la aplicación.", error);
        }
        ConexionOracle.recordar(login, clave, rolUsuario);

        // Segunda conexión con la cuenta Oracle correspondiente al rol obtenido.
        try (Connection conexion = new ConexionOracle().obtenerConexion(rolUsuario);
             CallableStatement enunciado = conexion.prepareCall(
                     "{? = call ENPH_ADMIGASCA.nb_validar_sesion(?, ?)}")) {
            enunciado.registerOutParameter(1, Types.NUMERIC);
            enunciado.setString(2, login);
            enunciado.setString(3, clave);
            enunciado.execute();
            id = enunciado.getBigDecimal(1);
            if (id == null) throw new SQLException("La sesión no pudo validarse.");
            return new Sesion(id, rolUsuario, login);
        } catch (SQLException error) {
            ConexionOracle.cerrarSesion();
            throw error;
        }
    }

    public java.util.List<Object[]> registros() throws java.sql.SQLException {
        return LlamadasOracle.filas(negocio.Sesion.Rol.ADMINISTRADOR, "nb_registros", "USUARIO");
    }
    public void editarRegistro(String id, String[] valores) throws java.sql.SQLException {
        LlamadasOracle.ejecutar(negocio.Sesion.Rol.ADMINISTRADOR, "nb_editar_registro", "USUARIO", id,
            valores[0], valores[1], valores[2], valores[3]);
    }
    public void eliminarRegistro(String id) throws java.sql.SQLException {
        LlamadasOracle.ejecutar(negocio.Sesion.Rol.ADMINISTRADOR, "nb_eliminar_registro", "USUARIO", id);
    }
    public void cambiarClave(String id, String nueva) throws SQLException {
        LlamadasOracle.ejecutar(Sesion.Rol.ADMINISTRADOR, "nb_cambiar_clave", new BigDecimal(id), nueva);
        if (new BigDecimal(id).compareTo(new BigDecimal("0")) > 0) {
            // Mantener la sesión si el administrador cambia su propia contraseña.
            try (Connection con = new ConexionOracle().obtenerConexion(Sesion.Rol.ADMINISTRADOR)) {
                Object actual = LlamadasOracle.funcion(con, "nb_id_sesion", Types.NUMERIC,
                    ConexionOracle.login(), nueva);
                if (actual != null && new BigDecimal(actual.toString()).compareTo(new BigDecimal(id)) == 0)
                    ConexionOracle.recordar(ConexionOracle.login(), nueva, Sesion.Rol.ADMINISTRADOR);
            }
        }
    }
}
