package persistencia;
import negocio.OpcionCatalogo;
import java.sql.SQLException;
import java.util.List;
import java.math.BigDecimal;
import negocio.Sesion.Rol;
public class PersistenciaLugarCompra {
    public List<OpcionCatalogo> listar(Rol rol) throws SQLException {
        return CatalogosOracle.listar(rol, "LUGAR_COMPRA", null);
    }
    public List<OpcionCatalogo> listar(Rol rol, BigDecimal padre) throws SQLException {
        return CatalogosOracle.listar(rol, "LUGAR_COMPRA", padre);
    }
}
