package persistencia;
import java.sql.*;
import java.util.*;
import negocio.*;
public class PersistenciaVisita {
    public List<Visita> listar(Sesion sesion) throws SQLException {
        List<Visita> visitas = new ArrayList<>();
        for (Object[] f : LlamadasOracle.filas(sesion.rol(), "nb_visitas")) {
            visitas.add(new Visita((java.math.BigDecimal) f[0], (java.math.BigDecimal) f[1],
                ((java.sql.Timestamp) f[2]).toLocalDateTime().toLocalDate(), (String) f[3],
                (String) f[4], (String) f[5], (String) f[6], ((Number) f[7]).intValue() == 1));
        }
        return visitas;
    }
    public void guardar(Sesion sesion, Visita visita, String nota) throws SQLException {
        LlamadasOracle.ejecutar(sesion.rol(), "nb_observar", visita.id(), nota);
    }
    public String informe(Sesion sesion, Visita visita) throws SQLException {
        try (Connection con = new ConexionOracle().obtenerConexion(sesion.rol())) {
            return (String) LlamadasOracle.funcion(con, "nb_informe", Types.VARCHAR, ConexionOracle.login(), ConexionOracle.clave(), visita.hogar());
        }
    }
    public void realizar(Sesion sesion, Visita visita, String nota) throws SQLException {
        LlamadasOracle.ejecutar(sesion.rol(), "nb_realizar_visita", visita.id(), nota);
    }
}
