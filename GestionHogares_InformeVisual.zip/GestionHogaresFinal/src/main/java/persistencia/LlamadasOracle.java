package persistencia;
import java.sql.*;
import java.util.*;
import negocio.Sesion.Rol;

public final class LlamadasOracle {
    private LlamadasOracle() {}
    static String llamada(String nombre, int cantidad, boolean funcion) {
        String parametros = String.join(",", Collections.nCopies(cantidad, "?"));
        return "{" + (funcion ? "? = " : "") + "call ENPH_ADMIGASCA." + nombre + "(" + parametros + ")}";
    }
    public static Object funcion(Connection con, String nombre, int tipo, Object... valores) throws SQLException {
        try (CallableStatement llamada = con.prepareCall(llamada(nombre, valores.length, true))) {
            llamada.registerOutParameter(1, tipo);
            for (int i = 0; i < valores.length; i++) llamada.setObject(i + 2, valores[i]);
            llamada.execute();
            return llamada.getObject(1);
        }
    }
    public static List<Object[]> filas(Rol rol, String nombre, Object... valores) throws SQLException {
        List<Object[]> filas = new ArrayList<>();
        try (Connection con = new ConexionOracle().obtenerConexion(rol);
             CallableStatement llamada = con.prepareCall(llamada(nombre, valores.length + 2, true))) {
            llamada.setString(2, ConexionOracle.login());
            llamada.setString(3, ConexionOracle.clave());
            llamada.registerOutParameter(1, -10); // Cursor devuelto por Oracle JDBC.
            for (int i = 0; i < valores.length; i++) llamada.setObject(i + 4, valores[i]);
            llamada.execute();
            try (ResultSet datos = (ResultSet) llamada.getObject(1)) {
                int columnas = datos.getMetaData().getColumnCount();
                while (datos.next()) {
                    Object[] fila = new Object[columnas];
                    for (int i = 0; i < columnas; i++) {
    int tipo = datos.getMetaData().getColumnType(i + 1);

    if (tipo == Types.TIMESTAMP || tipo == Types.DATE) {
        fila[i] = datos.getTimestamp(i + 1);
    } else {
        fila[i] = datos.getObject(i + 1);
    }
}
                    filas.add(fila);
                }
            }
        }
        return filas;
    }
    public static void ejecutar(Rol rol, String nombre, Object... valores) throws SQLException {
        try (Connection con = new ConexionOracle().obtenerConexion(rol)) {
            con.setAutoCommit(false);
            try (CallableStatement llamada = con.prepareCall(llamada(nombre, valores.length + 2, false))) {
                llamada.setString(1, ConexionOracle.login());
                llamada.setString(2, ConexionOracle.clave());
                for (int i = 0; i < valores.length; i++) llamada.setObject(i + 3, valores[i]);
                llamada.execute();
                con.commit();
            } catch (SQLException error) {
                con.rollback();
                throw error;
            }
        }
    }
}
