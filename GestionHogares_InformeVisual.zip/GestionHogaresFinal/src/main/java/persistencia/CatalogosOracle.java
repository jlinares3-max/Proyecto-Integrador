package persistencia;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.*;
import negocio.Sesion.Rol;
import negocio.OpcionCatalogo;
public class CatalogosOracle {
    static List<OpcionCatalogo> listar(Rol rol, String catalogo, BigDecimal padre) throws SQLException {
        List<OpcionCatalogo> opciones = new ArrayList<>();
        for (Object[] fila : LlamadasOracle.filas(rol, "nb_catalogo", catalogo, padre))
            opciones.add(new OpcionCatalogo((BigDecimal) fila[0], (String) fila[1]));
        return opciones;
    }
}
