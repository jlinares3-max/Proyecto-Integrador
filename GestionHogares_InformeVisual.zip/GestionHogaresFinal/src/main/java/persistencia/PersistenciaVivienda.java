package persistencia;
import negocio.OpcionCatalogo;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;
import negocio.Sesion.Rol;
public class PersistenciaVivienda {
    public List<OpcionCatalogo> listar() throws SQLException {
        return CatalogosOracle.listar(Rol.ADMINISTRADOR, "VIVIENDA", null);
    }
    public void registrar(String direccion, BigDecimal barrio, int hogares) throws SQLException {
        LlamadasOracle.ejecutar(Rol.ADMINISTRADOR, "nb_registrar_vivienda", direccion, barrio, hogares);
    }

    public java.util.List<Object[]> registros() throws java.sql.SQLException {
        return LlamadasOracle.filas(negocio.Sesion.Rol.ADMINISTRADOR, "nb_registros", "VIVIENDA");
    }
    public void editarRegistro(String id, String[] valores) throws java.sql.SQLException {
        LlamadasOracle.ejecutar(negocio.Sesion.Rol.ADMINISTRADOR, "nb_editar_registro", "VIVIENDA", id,
            valores[0], valores[1], valores[2], valores[3]);
    }
    public void eliminarRegistro(String id) throws java.sql.SQLException {
        LlamadasOracle.ejecutar(negocio.Sesion.Rol.ADMINISTRADOR, "nb_eliminar_registro", "VIVIENDA", id);
    }
}
