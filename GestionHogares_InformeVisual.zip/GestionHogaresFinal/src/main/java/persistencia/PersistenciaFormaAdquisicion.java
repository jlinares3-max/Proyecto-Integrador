package persistencia;
import negocio.OpcionCatalogo;
import java.sql.SQLException;
import java.util.List;
import java.math.BigDecimal;
import negocio.Sesion.Rol;
public class PersistenciaFormaAdquisicion {
    public List<OpcionCatalogo> listar(Rol rol) throws SQLException {
        return CatalogosOracle.listar(rol, "FORMA_ADQUISICION", null);
    }
    public List<OpcionCatalogo> listar(Rol rol, BigDecimal padre) throws SQLException {
        return CatalogosOracle.listar(rol, "FORMA_ADQUISICION", padre);
    }
}
