package persistencia;
import negocio.OpcionCatalogo;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;
import negocio.Sesion.Rol;
public class PersistenciaRecolector {
    public void registrar(BigDecimal documento, String nombre, String apellido, String telefono,
                          String login, String clave) throws SQLException {
        LlamadasOracle.ejecutar(Rol.ADMINISTRADOR, "nb_registrar_recolector",
                documento, nombre, apellido, new BigDecimal(telefono), login, clave);
    }
    public List<OpcionCatalogo> listar() throws SQLException {
        return CatalogosOracle.listar(Rol.ADMINISTRADOR, "RECOLECTOR", null);
    }

    public java.util.List<Object[]> registros() throws java.sql.SQLException {
        return LlamadasOracle.filas(negocio.Sesion.Rol.ADMINISTRADOR, "nb_registros", "RECOLECTOR");
    }
    public void editarRegistro(String id, String[] valores) throws java.sql.SQLException {
        LlamadasOracle.ejecutar(negocio.Sesion.Rol.ADMINISTRADOR, "nb_editar_registro", "RECOLECTOR", id,
            valores[0], valores[1], valores[2], valores[3]);
    }
    public void eliminarRegistro(String id) throws java.sql.SQLException {
        LlamadasOracle.ejecutar(negocio.Sesion.Rol.ADMINISTRADOR, "nb_eliminar_registro", "RECOLECTOR", id);
    }
}
