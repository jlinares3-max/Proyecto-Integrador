package persistencia;
import negocio.OpcionCatalogo;
import java.sql.SQLException;
import java.math.BigDecimal;
import java.util.List;
import negocio.Sesion;
public class PersistenciaGastos {
    public List<Object[]> listar(Sesion sesion) throws SQLException {
        return LlamadasOracle.filas(sesion.rol(), "nb_gastos");
    }
    public Object[] detalle(Sesion sesion, BigDecimal id) throws SQLException {
        List<Object[]> filas = LlamadasOracle.filas(sesion.rol(), "nb_gasto_detalle", id);
        if (filas.isEmpty()) throw new SQLException("El gasto ya no está disponible.");
        return filas.get(0);
    }
    public void editar(Sesion sesion, BigDecimal id, BigDecimal cantidad, BigDecimal valor,
                       String frecuencia, OpcionCatalogo forma, OpcionCatalogo unidad,
                       OpcionCatalogo articulo, OpcionCatalogo lugar) throws SQLException {
        LlamadasOracle.ejecutar(sesion.rol(), "nb_editar_gasto", id, cantidad, valor,
                frecuencia, forma.id(), unidad.id(), articulo.id(), lugar == null ? null : lugar.id());
    }
    public void revisar(Sesion sesion, BigDecimal gasto) throws SQLException {
        LlamadasOracle.ejecutar(sesion.rol(), "nb_revisar", gasto);
    }
    public void registrar(Sesion sesion, BigDecimal cantidad, BigDecimal valor,
                          String frecuencia, OpcionCatalogo forma, OpcionCatalogo unidad,
                          OpcionCatalogo articulo, OpcionCatalogo lugar) throws SQLException {
        LlamadasOracle.ejecutar(sesion.rol(), "nb_registrar_gasto",
                cantidad, valor, frecuencia, forma.id(), unidad.id(), articulo.id(),
                lugar == null ? null : lugar.id());
    }
    public List<Object[]> listarHogar(Sesion sesion, BigDecimal hogar) throws SQLException {
        return LlamadasOracle.filas(sesion.rol(), "nb_gastos_hogar", hogar);
    }
    public void guardarConOtros(Sesion sesion, BigDecimal gasto, BigDecimal cantidad, BigDecimal valor,
            String frecuencia, BigDecimal[] ids, String[] nombres, String tipo) throws SQLException {
        LlamadasOracle.ejecutar(sesion.rol(), "nb_gasto_con_otros", gasto, cantidad, valor, frecuencia,
            ids[0], nombres[0], ids[1], nombres[1], ids[2], nombres[2], ids[3], nombres[3], tipo);
    }
}
