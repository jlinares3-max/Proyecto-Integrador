package persistencia;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import negocio.Sesion.Rol;

public class ConexionOracle {
    // Ajustar aquí el servicio de la instalación de Oracle de la laptop.
    private final String url = "jdbc:oracle:thin:@//localhost:1521/XE";
    // Contraseñas del script CREATE USER compartido para este proyecto.
    private final String claveAdministrador = "us_administrador2026";
    private final String claveRecolector = "us_recolector2026";
    private final String claveEncuestado = "us_encuestado2026";

    private static Rol rolSesion;
    private static String loginSesion;
    private static String claveSesion;

    private Connection abrir(Rol rol) throws SQLException {
        String usuario;
        String contrasena;
        if (rol == Rol.ADMINISTRADOR) {
            usuario = "US_ADMINISTRADOR";
            contrasena = claveAdministrador;
        } else if (rol == Rol.RECOLECTOR) {
            usuario = "US_RECOLECTOR";
            contrasena = claveRecolector;
        } else {
            usuario = "US_ENCUESTADO";
            contrasena = claveEncuestado;
        }
        return DriverManager.getConnection(url, usuario, contrasena);
    }

    public Connection conectarLogin() throws SQLException {
        // Conexión inicial para llamar a la función que determina el rol.
        return abrir(Rol.RECOLECTOR);
    }

    public Connection obtenerConexion(Rol rol) throws SQLException {
        if (loginSesion == null) throw new SQLException("Inicia sesión para continuar.");
        if (rol != rolSesion) throw new SQLException("El rol no tiene permiso para esta operación.");
        return abrir(rol);
    }

    public static void recordar(String login, String clave, Rol rol) {
        rolSesion = rol;
        loginSesion = login;
        claveSesion = clave;
    }
    static String login() { return loginSesion; }
    static String clave() { return claveSesion; }
    public static void cerrarSesion() { loginSesion = null; claveSesion = null; rolSesion = null; }
}
