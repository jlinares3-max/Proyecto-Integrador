package persistencia;
import java.sql.*;
import negocio.Sesion;
public class PersistenciaEncuestado {
    public String documento(Sesion sesion) throws SQLException {
        try (Connection con = new ConexionOracle().obtenerConexion(sesion.rol())) {
            return (String) LlamadasOracle.funcion(con, "nb_documento_actual", Types.VARCHAR, ConexionOracle.login(), ConexionOracle.clave());
        }
    }

    public java.util.List<Object[]> registros() throws java.sql.SQLException {
        return LlamadasOracle.filas(negocio.Sesion.Rol.ADMINISTRADOR, "nb_registros", "ENCUESTADO");
    }
    public void editarRegistro(String id, String[] valores) throws java.sql.SQLException {
        LlamadasOracle.ejecutar(negocio.Sesion.Rol.ADMINISTRADOR, "nb_editar_registro", "ENCUESTADO", id,
            valores[0], valores[1], valores[2], valores[3]);
    }
    public void eliminarRegistro(String id) throws java.sql.SQLException {
        LlamadasOracle.ejecutar(negocio.Sesion.Rol.ADMINISTRADOR, "nb_eliminar_registro", "ENCUESTADO", id);
    }
}
