package persistencia;
import negocio.OpcionCatalogo;
import java.math.BigDecimal;
import java.sql.*;
import java.time.LocalDate;
import java.util.List;
import negocio.Sesion.Rol;
public class PersistenciaHogar {
    public void asignar(BigDecimal hogar, BigDecimal recolector, LocalDate inicio) throws SQLException {
        LlamadasOracle.ejecutar(Rol.ADMINISTRADOR, "nb_asignar", hogar, recolector, Date.valueOf(inicio));
    }
    public List<OpcionCatalogo> sinAsignar() throws SQLException {
        return CatalogosOracle.listar(Rol.ADMINISTRADOR, "HOGAR", null);
    }
    public void registrar(BigDecimal vivienda, int personas, String documento, String nombre,
                          String apellido, String telefono, String correo,
                          String login, String clave) throws SQLException {
        LlamadasOracle.ejecutar(Rol.ADMINISTRADOR, "nb_registrar_hogar",
                vivienda, personas, documento, nombre, apellido, new BigDecimal(telefono), correo, login, clave);
    }
    public List<Object[]> listarRegistros() throws SQLException {
        return LlamadasOracle.filas(Rol.ADMINISTRADOR, "nb_hogares");
    }

    public java.util.List<Object[]> registros() throws java.sql.SQLException {
        return LlamadasOracle.filas(negocio.Sesion.Rol.ADMINISTRADOR, "nb_registros", "HOGAR");
    }
    public void editarRegistro(String id, String[] valores) throws java.sql.SQLException {
        LlamadasOracle.ejecutar(negocio.Sesion.Rol.ADMINISTRADOR, "nb_editar_registro", "HOGAR", id,
            valores[0], valores[1], valores[2], valores[3]);
    }
    public void eliminarRegistro(String id) throws java.sql.SQLException {
        LlamadasOracle.ejecutar(negocio.Sesion.Rol.ADMINISTRADOR, "nb_eliminar_registro", "HOGAR", id);
    }
}
