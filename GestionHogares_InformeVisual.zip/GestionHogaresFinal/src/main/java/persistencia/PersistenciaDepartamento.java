package persistencia;
import negocio.OpcionCatalogo;
import java.sql.SQLException;
import java.util.List;
import java.math.BigDecimal;
import negocio.Sesion.Rol;
public class PersistenciaDepartamento {
    public List<OpcionCatalogo> listar(Rol rol) throws SQLException {
        return CatalogosOracle.listar(rol, "DEPARTAMENTO", null);
    }
    public List<OpcionCatalogo> listar(Rol rol, BigDecimal padre) throws SQLException {
        return CatalogosOracle.listar(rol, "DEPARTAMENTO", padre);
    }
}
