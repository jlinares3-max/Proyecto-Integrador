package persistencia;
import java.math.BigDecimal;
import java.sql.SQLException;
import negocio.Sesion.Rol;
public class PersistenciaEncuesta {
    public void cerrar(BigDecimal hogar) throws SQLException {
        LlamadasOracle.ejecutar(Rol.RECOLECTOR, "nb_cerrar", hogar);
    }
    public java.util.List<Object[]> disponibles() throws SQLException {
        return LlamadasOracle.filas(Rol.RECOLECTOR, "nb_encuestas_cierre");
    }
    public java.util.List<Object[]> gastosInforme(BigDecimal hogar) throws SQLException {
        return LlamadasOracle.filas(Rol.RECOLECTOR, "nb_reporte_gastos", hogar);
    }
    public String informe(BigDecimal hogar) throws SQLException {
        try (java.sql.Connection con = new ConexionOracle().obtenerConexion(Rol.RECOLECTOR)) {
            return (String) LlamadasOracle.funcion(con, "nb_informe", java.sql.Types.VARCHAR,
                ConexionOracle.login(), ConexionOracle.clave(), hogar);
        }
    }
}
