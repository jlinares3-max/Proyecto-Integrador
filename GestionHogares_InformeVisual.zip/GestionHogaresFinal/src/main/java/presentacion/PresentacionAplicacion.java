package presentacion;

import java.math.BigDecimal;
import javax.swing.*;
import java.awt.Dimension;
import negocio.Sesion;

public class PresentacionAplicacion {
    private static JFrame ventana;

    private static void mostrar(Pantalla pantalla) {
        if (ventana == null) {
            ventana = new JFrame("Gestión de hogares - ENPH");
            ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            ventana.setMinimumSize(new Dimension(800, 600));
            ventana.setSize(1100, 720);
            ventana.setLocationRelativeTo(null);
        }
        ventana.setContentPane(pantalla);
        ventana.revalidate();
        ventana.repaint();
        ventana.setVisible(true);
    }
    public static void iniciar() {
        SwingUtilities.invokeLater(() -> control.Main.mostrarInicio());
    }
    public static void mostrarInicio() {
        mostrar(new PresentacionInicio());
    }
    public static void presentarMenu(Sesion sesion) {
        MenuRol menu;
        if (sesion.rol() == Sesion.Rol.ADMINISTRADOR) {
            menu = new PresentacionAdministrador(sesion);
        } else if (sesion.rol() == Sesion.Rol.RECOLECTOR) {
            menu = new PresentacionRecolector(sesion);
        } else {
            menu = new PresentacionEncuestado(sesion);
        }
        mostrar(menu);
    }
    public static void cerrarSesion(MenuRol menu) { menu.limpiarNavegacion(); }
    public static void abrirRegistro(MenuRol menu, String tipo) {
        if (tipo.equals("VIVIENDA")) menu.abrir(new PresentacionRegistroVivienda());
        else if (tipo.equals("HOGAR")) menu.abrir(new PresentacionRegistroHogar());
        else if (tipo.equals("RECOLECTOR")) menu.abrir(new PresentacionRegistroRecolector());
    }
    public static void abrirGastos(MenuRol menu, Sesion sesion) {
        if (sesion.rol() == Sesion.Rol.ENCUESTADO) menu.verGastos("Mis gastos registrados");
        else if (sesion.rol() == Sesion.Rol.RECOLECTOR) menu.verGastos("Revisión de gastos de mis hogares");
        else menu.verGastos("Consulta de gastos de los hogares");
    }
    public static void abrirAsignacion(MenuRol menu) { menu.abrir(new PresentacionAsignacion()); }
    public static void abrirVisitas(MenuRol menu, Sesion sesion) { menu.abrir(new PresentacionVisitas(menu, sesion)); }
    public static void abrirGasto(MenuRol menu, Sesion sesion, BigDecimal gasto) {
        menu.abrir(new PresentacionRegistroGasto(sesion, gasto));
    }
    public static void abrirRegistros(MenuRol menu) { menu.abrir(new PresentacionRegistros()); }
    public static void abrirCierre(MenuRol menu, Sesion sesion) { menu.abrir(new PresentacionCierre()); }
    public static void abrirGastosVisita(MenuRol menu, negocio.Visita visita) {
        menu.verGastos("Gastos del hogar " + visita.hogar(), visita.hogar());
    }
}
