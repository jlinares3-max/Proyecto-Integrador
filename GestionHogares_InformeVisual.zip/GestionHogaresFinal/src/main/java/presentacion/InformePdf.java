package presentacion;

import java.awt.Color;
import java.io.File;
import java.nio.file.*;
import java.util.*;
import org.apache.pdfbox.pdmodel.*;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType0Font;

/** Diseño del documento. Recibe la información ya obtenida por Main. */
public final class InformePdf {
    private static final Color AZUL = new Color(24, 55, 91);
    private static final Color TEXTO = new Color(35, 49, 65);
    private static final Color GRIS = new Color(99, 113, 129);
    private static final Color FONDO = new Color(242, 246, 250);
    private static final Color LINEA = new Color(218, 227, 236);
    private final PDDocument documento;
    private final PDType0Font normal, negrita;
    private PDPageContentStream lienzo;
    private float y;
    private static final float M = 40, ANCHO = 515;

    private InformePdf(PDDocument documento) throws Exception {
        this.documento = documento;
        normal = PDType0Font.load(documento, InformePdf.class.getResourceAsStream("/fonts/DejaVuSans.ttf"));
        negrita = PDType0Font.load(documento, InformePdf.class.getResourceAsStream("/fonts/DejaVuSans-Bold.ttf"));
    }
    public static void guardar(File destino, String texto) throws Exception {
        Path temporal = Files.createTempFile(destino.toPath().toAbsolutePath().getParent(), "informe-", ".pdf");
        try (PDDocument documento = new PDDocument()) {
            InformePdf informe = new InformePdf(documento);
            try { informe.dibujar(texto); }
            finally { if (informe.lienzo != null) informe.lienzo.close(); }
            informe.lienzo = null;
            informe.pies();
            documento.getDocumentInformation().setTitle("ENPH | Informe de gastos del hogar");
            documento.save(temporal.toFile());
            Files.move(temporal, destino.toPath(), StandardCopyOption.REPLACE_EXISTING);
        } finally { Files.deleteIfExists(temporal); }
    }
    private void texto(String s, float x, float base, float tam, boolean bold, Color color) throws Exception {
        lienzo.setNonStrokingColor(color);
        lienzo.beginText(); lienzo.setFont(bold ? negrita : normal, tam);
        lienzo.newLineAtOffset(x, base); lienzo.showText(s); lienzo.endText();
    }
    private void caja(float x, float arriba, float ancho, float alto, Color color) throws Exception {
        lienzo.setNonStrokingColor(color); lienzo.addRect(x, arriba-alto, ancho, alto); lienzo.fill();
    }
    private void pagina() throws Exception {
        if (lienzo != null) lienzo.close();
        PDPage pagina = new PDPage(PDRectangle.A4); documento.addPage(pagina);
        lienzo = new PDPageContentStream(documento, pagina);
        caja(0, 842, 596, 106, AZUL);
        texto("ENPH  /  CUADERNILLO 2 URBANO", M, 811, 9, true, new Color(183, 208, 235));
        texto("Informe de gastos del hogar", M, 779, 22, true, Color.WHITE);
        texto("Registro y seguimiento de los gastos diarios", M, 755, 10, false, Color.WHITE);
        y = 715;
    }
    private void espacio(float alto) throws Exception { if (y-alto < 65) pagina(); }
    private List<String> envolver(String s, float ancho, float tam, boolean bold) throws Exception {
        List<String> lineas = new ArrayList<>();
        s = s.replace('\t', ' ').replaceAll("[\\p{Cntrl}]", " ");
        PDType0Font fuente = bold ? negrita : normal;
        while (fuente.getStringWidth(s)/1000*tam > ancho) {
            int corte=s.length();
            while(corte>1 && fuente.getStringWidth(s.substring(0,corte))/1000*tam>ancho) corte--;
            int blanco=s.lastIndexOf(' ',corte); if(blanco>0) corte=blanco;
            lineas.add(s.substring(0,corte)); s=s.substring(corte).stripLeading();
        }
        lineas.add(s); return lineas;
    }
    private void parrafo(String s, float tam, Color color) throws Exception {
        for(String linea:envolver(s,ANCHO,tam,false)) {
            espacio(tam+6); texto(linea,M,y,tam,false,color); y-=tam+6;
        }
    }
    private void titulo(String s) throws Exception {
        espacio(32); texto(s,M,y,12,true,AZUL); y-=22;
    }
    private void dato(String s) throws Exception {
        int corte=s.indexOf(':');
        String etiqueta=corte<0 ? "Información" : s.substring(0,corte);
        String valor=corte<0 ? s : s.substring(corte+1).trim();
        List<String> lineas=envolver(valor,ANCHO-166,9.5f,false);
        float alto=Math.max(27,lineas.size()*14+10);
        espacio(alto); caja(M,y+10,ANCHO,alto,FONDO);
        texto(etiqueta,M+10,y-5,9,true,GRIS);
        float base=y-5;
        for(String l:lineas){texto(l,M+164,base,9.5f,false,TEXTO);base-=14;}
        y-=alto+2;
    }
    private void totales(String personal, String hogar, String total, String registros) throws Exception {
        espacio(115); titulo("Resumen de gastos");
        String[] etiquetas={"PERSONAL","DEL HOGAR","TOTAL REGISTRADO"};
        String[] valores={personal,hogar,total};
        float ancho=(ANCHO-16)/3;
        for(int i=0;i<3;i++) {
            float x=M+i*(ancho+8); Color fondo=i==2 ? AZUL : FONDO;
            caja(x,y+8,ancho,62,fondo);
            texto(etiquetas[i],x+12,y-10,8,true,i==2 ? Color.WHITE : GRIS);
            float tam=15;
            while(negrita.getStringWidth(valores[i])/1000*tam>ancho-24 && tam>8)tam--;
            texto(valores[i],x+12,y-34,tam,true,i==2 ? Color.WHITE : AZUL);
        }
        y-=72; parrafo(registros,9,GRIS); y-=7;
    }
    private void dia(String s, float siguiente) throws Exception {
        espacio(36+siguiente); caja(M,y+9,ANCHO,29,AZUL);
        texto(s.replaceFirst("^Dia ","Día "),M+12,y-10,10,true,Color.WHITE); y-=34;
    }
    private float altoGasto(List<String> lineas) throws Exception {
        float alto=19;
        for(int i=0;i<lineas.size();i++) alto+=envolver(lineas.get(i),ANCHO-28,i==0?10:9,i==0).size()*14;
        return alto;
    }
    private void gasto(List<String> lineas, String dia) throws Exception {
        float alto=altoGasto(lineas);
        if(y-alto<65){pagina(); if(!dia.isEmpty())dia(dia+" (continuación)",alto);}
        caja(M,y+6,ANCHO,alto,FONDO);
        caja(M,y+6,3,alto,LINEA);
        float base=y-10;
        for(int i=0;i<lineas.size();i++) {
            String s=lineas.get(i); Color color=i==0 ? AZUL : TEXTO;
            // Resalta el estado sin alterar los datos del gasto.
            if(s.endsWith("PENDIENTE")) color=new Color(133,81,20);
            if(s.endsWith("REVISADO")) color=new Color(28,103,83);
            for(String l:envolver(s,ANCHO-28,i==0?10:9,i==0)) {
                texto(l,M+14,base,i==0?10:9,i==0,color);base-=14;
            }
        }
        y-=alto+8;
    }
    private void dibujar(String contenido) throws Exception {
        String[] lineas=contenido.split("\\R");
        String personal="-",hogar="-",total="-",registros="";
        int resumen=-1;
        for(int i=0;i<lineas.length;i++) {
            if(lineas[i].equals("RESUMEN")) resumen=i;
            if(resumen>=0) {
                if(lineas[i].startsWith("Personal: "))personal=lineas[i].substring(10);
                if(lineas[i].startsWith("Del hogar: "))hogar=lineas[i].substring(11);
                if(lineas[i].startsWith("Total registrado: "))total=lineas[i].substring(18);
                if(lineas[i].startsWith("Registros: "))registros=lineas[i];
            }
        }
        pagina();
        if(resumen>=0)totales(personal,hogar,total,registros);
        titulo("Información del hogar");
        String diaActual=""; boolean detalle=false;
        for(int i=0;i<lineas.length;i++) {
            String l=lineas[i].trim();
            if(l.isEmpty() || l.equals("INFORME DE GASTOS REGISTRADOS"))continue;
            if(l.equals("RESUMEN"))break;
            if(l.matches("^\\d+\\. .*")) {
                List<String> bloque=new ArrayList<>(); bloque.add(l);
                while(i+1<lineas.length && (lineas[i+1].startsWith("Fecha:") || lineas[i+1].startsWith("Cantidad:") || lineas[i+1].startsWith("Adquisición:")))bloque.add(lineas[++i]);
                gasto(bloque,diaActual);
            } else if(l.matches("^(Dia \\d+|Fuera del ciclo|Sin inicio) - .*")) {
                if(!detalle){y-=8;titulo("Detalle de los gastos");detalle=true;}
                diaActual=l;
                List<String> proximo=new ArrayList<>();
                for(int j=i+1;j<lineas.length && j<=i+4;j++)proximo.add(lineas[j]);
                dia(l,altoGasto(proximo));
            } else if(l.startsWith("Informe de avance") || l.startsWith("Encuesta finalizada") || l.startsWith("Incluye todos")) {
                parrafo(l,9,GRIS);
            } else if(l.startsWith("No hay gastos")) {
                titulo("Detalle de los gastos");parrafo(l,11,GRIS);
            } else { dato(l); }
        }
        y-=8;
        parrafo("Los valores corresponden al valor registrado de cada gasto; no se multiplican por la cantidad.",8,GRIS);
    }
    private void pies() throws Exception {
        for(int i=0;i<documento.getNumberOfPages();i++) {
            try(PDPageContentStream pie=new PDPageContentStream(documento,documento.getPage(i),PDPageContentStream.AppendMode.APPEND,true)) {
                lienzo=pie; caja(M,48,ANCHO,1,LINEA);
                texto("ENPH | Gastos diarios del hogar",M,30,8,false,GRIS);
                texto("Página "+(i+1)+" de "+documento.getNumberOfPages(),455,30,8,false,GRIS);
            }
        }
        lienzo=null;
    }
}
