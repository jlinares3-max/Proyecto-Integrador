package presentacion;

import java.awt.*;
import java.util.Arrays;
import javax.swing.*;

public class PresentacionInicio extends Pantalla {
    private final JTextField usuario = new JTextField(22);
    private final JPasswordField clave = new JPasswordField(22);

    public PresentacionInicio() {
        super("Gestión de hogares");
        JPanel tarjeta = new JPanel(new GridBagLayout());
        tarjeta.setBackground(Color.WHITE);
        tarjeta.setBorder(bordeTarjeta());
        tarjeta.setPreferredSize(new Dimension(380, 320));
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0; c.weightx = 1; c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(0, 0, 8, 0);
        JLabel titulo = new JLabel("Bienvenido");
        titulo.setFont(new Font("SansSerif", Font.BOLD, 23)); titulo.setForeground(TEXTO);
        tarjeta.add(titulo, c);
        JLabel ayuda = new JLabel("Ingrese sus datos para continuar");
        ayuda.setForeground(SECUNDARIO); c.gridy = 1; c.insets = new Insets(0, 0, 20, 0); tarjeta.add(ayuda, c);
        c.gridy = 2; c.insets = new Insets(0, 0, 6, 0); tarjeta.add(new JLabel("Usuario"), c);
        c.gridy = 3; c.insets = new Insets(0, 0, 14, 0); usuario.setPreferredSize(new Dimension(250, 34)); tarjeta.add(usuario, c);
        c.gridy = 4; c.insets = new Insets(0, 0, 6, 0); tarjeta.add(new JLabel("Contraseña"), c);
        c.gridy = 5; c.insets = new Insets(0, 0, 18, 0); clave.setPreferredSize(new Dimension(250, 34)); tarjeta.add(clave, c);
        c.gridy = 6; c.insets = new Insets(0, 0, 0, 0); tarjeta.add(opcion("Ingresar", () -> iniciar()), c);
        JPanel centro = new JPanel(new GridBagLayout());
        centro.setOpaque(false); centro.add(tarjeta);
        contenido.add(centro);
        usuario.addActionListener(e -> clave.requestFocusInWindow());
        clave.addActionListener(e -> iniciar());
    }

    private void iniciar() { control.Main.iniciarSesion(this); }
    public String capturarUsuario() { return usuario.getText(); }
    public String capturarClave() {
        char[] caracteres = clave.getPassword();
        try { return new String(caracteres); }
        finally { Arrays.fill(caracteres, '\0'); }
    }
    public void limpiarClave() { clave.setText(""); }
    public void presentarMensaje(String texto) { JOptionPane.showMessageDialog(this, texto); }
    public void presentarError(Exception error) { mostrarError(error); }
    public void cerrar() { limpiarClave(); }
}
