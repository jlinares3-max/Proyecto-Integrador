package presentacion;

import java.awt.*;
import java.io.File;
import java.math.BigDecimal;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;

class PresentacionCierre extends Pantalla {
    private final DefaultTableModel datos = tabla("ID", "Dirección", "Inicio", "Cierre previsto", "Estado", "Encuestado", "Personas", "Gastos pendientes", "Puede finalizar");
    private final JTable encuestas = new JTable(datos);
    private final JButton finalizar = new JButton("Finalizar encuesta");
    private final JButton informe = new JButton("Generar informe PDF");
    PresentacionCierre() {
        super("Hogares asignados: finalizar encuesta e informe de gastos");
        encuestas.removeColumn(encuestas.getColumnModel().getColumn(0));
        encuestas.moveColumn(4, 0);
        encuestas.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        for (int i=0; i<encuestas.getColumnCount(); i++)
            encuestas.getColumnModel().getColumn(i).setPreferredWidth(i<2 ? 190 : 120);
        contenido.add(new JScrollPane(encuestas));
        JPanel acciones = new JPanel();
        JButton actualizar = new JButton("Actualizar");
        acciones.add(actualizar); acciones.add(finalizar); acciones.add(informe);
        JPanel pie = new JPanel(new BorderLayout());
        pie.add(new JLabel("Finalizar requiere alcanzar el cierre previsto y revisar todos los gastos."), BorderLayout.NORTH);
        pie.add(acciones, BorderLayout.SOUTH);
        contenido.add(pie, BorderLayout.SOUTH);
        encuestas.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        encuestas.getSelectionModel().addListSelectionListener(e -> {
            int fila = encuestas.getSelectedRow();
            finalizar.setEnabled(fila >= 0 && "SI".equals(datos.getValueAt(fila, 8)));
            informe.setEnabled(fila >= 0);
        });
        actualizar.addActionListener(e -> cargar());
        finalizar.addActionListener(e -> finalizar());
        informe.addActionListener(e -> exportar());
        cargar();
    }
    private BigDecimal hogar() {
        int fila = encuestas.getSelectedRow();
        return fila < 0 ? null : (BigDecimal) datos.getValueAt(fila, 0);
    }
    private void cargar() {
        datos.setRowCount(0); finalizar.setEnabled(false); informe.setEnabled(false);
        try { for (Object[] fila : control.Main.encuestasDisponibles()) datos.addRow(fila); }
        catch (Exception error) { mostrarError(error); }
    }
    private void finalizar() {
        BigDecimal id = hogar(); if (id == null) return;
        if (JOptionPane.showConfirmDialog(this, "Finalizar la encuesta de este hogar?",
                "Confirmar cierre", JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION) return;
        try {
            control.Main.cerrarEncuesta(id); cargar();
            JOptionPane.showMessageDialog(this, "Encuesta finalizada. Selecciónala para generar su reporte.");
        } catch (Exception error) { mostrarError(error); }
    }
    private void exportar() {
        BigDecimal id = hogar(); if (id == null) return;
        try {
            String texto = control.Main.informeHogar(id);
            if (texto == null) { cargar(); JOptionPane.showMessageDialog(this, "El hogar ya no está asignado a este recolector. Actualiza la lista."); return; }
            JFileChooser destino = new JFileChooser();
            destino.setFileFilter(new FileNameExtensionFilter("Documento PDF", "pdf"));
            destino.setSelectedFile(new File("Informe_hogar_" + id + ".pdf"));
            if (destino.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;
            File archivo = destino.getSelectedFile();
            if (!archivo.getName().toLowerCase().endsWith(".pdf")) archivo = new File(archivo + ".pdf");
            if (archivo.exists() && JOptionPane.showConfirmDialog(this, "Reemplazar el archivo existente?",
                    "Guardar PDF", JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION) return;
            control.Main.guardarInforme(archivo, texto);
            JOptionPane.showMessageDialog(this, "Reporte guardado.");
        } catch (Exception error) { mostrarError(error); }
    }
}
