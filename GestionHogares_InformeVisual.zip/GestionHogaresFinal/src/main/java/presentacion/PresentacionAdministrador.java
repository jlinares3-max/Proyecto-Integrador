package presentacion;

import negocio.Sesion;

public class PresentacionAdministrador extends MenuRol {
    public PresentacionAdministrador(Sesion sesion) {
        super("Menú Administrador", sesion);
        opciones.add(opcion("Registrar vivienda", () -> control.Main.abrirRegistro(this, "VIVIENDA")));
        opciones.add(opcion("Registrar hogar y encuestado", () -> control.Main.abrirRegistro(this, "HOGAR")));
        opciones.add(opcion("Registrar recolector", () -> control.Main.abrirRegistro(this, "RECOLECTOR")));
        opciones.add(opcion("Asignar hogar e iniciar encuesta", () -> control.Main.abrirAsignacion(this)));
        opciones.add(opcion("Registros", () -> control.Main.abrirRegistros(this)));
    }
}
