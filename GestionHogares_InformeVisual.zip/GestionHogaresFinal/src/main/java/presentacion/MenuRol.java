package presentacion;

import java.awt.*;
import java.sql.SQLException;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import negocio.Sesion;

public class MenuRol extends Pantalla {
    final Sesion sesion;
    final JPanel opciones = new JPanel(new GridLayout(0, 3, 10, 8));
    private final JPanel areaTrabajo = new JPanel(new BorderLayout());
    private final java.util.Deque<VistaAnterior> historial = new java.util.ArrayDeque<>();
    private Pantalla actual;
    private final JButton volver = new JButton("← Volver");

    private static class VistaAnterior {
        final Pantalla vista;
        final Runnable actualizar;
        VistaAnterior(Pantalla vista, Runnable actualizar) { this.vista = vista; this.actualizar = actualizar; }
    }

    MenuRol(String titulo, Sesion sesion) {
        super(titulo + " - " + sesion.login());
        this.sesion = sesion;
        opciones.setOpaque(false);
        contenido.add(opciones, BorderLayout.NORTH);
        areaTrabajo.setOpaque(false);
        contenido.add(areaTrabajo, BorderLayout.CENTER);
        volver.addActionListener(e -> volver());
        JPanel pie = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        pie.setOpaque(false);
        pie.add(volver);
        volver.setVisible(false);
        pie.add(opcion("Cerrar sesión", () -> {
            control.Main.cerrarSesion(this);
        }));
        contenido.add(pie, BorderLayout.SOUTH);
        mostrarActual();
    }

    void abrir(Pantalla vista) { abrir(vista, null); }

    // Cada vista se muestra en el área central y conserva la navegación anterior.
    void abrir(Pantalla vista, Runnable actualizarAnterior) {
        if (actual != null) historial.push(new VistaAnterior(actual, actualizarAnterior));
        vista.prepararVistaInterna();
        actual = vista;
        mostrarActual();
    }

    void volver() {
        if (historial.isEmpty()) {
            actual = null;
        } else {
            VistaAnterior anterior = historial.pop();
            actual = anterior.vista;
            if (anterior.actualizar != null) anterior.actualizar.run();
        }
        mostrarActual();
    }

    void limpiarNavegacion() {
        historial.clear();
        actual = null;
        areaTrabajo.removeAll();
    }

    private void mostrarActual() {
        areaTrabajo.removeAll();
        if (actual == null) {
            JPanel bienvenida = new JPanel(new GridBagLayout());
            bienvenida.setBackground(Color.WHITE);
            bienvenida.setBorder(bordeTarjeta());
            JPanel mensaje = new JPanel(new GridLayout(0, 1, 0, 8));
            mensaje.setOpaque(false);
            JLabel titulo = new JLabel("Bienvenido al sistema", SwingConstants.CENTER);
            titulo.setFont(new Font("SansSerif", Font.BOLD, 21));
            titulo.setForeground(TEXTO);
            JLabel ayuda = new JLabel("Seleccione una opción del menú para comenzar.", SwingConstants.CENTER);
            ayuda.setForeground(SECUNDARIO);
            mensaje.add(titulo); mensaje.add(ayuda); bienvenida.add(mensaje);
            areaTrabajo.add(bienvenida, BorderLayout.CENTER);
        } else {
            areaTrabajo.add(actual, BorderLayout.CENTER);
        }
        volver.setVisible(actual != null);
        areaTrabajo.revalidate();
        areaTrabajo.repaint();
    }

    public void verGastos(String titulo) { verGastos(titulo, null); }

    public void verGastos(String titulo, java.math.BigDecimal hogar) {
        Pantalla vista = new Pantalla(titulo);
        DefaultTableModel datos = hogar == null
                ? tabla("ID", "Fecha", "Hogar", "Artículo", "Cantidad", "Valor", "Estado")
                : tabla("ID", "Fecha", "Hogar", "Artículo", "Cantidad", "Valor", "Estado", "Día del ciclo", "Tipo de gasto");
        try {
            for (Object[] fila : control.Main.listarGastosHogar(sesion, hogar)) datos.addRow(fila);
        } catch (SQLException error) {
            mostrarError(error);
            return;
        }
        JTable tablaGastos = new JTable(datos);
        if (hogar != null) {
            // IDs conservados en el modelo para editar/revisar, ocultos en pantalla.
            tablaGastos.removeColumn(tablaGastos.getColumnModel().getColumn(2));
            tablaGastos.removeColumn(tablaGastos.getColumnModel().getColumn(0));
            tablaGastos.moveColumn(5, 0);
            tablaGastos.moveColumn(6, 3);
            tablaGastos.getColumnModel().getColumn(0).setPreferredWidth(110);
            tablaGastos.getColumnModel().getColumn(1).setPreferredWidth(160);
        }
        vista.contenido.add(new JScrollPane(tablaGastos));
        JPanel accionesGastos = new JPanel();
        vista.contenido.add(accionesGastos, BorderLayout.SOUTH);
        JButton actualizar = new JButton("Actualizar gastos");
        actualizar.addActionListener(e -> {
            try {
                datos.setRowCount(0);
                for (Object[] registro : control.Main.listarGastosHogar(sesion, hogar)) datos.addRow(registro);
            } catch (SQLException error) { mostrarError(error); }
        });
        accionesGastos.add(actualizar);
        if (sesion.rol() == Sesion.Rol.RECOLECTOR) {
            JButton editar = new JButton("Editar gasto");
            editar.addActionListener(e -> {
                int fila = tablaGastos.getSelectedRow();
                if (fila < 0) return;
                java.math.BigDecimal id = (java.math.BigDecimal) datos.getValueAt(tablaGastos.convertRowIndexToModel(fila), 0);
                abrir(new PresentacionRegistroGasto(sesion, id), () -> actualizar.doClick());
            });
            accionesGastos.add(editar);
        }
        if (sesion.rol() == Sesion.Rol.RECOLECTOR) {
            JButton revisar = new JButton("Marcar como revisado");
            revisar.addActionListener(e -> {
                int fila = tablaGastos.getSelectedRow();
                if (fila < 0) return;
                try {
                    control.Main.revisarGasto(sesion, (java.math.BigDecimal) datos.getValueAt(fila, 0));
                    datos.setRowCount(0);
                    for (Object[] registro : control.Main.listarGastosHogar(sesion, hogar)) datos.addRow(registro);
                } catch (SQLException error) { mostrarError(error); }
            });
            accionesGastos.add(revisar);
        }
        abrir(vista);
    }
}
