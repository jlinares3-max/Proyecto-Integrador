package presentacion;
import negocio.OpcionCatalogo;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import javax.swing.*;

class PresentacionAsignacion extends Formulario {
    PresentacionAsignacion() {
        super("Asignar hogar");
        JComboBox<OpcionCatalogo> hogares = new JComboBox<>();
        JComboBox<OpcionCatalogo> recolectores = new JComboBox<>();
        JTextField fecha = new JTextField(LocalDate.now().toString());
        campo("Hogar sin recolector", hogares);
        campo("Recolector", recolectores);
        campo("Fecha de la primera visita (AAAA-MM-DD)", fecha);
        try {
            for (OpcionCatalogo hogar : control.Main.listarHogaresPendientes()) hogares.addItem(hogar);
            for (OpcionCatalogo recolector : control.Main.listarRecolectores()) recolectores.addItem(recolector);
        } catch (SQLException error) {
            mostrarError(error);
        }
        accion("Asignar hogar", () -> {
            OpcionCatalogo hogar = (OpcionCatalogo) hogares.getSelectedItem();
            OpcionCatalogo recolector = (OpcionCatalogo) recolectores.getSelectedItem();
            if (hogar == null || recolector == null) {
                mensaje("Selecciona un hogar y un recolector.");
                return;
            }
            try {
                LocalDate inicio = LocalDate.parse(fecha.getText().trim());
                if (inicio.isBefore(LocalDate.now())) {
                    mensaje("La primera visita no puede ser anterior a hoy."); return;
                }
                control.Main.asignarHogar(hogar.id(), recolector.id(), inicio);
                hogares.removeItem(hogar);
                mensaje("Hogar asignado.");
            } catch (DateTimeParseException error) {
                mensaje("Escribe la fecha con el formato AAAA-MM-DD.");
            } catch (SQLException error) {
                mostrarError(error);
            }
        });
    }
}
