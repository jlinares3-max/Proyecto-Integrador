package presentacion;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

class PresentacionRegistros extends Pantalla {
    private final JComboBox<String> tipo = new JComboBox<>(new String[]{"VIVIENDA", "ENCUESTADO", "RECOLECTOR", "ADMINISTRADOR"});
    private final JTable registros = new JTable();
    private String[] columnas;
    private java.util.List<Object[]> filas = java.util.List.of();
    PresentacionRegistros() { this(null, null, null); }
    PresentacionRegistros(String seccion, Object padre, String origen) {
        super("Registros del administrador");
        contenido.add(tipo, BorderLayout.NORTH);
        contenido.add(new JScrollPane(registros));
        registros.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JPanel botones = new JPanel();
        JButton actualizar = new JButton("Actualizar");
        JButton editar = new JButton("Editar registro");
        JButton eliminar = new JButton("Borrar fila");
        botones.add(actualizar); botones.add(editar); botones.add(eliminar);
        JButton hogares = new JButton("Ver hogares");
        JButton cuenta = new JButton("Editar usuario de acceso");
        botones.add(hogares); botones.add(cuenta);
        JButton clave = new JButton("Cambiar contraseña");
        botones.add(clave);
        clave.setEnabled(false);
        tipo.addActionListener(e -> clave.setEnabled(tipo().equals("USUARIO") || tipo().equals("ADMINISTRADOR") || tipo().equals("ENCUESTADO") || tipo().equals("RECOLECTOR")));
        clave.addActionListener(e -> cambiarClave());
        hogares.addActionListener(e -> {
            int n = registros.getSelectedRow(); if (n < 0) return;
            Object[] fila = filas.get(registros.convertRowIndexToModel(n));
            if (tipo().equals("VIVIENDA") || tipo().equals("RECOLECTOR") || tipo().equals("ENCUESTADO"))
                abrirDetalle(new PresentacionRegistros("HOGAR", tipo().equals("ENCUESTADO") ? fila[9] : fila[0], tipo()));
        });
        cuenta.addActionListener(e -> {
            int n = registros.getSelectedRow(); if (n < 0) return;
            Object[] fila = filas.get(registros.convertRowIndexToModel(n));
            if (tipo().equals("ENCUESTADO") || tipo().equals("RECOLECTOR"))
                abrirDetalle(new PresentacionRegistros("USUARIO", fila[tipo().equals("ENCUESTADO") ? 10 : 5], tipo()));
        });
        tipo.addActionListener(e -> {
            eliminar.setText("Borrar " + tipo().toLowerCase());
            hogares.setEnabled(tipo().equals("VIVIENDA") || tipo().equals("ENCUESTADO") || tipo().equals("RECOLECTOR"));
            cuenta.setEnabled(tipo().equals("ENCUESTADO") || tipo().equals("RECOLECTOR"));
        });
        eliminar.setText("Borrar vivienda");
        contenido.add(botones, BorderLayout.SOUTH);
        tipo.addActionListener(e -> cargar());
        actualizar.addActionListener(e -> cargar());
        editar.addActionListener(e -> editar());
        eliminar.addActionListener(e -> eliminar());
        if (seccion != null) {
            tipo.addItem(seccion); tipo.setSelectedItem(seccion); tipo.setEnabled(false);
            this.padre = padre; this.origen = origen;
        }
        cargar();
    }
    private Object padre;
    private String origen;
    private String tipo() { return (String) tipo.getSelectedItem(); }
    private void cargar() {
        switch (tipo()) {
            case "VIVIENDA": columnas = new String[]{"ID", "Dirección", "Barrio", "Cantidad hogares", "Municipio", "Departamento"}; break;
            case "HOGAR": columnas = new String[]{"ID", "Total personas", "Dirección", "Estado", "Encuestado", "Recolector"}; break;
            case "RECOLECTOR": columnas = new String[]{"Documento", "Nombre", "Apellido", "Teléfono", "Usuario"}; break;
            case "ENCUESTADO": columnas = new String[]{"Documento", "Nombre", "Apellido", "Teléfono", "Correo", "Usuario", "Dirección", "Total personas", "Estado del hogar", "Recolector"}; break;
            default: columnas = new String[]{"ID", "Usuario"};
        }
        DefaultTableModel modelo = tabla(columnas);
        registros.setModel(modelo);
        registros.removeColumn(registros.getColumnModel().getColumn(0));
        try {
            java.util.List<Object[]> encontrados = control.Main.listarRegistros(tipo().equals("ADMINISTRADOR") ? "USUARIO" : tipo());
            filas = new java.util.ArrayList<>();
            for (Object[] dato : encontrados) {
                if (tipo().equals("ADMINISTRADOR") && !"ADMINISTRADOR".equals(dato[2])) continue;
                if (padre != null) {
                    Object relacion = tipo().equals("USUARIO") ? dato[0]
                        : origen.equals("VIVIENDA") ? dato[2] : origen.equals("RECOLECTOR") ? dato[7] : dato[0];
                    if (relacion == null || !padre.toString().equals(relacion.toString())) continue;
                }
                filas.add(dato);
            }
            for (Object[] fila : filas) {
                Object[] visible = java.util.Arrays.copyOf(fila, columnas.length);
                if (tipo().equals("VIVIENDA")) { visible[2] = fila[4]; visible[4] = fila[5]; visible[5] = fila[6]; }
                if (tipo().equals("HOGAR")) { visible[2] = fila[3]; visible[3] = fila[4]; visible[4] = fila[5]; visible[5] = fila[6]; }
                if (tipo().equals("ENCUESTADO")) visible[9] = fila[11];
                modelo.addRow(visible);
            }
        } catch (Exception error) { mostrarError(error); }
    }
    private void editar() {
        int fila = registros.getSelectedRow();
        if (fila < 0) { JOptionPane.showMessageDialog(this, "Selecciona un registro."); return; }
        JPanel formulario = new JPanel(new GridLayout(0, 2, 8, 8));
        JTextField[] campos = new JTextField[tipo().equals("VIVIENDA") || tipo().equals("RECOLECTOR") ? 3 : tipo().equals("ENCUESTADO") ? 4 : tipo().equals("HOGAR") ? 2 : 1];
        for (int i = 0; i < campos.length; i++) {
            Object valor = filas.get(registros.convertRowIndexToModel(fila))[i + 1];
            campos[i] = new JTextField(valor == null ? "" : valor.toString(), 24);
            formulario.add(new JLabel(columnas[i + 1])); formulario.add(campos[i]);
        }
        JComboBox<negocio.OpcionCatalogo> relacion = new JComboBox<>();
        boolean tieneRelacion = tipo().equals("VIVIENDA") || tipo().equals("HOGAR");
        if (tieneRelacion) {
            try {
                java.util.List<negocio.OpcionCatalogo> opciones = tipo().equals("VIVIENDA")
                    ? control.Main.listarBarrio(negocio.Sesion.Rol.ADMINISTRADOR)
                    : control.Main.listarViviendas();
                Object actual = filas.get(registros.convertRowIndexToModel(fila))[2];
                for (negocio.OpcionCatalogo opcion : opciones) {
                    relacion.addItem(opcion);
                    if (opcion.id().compareTo((java.math.BigDecimal) actual) == 0) relacion.setSelectedItem(opcion);
                }
                formulario.remove(campos[1]);
                formulario.add(relacion, 3);
            } catch (Exception error) { mostrarError(error); return; }
        }
        MenuRol menu = obtenerMenu();
        if (menu == null) return;
        String tipoRegistro = tipo();
        String id = filas.get(registros.convertRowIndexToModel(fila))[0].toString();
        Pantalla editor = new Pantalla("Editar " + tipoRegistro.toLowerCase());
        editor.contenido.add(formulario, BorderLayout.NORTH);
        JButton guardar = new JButton("Guardar cambios");
        JPanel acciones = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        acciones.add(guardar);
        editor.contenido.add(acciones, BorderLayout.SOUTH);
        guardar.addActionListener(e -> {
            String[] valores = new String[4];
            for (int i = 0; i < campos.length; i++) valores[i] = campos[i].getText().trim();
            if (tieneRelacion) {
                negocio.OpcionCatalogo opcion = (negocio.OpcionCatalogo) relacion.getSelectedItem();
                if (opcion == null) { JOptionPane.showMessageDialog(editor, "Selecciona una opción."); return; }
                valores[1] = opcion.id().toPlainString();
            }
            try {
                control.Main.editarRegistro(tipoRegistro.equals("ADMINISTRADOR") ? "USUARIO" : tipoRegistro, id, valores);
                menu.volver();
                JOptionPane.showMessageDialog(PresentacionRegistros.this, "Registro actualizado.");
            } catch (Exception error) { editor.mostrarError(error); }
        });
        menu.abrir(editor, this::cargar);
    }
    private void eliminar() {
        int fila = registros.getSelectedRow();
        if (fila < 0) { JOptionPane.showMessageDialog(this, "Selecciona un registro."); return; }
        if (JOptionPane.showConfirmDialog(this,
                "Eliminar este registro? Solo se permite si no tiene datos relacionados.",
                "Confirmar eliminación", JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION) return;
        try {
            control.Main.eliminarRegistro(tipo().equals("ADMINISTRADOR") ? "USUARIO" : tipo(), filas.get(registros.convertRowIndexToModel(fila))[0].toString());
            cargar(); JOptionPane.showMessageDialog(this, "Registro eliminado.");
        } catch (Exception error) {
            JOptionPane.showMessageDialog(this, "No se pudo eliminar. Verifica si tiene datos relacionados.\n" + error.getMessage());
        }
    }
    private MenuRol obtenerMenu() {
        java.awt.Container padre = getParent();
        while (padre != null && !(padre instanceof MenuRol)) padre = padre.getParent();
        return (MenuRol) padre;
    }
    private void abrirDetalle(PresentacionRegistros vista) {
        MenuRol menu = obtenerMenu();
        if (menu != null) menu.abrir(vista, this::cargar);
    }
    private void cambiarClave() {
        int n = registros.getSelectedRow();
        if (n < 0) { JOptionPane.showMessageDialog(this, "Selecciona una persona o cuenta."); return; }
        Object[] fila = filas.get(registros.convertRowIndexToModel(n));
        Object id = tipo().equals("ENCUESTADO") ? fila[10] : tipo().equals("RECOLECTOR") ? fila[5] : fila[0];
        MenuRol menu = obtenerMenu();
        if (menu == null) return;
        JPasswordField nueva = new JPasswordField(20), confirmar = new JPasswordField(20);
        JPanel panel = new JPanel(new GridLayout(0, 2, 8, 8));
        panel.add(new JLabel("Nueva contraseña")); panel.add(nueva);
        panel.add(new JLabel("Confirmar contraseña")); panel.add(confirmar);
        Pantalla editor = new Pantalla("Cambiar contraseña");
        editor.contenido.add(panel, BorderLayout.NORTH);
        JButton guardar = new JButton("Actualizar contraseña");
        JPanel acciones = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        acciones.add(guardar); editor.contenido.add(acciones, BorderLayout.SOUTH);
        guardar.addActionListener(e -> {
            char[] a = nueva.getPassword(), b = confirmar.getPassword();
            try {
                if (a.length == 0 || !java.util.Arrays.equals(a, b)) {
                    JOptionPane.showMessageDialog(editor, "Escribe una contraseña y repítela igual."); return;
                }
                control.Main.cambiarClaveUsuario(id.toString(), new String(a));
                menu.volver();
                JOptionPane.showMessageDialog(PresentacionRegistros.this, "Contraseña actualizada.");
            } catch (Exception error) { editor.mostrarError(error); }
            finally { java.util.Arrays.fill(a, '\0'); java.util.Arrays.fill(b, '\0'); nueva.setText(""); confirmar.setText(""); }
        });
        menu.abrir(editor);
    }
}
