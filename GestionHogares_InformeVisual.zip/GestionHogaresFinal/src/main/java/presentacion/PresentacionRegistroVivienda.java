package presentacion;
import negocio.OpcionCatalogo;

import java.sql.SQLException;
import javax.swing.*;
import negocio.Sesion.Rol;

class PresentacionRegistroVivienda extends Formulario {
    private final JComboBox<OpcionCatalogo> departamentos = new JComboBox<>();
    private final JComboBox<OpcionCatalogo> municipios = new JComboBox<>();
    private final JComboBox<OpcionCatalogo> barrios = new JComboBox<>();

    PresentacionRegistroVivienda() {
        super("Registrar vivienda");
        JTextField direccion = new JTextField();
        JSpinner hogares = new JSpinner(new SpinnerNumberModel(1, 1, Integer.MAX_VALUE, 1));
        campo("Dirección", direccion);
        campo("Departamento", departamentos);
        campo("Municipio", municipios);
        campo("Barrio", barrios);
        campo("Cantidad de hogares", hogares);
        departamentos.addActionListener(e -> cargarMunicipios());
        municipios.addActionListener(e -> cargarBarrios());
        try {
            for (OpcionCatalogo item : control.Main.listarDepartamento(Rol.ADMINISTRADOR)) {
                departamentos.addItem(item);
            }
        } catch (SQLException error) {
            mostrarError(error);
        }
        accion("Guardar vivienda", () -> {
            OpcionCatalogo barrio = (OpcionCatalogo) barrios.getSelectedItem();
            if (direccion.getText().isBlank() || barrio == null) {
                mensaje("Escribe la dirección y selecciona el barrio.");
                return;
            }
            try {
                control.Main.registrarVivienda(direccion.getText().trim(), barrio.id(),
                        (Integer) hogares.getValue());
                mensaje("Vivienda registrada.");
                direccion.setText("");
            } catch (SQLException error) {
                mostrarError(error);
            }
        });
    }

    private void cargarMunicipios() {
        municipios.removeAllItems();
        OpcionCatalogo departamento = (OpcionCatalogo) departamentos.getSelectedItem();
        if (departamento == null) return;
        try {
            for (OpcionCatalogo item : control.Main.listarMunicipio(Rol.ADMINISTRADOR, departamento.id())) {
                municipios.addItem(item);
            }
        } catch (SQLException error) {
            mostrarError(error);
        }
    }

    private void cargarBarrios() {
        barrios.removeAllItems();
        OpcionCatalogo municipio = (OpcionCatalogo) municipios.getSelectedItem();
        if (municipio == null) return;
        try {
            for (OpcionCatalogo item : control.Main.listarBarrio(Rol.ADMINISTRADOR, municipio.id())) {
                barrios.addItem(item);
            }
        } catch (SQLException error) {
            mostrarError(error);
        }
    }
}
