package presentacion;

import negocio.Sesion;

public class PresentacionRecolector extends MenuRol {
    public PresentacionRecolector(Sesion sesion) {
        super("Menú Recolector", sesion);
        opciones.add(opcion("Seguimiento", () -> control.Main.abrirVisitas(this, sesion)));
        opciones.add(opcion("Finalizar encuesta e informe", () -> control.Main.abrirCierre(this, sesion)));
    }
}
