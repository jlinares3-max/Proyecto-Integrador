package presentacion;
import negocio.OpcionCatalogo;

import java.sql.SQLException;
import java.util.Arrays;
import javax.swing.*;

class PresentacionRegistroHogar extends Formulario {
    PresentacionRegistroHogar() {
        super("Registrar hogar y encuestado");
        JComboBox<OpcionCatalogo> viviendas = new JComboBox<>();
        JSpinner personas = new JSpinner(new SpinnerNumberModel(1, 1, Integer.MAX_VALUE, 1));
        JTextField documento = new JTextField();
        JTextField nombre = new JTextField();
        JTextField apellido = new JTextField();
        JTextField telefono = new JTextField();
        JTextField correo = new JTextField();
        JTextField login = new JTextField();
        JPasswordField clave = new JPasswordField();
        campo("Vivienda", viviendas);
        campo("Total de personas", personas);
        campo("Documento del encuestado", documento);
        campo("Nombre", nombre);
        campo("Apellido", apellido);
        campo("Teléfono", telefono);
        campo("Correo (opcional)", correo);
        campo("Usuario", login);
        campo("Contraseña", clave);
        try {
            for (OpcionCatalogo item : control.Main.listarViviendas()) viviendas.addItem(item);
        } catch (SQLException error) {
            mostrarError(error);
        }
        accion("Guardar hogar", () -> {
            OpcionCatalogo vivienda = (OpcionCatalogo) viviendas.getSelectedItem();
            char[] textoClave = clave.getPassword();
            try {
                if (vivienda == null || documento.getText().isBlank() || nombre.getText().isBlank()
                        || apellido.getText().isBlank() || !telefono.getText().trim().matches("[0-9]{1,15}")
                        || login.getText().isBlank() || textoClave.length == 0) {
                    mensaje("Completa los campos obligatorios y escribe un teléfono numérico.");
                    return;
                }
                control.Main.registrarHogar(vivienda.id(), (Integer) personas.getValue(),
                        documento.getText().trim(), nombre.getText().trim(), apellido.getText().trim(),
                        telefono.getText().trim(), correo.getText().trim(),
                        login.getText().trim(), new String(textoClave));
                mensaje("Hogar y encuestado registrados.");
                for (JTextField campo : new JTextField[]{documento, nombre, apellido, telefono, correo,
                        login, clave}) campo.setText("");
            } catch (SQLException error) {
                mostrarError(error);
            } finally {
                Arrays.fill(textoClave, '\0');
            }
        });
    }
}
