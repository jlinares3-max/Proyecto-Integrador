package presentacion;

import java.awt.*;
import javax.swing.*;

class Formulario extends Pantalla {
    private final JPanel campos = new JPanel(new GridBagLayout());
    private int fila;

    Formulario(String titulo) {
        super(titulo);
        campos.setBackground(Color.WHITE);
        campos.setBorder(bordeTarjeta());
        JPanel envoltura = new JPanel(new BorderLayout());
        envoltura.setBackground(FONDO);
        envoltura.add(campos, BorderLayout.NORTH);
        JScrollPane scroll = new JScrollPane(envoltura);
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(18);
        contenido.add(scroll, BorderLayout.CENTER);
    }

    void campo(String etiqueta, JComponent entrada) {
        JLabel nombre = new JLabel(etiqueta);
        nombre.setFont(new Font("SansSerif", Font.BOLD, 12));
        nombre.setForeground(TEXTO);
        GridBagConstraints c = new GridBagConstraints();
        c.gridy = fila++; c.gridx = 0;
        c.weightx = 0; c.fill = GridBagConstraints.HORIZONTAL;
        c.anchor = GridBagConstraints.NORTHWEST;
        c.insets = new Insets(5, 0, 9, 24);
        nombre.setPreferredSize(new Dimension(210, 30));
        campos.add(nombre, c);
        c.gridx = 1; c.weightx = 1; c.insets = new Insets(3, 0, 9, 0);
        entrada.setPreferredSize(new Dimension(260, 32));
        campos.add(entrada, c);
    }

    void accion(String texto, Runnable evento) {
        JPanel acciones = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        acciones.setOpaque(false);
        acciones.add(opcion(texto, evento));
        contenido.add(acciones, BorderLayout.SOUTH);
    }

    void mensaje(String texto) { JOptionPane.showMessageDialog(this, texto); }
}
