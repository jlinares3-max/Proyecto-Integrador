package presentacion;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;

/** Presenta los datos devueltos por Oracle; no ejecuta consultas. */
public final class InformeGastos {
    private InformeGastos() {}
    private static String valor(Object dato) { return dato == null ? "Sin dato" : dato.toString(); }
    private static BigDecimal numero(Object dato) {
        return dato == null ? BigDecimal.ZERO : new BigDecimal(dato.toString());
    }
    public static String texto(List<Object[]> filas) {
        if (filas.isEmpty()) return null;
        Object[] h = filas.get(0);
        StringBuilder texto = new StringBuilder();
        texto.append("INFORME DE GASTOS REGISTRADOS\n");
        texto.append("Generado: ").append(LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"))).append('\n');
        texto.append("Encuestado de referencia: ").append(valor(h[6])).append('\n');
        texto.append("Dirección: ").append(valor(h[0])).append('\n');
        texto.append("Personas del hogar: ").append(valor(h[1])).append('\n');
        texto.append("Recolector: ").append(valor(h[2])).append('\n');
        texto.append("Inicio: ").append(valor(h[3])).append(" | Cierre previsto: ").append(valor(h[4])).append('\n');
        texto.append("Estado de la encuesta: ").append(valor(h[5])).append('\n');
        texto.append("FINALIZADO".equals(h[5]) ? "Encuesta finalizada.\n" : "Informe de avance: no acredita la finalización de la encuesta.\n");
        texto.append("Incluye todos los gastos registrados del hogar, pendientes y revisados.\n\n");
        BigDecimal total=BigDecimal.ZERO, personal=BigDecimal.ZERO, hogar=BigDecimal.ZERO;
        int cantidad=0, pendientes=0;
        NumberFormat moneda=NumberFormat.getCurrencyInstance(Locale.forLanguageTag("es-CO"));
        String fechaAnterior="";
        for (Object[] g : filas) {
            if (g[7]==null) continue;
            String fecha=valor(g[8]);
            String dia=fecha.length()>=10 ? fecha.substring(0,10) : fecha;
            if (!dia.equals(fechaAnterior)) {
                texto.append("\n").append(valor(g[9])).append(" - ").append(dia).append('\n');
                fechaAnterior=dia;
            }
            cantidad++;
            BigDecimal importe=numero(g[14]);
            total=total.add(importe);
            if ("Personal".equals(g[11])) personal=personal.add(importe);
            if ("Del hogar".equals(g[11])) hogar=hogar.add(importe);
            if ("PENDIENTE".equals(g[15])) pendientes++;
            texto.append(cantidad).append(". ").append(valor(g[10])).append(" | ").append(valor(g[11])).append('\n');
            texto.append("Fecha: ").append(fecha).append(" | Registrado por: ").append(valor(g[16])).append('\n');
            texto.append("Cantidad: ").append(valor(g[12])).append(' ').append(valor(g[13]));
            texto.append(" | Valor: ").append(moneda.format(importe)).append(" | ").append(valor(g[15])).append('\n');
            texto.append("Adquisición: ").append(valor(g[17])).append(" | Lugar: ").append(valor(g[18])).append('\n');
        }
        if (cantidad==0) texto.append("No hay gastos registrados.\n");
        texto.append("\nRESUMEN\nRegistros: ").append(cantidad).append(" | Pendientes de revisión: ").append(pendientes).append('\n');
        texto.append("Personal: ").append(moneda.format(personal)).append('\n');
        texto.append("Del hogar: ").append(moneda.format(hogar)).append('\n');
        texto.append("Total registrado: ").append(moneda.format(total)).append('\n');
        texto.append("Los valores corresponden al valor registrado de cada gasto; no se multiplican por la cantidad.");
        return texto.toString();
    }
}
