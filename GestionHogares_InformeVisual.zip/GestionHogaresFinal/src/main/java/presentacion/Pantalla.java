package presentacion;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableModel;

class Pantalla extends JPanel {
    private final String titulo;
    private final JPanel encabezado = new JPanel(new BorderLayout(0, 4));
    private final JLabel marca = new JLabel("ENPH  /  CUADERNILLO 2 URBANO");
    private final JLabel nombre = new JLabel();
    static final Color AZUL = new Color(22, 53, 93);
    static final Color AZUL_CLARO = new Color(40, 100, 157);
    static final Color FONDO = new Color(242, 246, 250);
    static final Color TEXTO = new Color(32, 49, 68);
    static final Color SECUNDARIO = new Color(105, 121, 138);
    final JPanel contenido = new JPanel(new BorderLayout(12, 12));

    Pantalla(String titulo) {
        super(new BorderLayout());
        this.titulo = titulo;
        setBackground(FONDO);
        encabezado.setBackground(Color.WHITE);
        encabezado.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(220, 228, 237)),
                BorderFactory.createEmptyBorder(13, 24, 13, 24)));
        marca.setFont(new Font("SansSerif", Font.BOLD, 10));
        marca.setForeground(AZUL_CLARO);
        nombre.setText(titulo);
        nombre.setFont(new Font("SansSerif", Font.BOLD, 20));
        nombre.setForeground(TEXTO);
        encabezado.add(marca, BorderLayout.NORTH);
        encabezado.add(nombre, BorderLayout.CENTER);
        add(encabezado, BorderLayout.NORTH);
        contenido.setBackground(FONDO);
        contenido.setBorder(BorderFactory.createEmptyBorder(14, 24, 14, 24));
        add(contenido, BorderLayout.CENTER);
    }

    String getTitle() { return titulo; }

    void prepararVistaInterna() {
        marca.setVisible(false);
        nombre.setFont(new Font("SansSerif", Font.BOLD, 17));
        encabezado.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(220, 228, 237)),
            BorderFactory.createEmptyBorder(10, 18, 10, 18)));
        contenido.setBorder(BorderFactory.createEmptyBorder(10, 16, 8, 16));
    }

    JButton opcion(String texto, Runnable accion) {
        JButton boton = new JButton(texto);
        boton.setFont(new Font("SansSerif", Font.BOLD, 12));
        boton.setForeground(Color.WHITE);
        boton.setBackground(AZUL);
        boton.setOpaque(true);
        boton.setFocusPainted(false);
        boton.setBorder(BorderFactory.createEmptyBorder(12, 18, 12, 18));
        boton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        boton.addActionListener(e -> accion.run());
        return boton;
    }

    static Border bordeTarjeta() {
        return BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(222, 230, 238)),
            BorderFactory.createEmptyBorder(20, 22, 20, 22));
    }

    void mostrarError(Exception error) {
        JOptionPane.showMessageDialog(this, error.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }

    static DefaultTableModel tabla(String... columnas) {
        return new DefaultTableModel(columnas, 0) {
            @Override public boolean isCellEditable(int fila, int columna) { return false; }
        };
    }
}
