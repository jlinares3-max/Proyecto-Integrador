package presentacion;
import java.awt.*;
import java.io.File;
import java.sql.SQLException;
import java.util.List;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import negocio.*;

class PresentacionVisitas extends Pantalla {
    private final Sesion sesion;
    private final MenuRol menu;
    private final DefaultTableModel datos = tabla("Hogar", "Fecha", "Tipo", "Estado", "Dirección");
    private final JTable tablaVisitas = new JTable(datos);
    private final JTextArea observaciones = new JTextArea(4, 40);
    private final JButton guardar = new JButton("Guardar observaciones");
    private final JButton gastos = new JButton("Revisar gastos del hogar");
    private final JButton realizada = new JButton("Marcar visita como realizada");
    private List<Visita> visitas = List.of();

    PresentacionVisitas(MenuRol menu, Sesion sesion) {
        super("Seguimiento: visitas pendientes de hoy - " + sesion.login());
        this.menu = menu;
        this.sesion = sesion;
        contenido.add(new JScrollPane(tablaVisitas));
        JPanel detalle = new JPanel(new BorderLayout(8, 8));
        detalle.add(new JLabel("Observaciones de la visita seleccionada (hasta 300 caracteres)"), BorderLayout.NORTH);
        observaciones.setLineWrap(true);
        observaciones.setWrapStyleWord(true);
        detalle.add(new JScrollPane(observaciones));
        JPanel acciones = new JPanel();
        JButton actualizar = new JButton("Actualizar");
        actualizar.addActionListener(e -> cargar());
        acciones.add(actualizar);
        acciones.add(guardar);
        acciones.add(gastos);
        acciones.add(realizada);
        detalle.add(acciones, BorderLayout.SOUTH);
        contenido.add(detalle, BorderLayout.SOUTH);
        tablaVisitas.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tablaVisitas.getSelectionModel().addListSelectionListener(e -> {
            if (e.getValueIsAdjusting()) return;
            Visita visita = seleccionada();
            guardar.setEnabled(visita != null);
            gastos.setEnabled(visita != null);
            realizada.setEnabled(visita != null);
            observaciones.setEnabled(visita != null);
            observaciones.setText(visita == null ? "" : visita.observaciones());
        });
        guardar.addActionListener(e -> guardar());
        gastos.addActionListener(e -> {
            Visita v = seleccionada();
            if (v != null) control.Main.abrirGastosVisita(menu, v);
        });
        realizada.addActionListener(e -> realizar());
        cargar();
    }
    private Visita seleccionada() {
        int fila = tablaVisitas.getSelectedRow();
        return fila < 0 ? null : visitas.get(tablaVisitas.convertRowIndexToModel(fila));
    }
    private void cargar() {
        guardar.setEnabled(false);
        gastos.setEnabled(false);
        realizada.setEnabled(false);
        observaciones.setText("");
        observaciones.setEnabled(false);
        datos.setRowCount(0);
        visitas = List.of();
        try {
            visitas = control.Main.listarVisitas(sesion);
            for (Visita v : visitas)
                datos.addRow(new Object[]{v.hogar(), v.fecha(), v.tipo(), v.estado(), v.direccion()});
        } catch (SQLException error) { mostrarError(error); }
    }
    private void guardar() {
        Visita visita = seleccionada();
        if (visita == null) return;
        if (observaciones.getText().length() > 300) {
            JOptionPane.showMessageDialog(this, "Usa hasta 300 caracteres.");
            return;
        }
        try {
            control.Main.guardarObservacion(sesion, visita, observaciones.getText());
            cargar();
            JOptionPane.showMessageDialog(this, "Observaciones guardadas.");
        } catch (SQLException error) { mostrarError(error); }
    }
    private void realizar() {
        Visita v = seleccionada();
        if (v == null) return;
        if (observaciones.getText().length() > 300) {
            JOptionPane.showMessageDialog(this, "Usa hasta 300 caracteres."); return;
        }
        if (JOptionPane.showConfirmDialog(this, "Terminaste la revisión de esta visita? Se guardarán las observaciones y dejará de aparecer como pendiente.",
                "Completar visita", JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION) return;
        try {
            control.Main.realizarVisita(sesion, v, observaciones.getText());
            cargar();
            JOptionPane.showMessageDialog(this, "Visita realizada.");
        } catch (SQLException error) { mostrarError(error); }
    }
}
