package presentacion;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Arrays;
import javax.swing.*;

class PresentacionRegistroRecolector extends Formulario {
    PresentacionRegistroRecolector() {
        super("Registrar recolector");
        JTextField documento = new JTextField();
        JTextField nombre = new JTextField();
        JTextField apellido = new JTextField();
        JTextField telefono = new JTextField();
        JTextField login = new JTextField();
        JPasswordField clave = new JPasswordField();
        campo("Documento", documento);
        campo("Nombre", nombre);
        campo("Apellido", apellido);
        campo("Teléfono", telefono);
        campo("Usuario", login);
        campo("Contraseña", clave);
        accion("Guardar recolector", () -> {
            char[] textoClave = clave.getPassword();
            try {
                if (!documento.getText().trim().matches("[0-9]{1,20}") || nombre.getText().isBlank()
                        || !telefono.getText().matches("[0-9]{1,15}") || apellido.getText().isBlank() || login.getText().isBlank() || textoClave.length == 0) {
                    mensaje("Completa los campos y escribe un documento numérico.");
                    return;
                }
                control.Main.registrarRecolector(new BigDecimal(documento.getText().trim()),
                        nombre.getText().trim(), apellido.getText().trim(), telefono.getText().trim(), login.getText().trim(),
                        new String(textoClave));
                mensaje("Recolector registrado.");
                documento.setText("");
                nombre.setText("");
                apellido.setText("");
                login.setText("");
                clave.setText("");
            } catch (SQLException error) {
                mostrarError(error);
            } finally {
                Arrays.fill(textoClave, '\0');
            }
        });
    }
}
