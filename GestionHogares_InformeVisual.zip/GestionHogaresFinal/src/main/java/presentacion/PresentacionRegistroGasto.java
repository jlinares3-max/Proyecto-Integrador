package presentacion;
import negocio.OpcionCatalogo;

import java.math.BigDecimal;
import java.sql.SQLException;
import javax.swing.*;
import negocio.Sesion;

class PresentacionRegistroGasto extends Formulario {
    PresentacionRegistroGasto(Sesion sesion) { this(sesion, null); }
    PresentacionRegistroGasto(Sesion sesion, BigDecimal idGasto) {
        super(idGasto == null ? "Registrar gasto diario" : "Editar gasto");
        JComboBox<OpcionCatalogo> articulo = new JComboBox<>();
        JComboBox<OpcionCatalogo> unidad = new JComboBox<>();
        JComboBox<OpcionCatalogo> forma = new JComboBox<>();
        JComboBox<OpcionCatalogo> lugar = new JComboBox<>();
        JTextField cantidad = new JTextField();
        JTextField valor = new JTextField();
        JComboBox<String> frecuencia = new JComboBox<>(new String[]{
            "DIARIO", "VARIAS_SEMANA", "SEMANAL", "QUINCENAL", "MENSUAL", "BIMESTRAL", "TRIMESTRAL", "ESPORADICA"});
        JTextField otroArticulo = new JTextField();
        JTextField otraUnidad = new JTextField();
        JTextField otraForma = new JTextField();
        JTextField otroLugar = new JTextField();
        JRadioButton personal = new JRadioButton("Personal");
        JRadioButton delHogar = new JRadioButton("Del hogar", true);
        ButtonGroup tipos = new ButtonGroup();
        tipos.add(personal); tipos.add(delHogar);
        JPanel tipoPanel = new JPanel(new java.awt.GridLayout(1, 2, 10, 0));
        tipoPanel.setOpaque(false);
        personal.setOpaque(false); delHogar.setOpaque(false);
        tipoPanel.add(personal); tipoPanel.add(delHogar);
        campo("Tipo de gasto", tipoPanel);
        campo("Artículo", conOtro(articulo, otroArticulo));
        campo("Cantidad", cantidad);
        campo("Unidad de medida", conOtro(unidad, otraUnidad));
        campo("Forma de adquisición", conOtro(forma, otraForma));
        campo("Lugar de compra (opcional)", conOtro(lugar, otroLugar));
        campo("Valor pagado o estimado", valor);
        campo("Frecuencia de compra", frecuencia);
        try {
            for (OpcionCatalogo item : control.Main.listarArticulo(sesion.rol())) articulo.addItem(item);
            for (OpcionCatalogo item : control.Main.listarUnidadMedida(sesion.rol())) unidad.addItem(item);
            for (OpcionCatalogo item : control.Main.listarFormaAdquisicion(sesion.rol())) forma.addItem(item);
            lugar.addItem(null);
            for (OpcionCatalogo item : control.Main.listarLugarCompra(sesion.rol())) lugar.addItem(item);
        } catch (SQLException error) {
            mostrarError(error);
        }
        articulo.addItem(new OpcionCatalogo(null, "Otro"));
        unidad.addItem(new OpcionCatalogo(null, "Otro"));
        forma.addItem(new OpcionCatalogo(null, "Otro"));
        lugar.addItem(new OpcionCatalogo(null, "Otro"));
        if (idGasto != null) {
            try {
                Object[] fila = control.Main.consultarGasto(sesion, idGasto);
                cantidad.setText(fila[0].toString());
                valor.setText(fila[1].toString());
                frecuencia.setSelectedItem(fila[2]);
                personal.setSelected("PERSONAL".equals(fila[7]));
                delHogar.setSelected("HOGAR".equals(fila[7]));
                seleccionar(forma, (BigDecimal) fila[3]);
                seleccionar(unidad, (BigDecimal) fila[4]);
                seleccionar(articulo, (BigDecimal) fila[5]);
                seleccionar(lugar, (BigDecimal) fila[6]);
            } catch (SQLException error) { mostrarError(error); }
        }
        accion("Guardar gasto", () -> {
            try {
                BigDecimal c = new BigDecimal(cantidad.getText().trim().replace(',', '.'));
                BigDecimal v = new BigDecimal(valor.getText().trim().replace(',', '.'));
                if (c.signum() <= 0 || v.signum() < 0 || articulo.getSelectedItem() == null
                        || unidad.getSelectedItem() == null || forma.getSelectedItem() == null) {
                    mensaje("Completa los catálogos, escribe una cantidad positiva y un valor de cero o más.");
                    return;
                }
                OpcionCatalogo[] opciones = {(OpcionCatalogo) articulo.getSelectedItem(),
                    (OpcionCatalogo) unidad.getSelectedItem(), (OpcionCatalogo) forma.getSelectedItem(),
                    (OpcionCatalogo) lugar.getSelectedItem()};
                JTextField[] textos = {otroArticulo, otraUnidad, otraForma, otroLugar};
                int[] limites = {100, 30, 60, 80};
                BigDecimal[] ids = new BigDecimal[4]; String[] nombres = new String[4];
                for (int i = 0; i < 4; i++) {
                    if (opciones[i] == null) continue;
                    ids[i] = opciones[i].id();
                    if (ids[i] == null) {
                        nombres[i] = textos[i].getText().trim();
                        if (nombres[i].isEmpty() || nombres[i].length() > limites[i]) {
                            mensaje("Completa cada opción Otro (máximo " + limites[i] + " caracteres). "); return;
                        }
                    }
                }
                control.Main.guardarGastoConOtros(sesion, idGasto, c, v,
                    (String) frecuencia.getSelectedItem(), ids, nombres, personal.isSelected() ? "PERSONAL" : "HOGAR");
                mensaje("Gasto guardado como pendiente de revisión.");
                if (idGasto != null) return;
                cantidad.setText("");
                valor.setText("");
            } catch (NumberFormatException error) {
                mensaje("Escribe números en cantidad y valor.");
            } catch (SQLException error) {
                mostrarError(error);
            }
        });
    }
    private JPanel conOtro(JComboBox<OpcionCatalogo> lista, JTextField texto) {
        JPanel panel = new JPanel(new java.awt.GridLayout(1, 2, 8, 0));
        texto.setEnabled(false); texto.setToolTipText("Escribe la nueva opción al seleccionar Otro");
        lista.addActionListener(e -> {
            OpcionCatalogo opcion = (OpcionCatalogo) lista.getSelectedItem();
            texto.setEnabled(opcion != null && opcion.id() == null);
        });
        panel.add(lista); panel.add(texto); return panel;
    }
    private void seleccionar(JComboBox<OpcionCatalogo> lista, BigDecimal id) {
        if (id == null) { lista.setSelectedItem(null); return; }
        for (int i = 0; i < lista.getItemCount(); i++) {
            OpcionCatalogo opcion = lista.getItemAt(i);
            if (opcion != null && opcion.id() != null && opcion.id().compareTo(id) == 0) {
                lista.setSelectedIndex(i);
                return;
            }
        }
    }
}
