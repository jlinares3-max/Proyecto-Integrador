package presentacion;

import negocio.Sesion;

public class PresentacionEncuestado extends MenuRol {
    public PresentacionEncuestado(Sesion sesion) {
        super("Menú Encuestado", sesion);
        opciones.add(opcion("Registrar gasto", () -> control.Main.abrirGasto(this, sesion, null)));
        opciones.add(opcion("Consultar mis gastos", () -> control.Main.abrirGastos(this, sesion)));
    }
}
