SET SQLBLANKLINES ON
-- Ejecutar como ENPH_ADMIGASCA despues del script 03.
CREATE OR REPLACE FUNCTION nb_registros(p_login_sesion VARCHAR2, p_clave_sesion VARCHAR2, p_tipo VARCHAR2) RETURN SYS_REFCURSOR IS
 v_id NUMBER; c SYS_REFCURSOR; e_tipo EXCEPTION;
BEGIN
 v_id := nb_validar_sesion(p_login_sesion, p_clave_sesion, 'ADMINISTRADOR');
 IF p_tipo = 'VIVIENDA' THEN
   OPEN c FOR SELECT v.id_vivienda, v.direccion, v.id_barrio, v.cant_hogares, b.nombre FROM vivienda v JOIN barrio b ON b.id_barrio = v.id_barrio ORDER BY v.id_vivienda;
 ELSIF p_tipo = 'HOGAR' THEN
   OPEN c FOR SELECT h.id_hogar, h.total_personas, h.id_vivienda, v.direccion FROM hogar h JOIN vivienda v ON v.id_vivienda = h.id_vivienda ORDER BY h.id_hogar;
 ELSIF p_tipo = 'RECOLECTOR' THEN
   OPEN c FOR SELECT documento, nombre, apellido, telefono FROM recolector ORDER BY documento;
 ELSIF p_tipo = 'ENCUESTADO' THEN
   OPEN c FOR SELECT documento, nombre, apellido, telefono, correo FROM encuestado ORDER BY documento;
 ELSIF p_tipo = 'USUARIO' THEN
   OPEN c FOR SELECT id_usuario, login FROM usuario ORDER BY id_usuario;
 ELSE RAISE e_tipo; END IF;
 RETURN c;
END;
/
SHOW ERRORS FUNCTION nb_registros
