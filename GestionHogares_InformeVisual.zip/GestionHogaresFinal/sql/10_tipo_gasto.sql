SET SQLBLANKLINES ON
SET DEFINE OFF
-- Ejecutar como propietario del esquema. No borra datos.
CREATE OR REPLACE PROCEDURE nb_registrar_gasto(p_login_sesion VARCHAR2, p_clave_sesion VARCHAR2, p_cantidad NUMBER, p_valor NUMBER, p_frecuencia VARCHAR2, p_forma NUMBER, p_unidad NUMBER, p_articulo NUMBER, p_lugar NUMBER, p_tipo VARCHAR2 DEFAULT 'HOGAR') IS
    v_id_sesion NUMBER;
    e_acceso EXCEPTION;
    v_documento VARCHAR2(20);
    v_total NUMBER;
  BEGIN
    v_id_sesion := nb_validar_sesion(p_login_sesion, p_clave_sesion, 'ENCUESTADO');
    IF p_tipo IS NULL OR p_tipo NOT IN ('PERSONAL','HOGAR') THEN RAISE e_acceso; END IF;
    v_documento := nb_documento_actual(p_login_sesion, p_clave_sesion);
    SELECT COUNT(*) INTO v_total FROM encuestado x JOIN encuesta e ON e.id_hogar = x.id_hogar
    WHERE x.documento = v_documento AND e.estado_ciclo = 'PROCESO'
      AND TRUNC(SYSDATE) BETWEEN TRUNC(e.fecha_inicio) AND TRUNC(e.fecha_cierre);
    IF v_total = 0 OR p_cantidad <= 0 OR p_valor < 0 THEN RAISE e_acceso; END IF;
    pro_registrar_gasto(v_documento, p_articulo, p_cantidad, p_unidad,
      p_valor, p_forma, p_lugar, p_frecuencia, SYSDATE, p_tipo);
  END;
/
SHOW ERRORS PROCEDURE nb_registrar_gasto
CREATE OR REPLACE PROCEDURE nb_editar_gasto(p_login_sesion VARCHAR2, p_clave_sesion VARCHAR2, p_gasto NUMBER, p_cantidad NUMBER, p_valor NUMBER, p_frecuencia VARCHAR2,
    p_forma NUMBER, p_unidad NUMBER, p_articulo NUMBER, p_lugar NUMBER, p_tipo VARCHAR2 DEFAULT NULL) IS
    v_id_sesion NUMBER;
    v_rol_sesion VARCHAR2(20);
    e_acceso EXCEPTION;
    v_documento VARCHAR2(20);
    v_tipo VARCHAR2(10);
  BEGIN
    v_rol_sesion := nb_rol_sesion(p_login_sesion, p_clave_sesion);
    v_id_sesion := nb_validar_sesion(p_login_sesion, p_clave_sesion, 'RECOLECTOR');
    SELECT g.id_encuestado, g.tipo_gasto INTO v_documento, v_tipo
    FROM gastos g JOIN encuestado x ON x.documento = g.id_encuestado
    JOIN hogar h ON h.id_hogar = x.id_hogar
    LEFT JOIN recolector r ON r.documento = h.id_recolector
    WHERE g.id_gasto = p_gasto AND
      r.id_usuario = v_id_sesion
      AND EXISTS (SELECT 1 FROM visita vi WHERE vi.id_hogar = h.id_hogar AND vi.estado = 'PENDIENTE' AND TRUNC(vi.fecha_visita) = TRUNC(SYSDATE));
    IF p_cantidad <= 0 OR p_valor < 0 THEN RAISE e_acceso; END IF;
    IF p_tipo IS NOT NULL THEN
      IF p_tipo NOT IN ('PERSONAL','HOGAR') THEN RAISE e_acceso; END IF;
      v_tipo := p_tipo;
    END IF;
    pro_editar_gasto(p_gasto, v_documento, p_articulo, p_cantidad, p_unidad,
      p_valor, p_forma, p_lugar, p_frecuencia, v_tipo);
  END;
/
SHOW ERRORS PROCEDURE nb_editar_gasto
CREATE OR REPLACE PROCEDURE nb_gasto_con_otros(
 p_login_sesion VARCHAR2, p_clave_sesion VARCHAR2, p_gasto NUMBER,
 p_cantidad NUMBER, p_valor NUMBER, p_frecuencia VARCHAR2,
 p_articulo NUMBER, p_otro_articulo VARCHAR2,
 p_unidad NUMBER, p_otra_unidad VARCHAR2,
 p_forma NUMBER, p_otra_forma VARCHAR2,
 p_lugar NUMBER, p_otro_lugar VARCHAR2, p_tipo VARCHAR2 DEFAULT 'HOGAR') IS
 v_usuario NUMBER; v_articulo NUMBER; v_unidad NUMBER; v_forma NUMBER; v_lugar NUMBER;
BEGIN
 SAVEPOINT gasto_otros;
 IF p_gasto IS NULL THEN
 v_usuario := nb_validar_sesion(p_login_sesion, p_clave_sesion, 'ENCUESTADO');
 ELSE
 v_usuario := nb_validar_sesion(p_login_sesion, p_clave_sesion, 'RECOLECTOR');
 END IF;
 v_articulo := p_articulo; v_unidad := p_unidad; v_forma := p_forma; v_lugar := p_lugar;
 IF p_otro_articulo IS NOT NULL THEN v_articulo := nb_opcion_otro('ARTICULO', p_otro_articulo); END IF;
 IF p_otra_unidad IS NOT NULL THEN v_unidad := nb_opcion_otro('UNIDAD_MEDIDA', p_otra_unidad); END IF;
 IF p_otra_forma IS NOT NULL THEN v_forma := nb_opcion_otro('FORMA_ADQUISICION', p_otra_forma); END IF;
 IF p_otro_lugar IS NOT NULL THEN v_lugar := nb_opcion_otro('LUGAR_COMPRA', p_otro_lugar); END IF;
 IF p_gasto IS NULL THEN
 nb_registrar_gasto(p_login_sesion,p_clave_sesion,p_cantidad,p_valor,p_frecuencia,v_forma,v_unidad,v_articulo,v_lugar,p_tipo);
 ELSE
 nb_editar_gasto(p_login_sesion,p_clave_sesion,p_gasto,p_cantidad,p_valor,p_frecuencia,v_forma,v_unidad,v_articulo,v_lugar,p_tipo);
 END IF;
EXCEPTION WHEN OTHERS THEN
 ROLLBACK TO gasto_otros;
 RAISE;
END;
/
SHOW ERRORS PROCEDURE nb_gasto_con_otros
CREATE OR REPLACE FUNCTION nb_gasto_detalle(p_login_sesion VARCHAR2, p_clave_sesion VARCHAR2, p_gasto NUMBER) RETURN SYS_REFCURSOR IS
    v_id_sesion NUMBER;
    v_rol_sesion VARCHAR2(20);
    c SYS_REFCURSOR;
  BEGIN
    v_rol_sesion := nb_rol_sesion(p_login_sesion, p_clave_sesion);
    v_id_sesion := nb_validar_sesion(p_login_sesion, p_clave_sesion);
    OPEN c FOR SELECT g.cantidad, g.valor_producto, g.frecuencia_compra,
        g.id_forma, g.id_unidad, g.id_articulo, g.id_lugar, g.tipo_gasto
      FROM gastos g JOIN encuestado x ON x.documento = g.id_encuestado
      JOIN hogar h ON h.id_hogar = x.id_hogar
      LEFT JOIN recolector r ON r.documento = h.id_recolector
      WHERE g.id_gasto = p_gasto AND
        ((v_rol_sesion = 'ENCUESTADO' AND x.id_usuario = v_id_sesion)
          OR (v_rol_sesion = 'RECOLECTOR' AND r.id_usuario = v_id_sesion));
    RETURN c;
  END;
/
SHOW ERRORS FUNCTION nb_gasto_detalle
CREATE OR REPLACE TRIGGER trg_gasto_tipo
BEFORE INSERT OR UPDATE OF tipo_gasto ON gastos
FOR EACH ROW
DECLARE e_tipo EXCEPTION;
BEGIN
 IF :NEW.tipo_gasto IS NULL OR :NEW.tipo_gasto NOT IN ('PERSONAL','HOGAR') THEN
  RAISE e_tipo;
 END IF;
END;
/
SHOW ERRORS TRIGGER trg_gasto_tipo
