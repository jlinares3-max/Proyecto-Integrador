SET SERVEROUTPUT ON
SET DEFINE OFF
SET SQLBLANKLINES ON
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
-- Ejecutar UNA VEZ como ENPH_ADMIGASCA.
-- Datos ficticios, solo para entrar y explorar las pantallas.
-- No crea cuentas Oracle: inserta las cuentas personales en USUARIO.
DECLARE
  v_usuario_recolector NUMBER;
  v_usuario_encuestado NUMBER;
  v_departamento NUMBER;
  v_municipio NUMBER;
  v_barrio NUMBER;
  v_vivienda NUMBER;
  v_hogar NUMBER;
  v_total NUMBER;
  e_demo_existente EXCEPTION;
BEGIN
  SELECT COUNT(*) INTO v_total FROM usuario
    WHERE login IN ('recolector_demo', 'encuestado_demo');
  IF v_total > 0 THEN
    DBMS_OUTPUT.PUT_LINE('Ya existe una cuenta de demostracion. No se cambiaron sus datos.');
    RAISE e_demo_existente;
  END IF;
  SELECT COUNT(*) INTO v_total FROM recolector WHERE documento = 900000001;
  IF v_total > 0 THEN RAISE e_demo_existente; END IF;
  SELECT COUNT(*) INTO v_total FROM encuestado WHERE documento = '900000002';
  IF v_total > 0 THEN RAISE e_demo_existente; END IF;

  SELECT seq_usuario.NEXTVAL INTO v_usuario_recolector FROM dual;
  INSERT INTO usuario (id_usuario, login, contrasena, rol)
    VALUES (v_usuario_recolector, 'recolector_demo', 'Recolector2026', 'RECOLECTOR');
  INSERT INTO recolector (documento, nombre, apellido, telefono, id_usuario)
    VALUES (900000001, 'Carlos', 'Prueba', 3000000001, v_usuario_recolector);

  -- Ubicacion ficticia para no depender de que existan barrios o viviendas.
  SELECT seq_departamento.NEXTVAL INTO v_departamento FROM dual;
  INSERT INTO departamento (id_departamento, nombre)
    VALUES (v_departamento, 'Departamento DEMO');
  SELECT seq_municipio.NEXTVAL INTO v_municipio FROM dual;
  INSERT INTO municipio (id_municipio, nombre, id_departamento)
    VALUES (v_municipio, 'Municipio DEMO', v_departamento);
  SELECT seq_barrio.NEXTVAL INTO v_barrio FROM dual;
  INSERT INTO barrio (id_barrio, nombre, id_municipio)
    VALUES (v_barrio, 'Barrio DEMO', v_municipio);
  SELECT seq_vivienda.NEXTVAL INTO v_vivienda FROM dual;
  INSERT INTO vivienda (id_vivienda, direccion, id_barrio, cant_hogares)
    VALUES (v_vivienda, 'Vivienda de demostracion', v_barrio, 1);
  SELECT seq_hogar.NEXTVAL INTO v_hogar FROM dual;
  INSERT INTO hogar (id_hogar, estado, total_personas, id_vivienda, id_recolector)
    VALUES (v_hogar, 'SIN_ASIGNAR', 3, v_vivienda, NULL);

  SELECT seq_usuario.NEXTVAL INTO v_usuario_encuestado FROM dual;
  INSERT INTO usuario (id_usuario, login, contrasena, rol)
    VALUES (v_usuario_encuestado, 'encuestado_demo', 'Encuestado2026', 'ENCUESTADO');
  INSERT INTO encuestado (documento, nombre, apellido, telefono, correo, id_hogar, id_usuario)
    VALUES ('900000002', 'Ana', 'Prueba', 3000000002, 'ana.demo@example.com', v_hogar, v_usuario_encuestado);

  -- Una visita de hoy aparecera en Seguimiento del recolector.
  pro_asignar_hogar(v_hogar, 900000001);
  pro_iniciar_encuesta(v_hogar, TRUNC(SYSDATE));
  SELECT COUNT(*) INTO v_total FROM visita WHERE id_hogar = v_hogar;
  IF v_total <> 8 THEN RAISE e_demo_existente; END IF;
  COMMIT;
  DBMS_OUTPUT.PUT_LINE('Cuentas creadas. Hogar de demostracion: ' || v_hogar);
  DBMS_OUTPUT.PUT_LINE('Recolector: recolector_demo / Recolector2026');
  DBMS_OUTPUT.PUT_LINE('Encuestado: encuestado_demo / Encuestado2026');
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    RAISE;
END;
/
