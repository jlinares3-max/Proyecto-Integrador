-- Ejecutar conectado al propietario de las tablas. No borra datos.
SET DEFINE OFF
CREATE OR REPLACE FUNCTION nb_gastos_hogar(p_login_sesion VARCHAR2, p_clave_sesion VARCHAR2, p_hogar NUMBER) RETURN SYS_REFCURSOR IS
 v_id NUMBER; c SYS_REFCURSOR;
BEGIN
 v_id := nb_validar_sesion(p_login_sesion, p_clave_sesion, 'RECOLECTOR');
 OPEN c FOR SELECT g.id_gasto, g.fecha_registro, h.id_hogar, a.nombre,
   g.cantidad, g.valor_producto, g.estado,
   CASE WHEN e.fecha_inicio IS NULL THEN 'Sin inicio'
        WHEN TRUNC(g.fecha_registro) - TRUNC(e.fecha_inicio) NOT BETWEEN 0 AND 13
          THEN 'Fuera del ciclo'
        ELSE 'Dia ' || TO_CHAR(TRUNC(g.fecha_registro) - TRUNC(e.fecha_inicio) + 1) END AS dia_ciclo,
   CASE g.tipo_gasto WHEN 'PERSONAL' THEN 'Personal' WHEN 'HOGAR' THEN 'Del hogar'
        ELSE 'Sin tipo' END AS tipo_gasto
 FROM gastos g JOIN encuestado x ON x.documento = g.id_encuestado
 JOIN hogar h ON h.id_hogar = x.id_hogar JOIN articulo a ON a.id_articulo = g.id_articulo
 LEFT JOIN encuesta e ON e.id_hogar = h.id_hogar
 JOIN recolector r ON r.documento = h.id_recolector
 WHERE h.id_hogar = p_hogar AND r.id_usuario = v_id
   AND EXISTS (SELECT 1 FROM visita vi WHERE vi.id_hogar = h.id_hogar
      AND vi.estado = 'PENDIENTE' AND TRUNC(vi.fecha_visita) = TRUNC(SYSDATE))
 ORDER BY g.fecha_registro ASC, g.id_gasto;
 RETURN c;
END;
/
SHOW ERRORS FUNCTION nb_gastos_hogar
GRANT EXECUTE ON nb_gastos_hogar TO rol_recolector;
