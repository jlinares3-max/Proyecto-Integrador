SET SQLBLANKLINES ON
-- Ejecutar como ENPH_ADMIGASCA.
CREATE OR REPLACE FUNCTION nb_hogares(p_login_sesion VARCHAR2, p_clave_sesion VARCHAR2) RETURN SYS_REFCURSOR IS
    v_id_sesion NUMBER;
    c SYS_REFCURSOR;
  BEGIN
    v_id_sesion := nb_validar_sesion(p_login_sesion, p_clave_sesion, 'ADMINISTRADOR');
    OPEN c FOR SELECT h.id_hogar, v.direccion, h.estado,
      r.nombre || ' ' || r.apellido, e.fecha_inicio, fun_dia_periodo(h.id_hogar),
      (SELECT COUNT(*) FROM visita vi WHERE vi.id_hogar = h.id_hogar),
      e.estado_ciclo, e.fecha_cierre, fun_contar_gastos_pendientes(h.id_hogar)
    FROM hogar h JOIN vivienda v ON v.id_vivienda = h.id_vivienda
    LEFT JOIN recolector r ON r.documento = h.id_recolector
    LEFT JOIN encuesta e ON e.id_hogar = h.id_hogar ORDER BY h.id_hogar;
    RETURN c;
  END;
/
SHOW ERRORS FUNCTION nb_hogares
