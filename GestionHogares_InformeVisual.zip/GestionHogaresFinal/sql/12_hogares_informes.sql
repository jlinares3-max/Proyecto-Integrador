-- Ejecutar como propietario de las tablas. No elimina datos.
SET DEFINE OFF
CREATE OR REPLACE FUNCTION nb_encuestas_cierre(p_login_sesion VARCHAR2, p_clave_sesion VARCHAR2) RETURN SYS_REFCURSOR IS
 v_id NUMBER; c SYS_REFCURSOR;
BEGIN
 v_id := nb_validar_sesion(p_login_sesion, p_clave_sesion, 'RECOLECTOR');
 OPEN c FOR
 SELECT h.id_hogar, v.direccion, TO_CHAR(e.fecha_inicio,'DD/MM/YYYY'),
   TO_CHAR(e.fecha_cierre,'DD/MM/YYYY'), NVL(e.estado_ciclo,'SIN ENCUESTA'),
   (SELECT MIN(x.nombre || ' ' || x.apellido) FROM encuestado x WHERE x.id_hogar=h.id_hogar),
   h.total_personas, fun_contar_gastos_pendientes(h.id_hogar),
   CASE WHEN e.estado_ciclo='PROCESO' AND TRUNC(SYSDATE)>=TRUNC(e.fecha_cierre)
     AND fun_contar_gastos_pendientes(h.id_hogar)=0 THEN 'SI' ELSE 'NO' END
 FROM hogar h JOIN vivienda v ON v.id_vivienda=h.id_vivienda
 JOIN recolector r ON r.documento=h.id_recolector
 LEFT JOIN encuesta e ON e.id_hogar=h.id_hogar
 WHERE r.id_usuario=v_id ORDER BY h.id_hogar;
 RETURN c;
END;
/
SHOW ERRORS FUNCTION nb_encuestas_cierre

CREATE OR REPLACE FUNCTION nb_reporte_gastos(p_login_sesion VARCHAR2, p_clave_sesion VARCHAR2, p_hogar NUMBER)
RETURN SYS_REFCURSOR IS
 v_id NUMBER; c SYS_REFCURSOR;
BEGIN
 v_id := nb_validar_sesion(p_login_sesion, p_clave_sesion, 'RECOLECTOR');
 OPEN c FOR
 SELECT v.direccion, h.total_personas, r.nombre || ' ' || r.apellido,
   TO_CHAR(e.fecha_inicio,'DD/MM/YYYY'), TO_CHAR(e.fecha_cierre,'DD/MM/YYYY'),
   NVL(e.estado_ciclo,'SIN ENCUESTA'),
   (SELECT MIN(z.nombre || ' ' || z.apellido) FROM encuestado z WHERE z.id_hogar=h.id_hogar),
   g.id_gasto, TO_CHAR(g.fecha_registro,'DD/MM/YYYY HH24:MI'),
   CASE WHEN g.id_gasto IS NULL THEN NULL
        WHEN e.fecha_inicio IS NULL THEN 'Sin inicio'
        WHEN TRUNC(g.fecha_registro)-TRUNC(e.fecha_inicio) NOT BETWEEN 0 AND 13 THEN 'Fuera del ciclo'
        ELSE 'Dia ' || TO_CHAR(TRUNC(g.fecha_registro)-TRUNC(e.fecha_inicio)+1) END,
   a.nombre, CASE g.tipo_gasto WHEN 'PERSONAL' THEN 'Personal' WHEN 'HOGAR' THEN 'Del hogar' ELSE 'Sin tipo' END,
   g.cantidad, um.nombre, g.valor_producto, g.estado,
   x.nombre || ' ' || x.apellido, fa.nombre, lc.nombre
 FROM hogar h JOIN vivienda v ON v.id_vivienda=h.id_vivienda
 JOIN recolector r ON r.documento=h.id_recolector
 LEFT JOIN encuesta e ON e.id_hogar=h.id_hogar
 LEFT JOIN encuestado x ON x.id_hogar=h.id_hogar
 LEFT JOIN gastos g ON g.id_encuestado=x.documento
 LEFT JOIN articulo a ON a.id_articulo=g.id_articulo
 LEFT JOIN unidad_medida um ON um.id_unidad=g.id_unidad
 LEFT JOIN forma_adquisicion fa ON fa.id_forma=g.id_forma
 LEFT JOIN lugar_compra lc ON lc.id_lugar=g.id_lugar
 WHERE h.id_hogar=p_hogar AND r.id_usuario=v_id
 ORDER BY g.fecha_registro, g.id_gasto;
 RETURN c;
END;
/
SHOW ERRORS FUNCTION nb_reporte_gastos
GRANT EXECUTE ON nb_encuestas_cierre TO rol_recolector;
GRANT EXECUTE ON nb_reporte_gastos TO rol_recolector;

CREATE OR REPLACE PROCEDURE nb_cerrar(p_login_sesion VARCHAR2, p_clave_sesion VARCHAR2, p_hogar NUMBER) IS
    v_id_sesion NUMBER;
    e_acceso EXCEPTION;
    v_estado VARCHAR2(20);
    v_total NUMBER;
  BEGIN
    v_id_sesion := nb_validar_sesion(p_login_sesion, p_clave_sesion, 'RECOLECTOR');
    SELECT COUNT(*) INTO v_total FROM hogar h JOIN recolector r ON r.documento = h.id_recolector
      WHERE h.id_hogar = p_hogar AND r.id_usuario = v_id_sesion;
    IF v_total = 0 THEN RAISE e_acceso; END IF;
    SELECT COUNT(*) INTO v_total FROM encuesta
      WHERE id_hogar=p_hogar AND estado_ciclo='PROCESO'
        AND TRUNC(SYSDATE)>=TRUNC(fecha_cierre)
        AND fun_contar_gastos_pendientes(p_hogar)=0;
    IF v_total=0 THEN RAISE e_acceso; END IF;
    pro_cerrar_encuesta(p_hogar);
    SELECT estado_ciclo INTO v_estado FROM encuesta WHERE id_hogar = p_hogar;
    IF v_estado <> 'FINALIZADO' THEN RAISE e_acceso; END IF;
  END;
/
SHOW ERRORS PROCEDURE nb_cerrar

GRANT EXECUTE ON nb_cerrar TO rol_recolector;
