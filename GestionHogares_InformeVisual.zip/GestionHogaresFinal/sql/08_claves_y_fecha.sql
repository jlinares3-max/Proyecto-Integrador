SET SQLBLANKLINES ON
SET DEFINE OFF
-- Conectado al propietario: ENPH_ADMIGASCA o ENPH_DAVID.
CREATE OR REPLACE PROCEDURE nb_cambiar_clave(p_login_sesion VARCHAR2, p_clave_sesion VARCHAR2, p_usuario NUMBER, p_nueva VARCHAR2) IS
 v_id NUMBER; e_clave EXCEPTION;
BEGIN
 v_id := nb_validar_sesion(p_login_sesion, p_clave_sesion, 'ADMINISTRADOR');
 IF TRIM(p_nueva) IS NULL OR LENGTHB(p_nueva) > 100 THEN RAISE e_clave; END IF;
 UPDATE usuario SET contrasena = p_nueva WHERE id_usuario = p_usuario;
 IF SQL%ROWCOUNT <> 1 THEN RAISE e_clave; END IF;
END;
/
SHOW ERRORS PROCEDURE nb_cambiar_clave
GRANT EXECUTE ON nb_cambiar_clave TO rol_administrador;
CREATE OR REPLACE TRIGGER trg_encuesta_fecha_inicio
BEFORE INSERT OR UPDATE OF fecha_inicio ON encuesta
FOR EACH ROW
DECLARE e_fecha_invalida EXCEPTION;
BEGIN
 IF :NEW.fecha_inicio IS NULL THEN RAISE e_fecha_invalida; END IF;
 IF INSERTING THEN
  IF TRUNC(:NEW.fecha_inicio) < TRUNC(SYSDATE) THEN RAISE e_fecha_invalida; END IF;
 ELSIF :OLD.fecha_inicio IS NULL OR TRUNC(:NEW.fecha_inicio) <> TRUNC(:OLD.fecha_inicio) THEN
  IF TRUNC(:NEW.fecha_inicio) < TRUNC(SYSDATE) THEN RAISE e_fecha_invalida; END IF;
 END IF;
END;
/
SHOW ERRORS TRIGGER trg_encuesta_fecha_inicio
