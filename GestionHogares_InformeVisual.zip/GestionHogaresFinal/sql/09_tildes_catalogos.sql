SET DEFINE OFF
-- Opcional: corrige SOLO variantes conocidas; revisar antes de COMMIT.
UPDATE articulo SET nombre = UNISTR('Az\00FAcar')
WHERE UPPER(TRIM(nombre)) IN (UPPER(UNISTR('Az\00C3\00BAcar')), UPPER(UNISTR('Az\251C\2551car')));
UPDATE forma_adquisicion SET nombre = UNISTR('Compra a cr\00E9dito')
WHERE UPPER(TRIM(nombre)) IN (UPPER(UNISTR('Compra a cr\00C3\00A9dito')), UPPER(UNISTR('Compra a cr\251C\00AEdito')));
UPDATE forma_adquisicion SET nombre = UNISTR('Producci\00F3n propia')
WHERE UPPER(TRIM(nombre)) IN (UPPER(UNISTR('Producci\00C3\00B3n propia')), UPPER(UNISTR('Producci\251C\2502n propia')));
UPDATE lugar_compra SET nombre = UNISTR('Panader\00EDa')
WHERE UPPER(TRIM(nombre)) IN (UPPER(UNISTR('Panader\00C3\00ADa')), UPPER(UNISTR('Panader\251C\00A1a')));
UPDATE lugar_compra SET nombre = UNISTR('Carnicer\00EDa')
WHERE UPPER(TRIM(nombre)) IN (UPPER(UNISTR('Carnicer\00C3\00ADa')), UPPER(UNISTR('Carnicer\251C\00A1a')));
SELECT nombre FROM articulo;
SELECT nombre FROM forma_adquisicion;
-- Si los nombres son correctos: COMMIT; si no: ROLLBACK;
