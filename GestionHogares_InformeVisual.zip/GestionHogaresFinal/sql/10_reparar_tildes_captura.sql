-- Ejecutar conectado al propietario de las tablas del proyecto.
-- Compatible con SQL*Plus / Oracle 10g. El archivo usa solo caracteres ASCII.
-- No contiene COMMIT ni ROLLBACK: revise los resultados antes de decidir.
SET DEFINE OFF
SET PAGESIZE 100
SET LINESIZE 180
COLUMN nombre FORMAT A45
PROMPT === Compruebe el usuario conectado ===
SHOW USER
PROMPT === Filas candidatas antes de la correccion ===
SELECT id_articulo, nombre, DUMP(nombre, 1016) AS bytes
FROM articulo
WHERE UPPER(TRIM(nombre)) LIKE 'AZ_CAR'
   OR UPPER(TRIM(nombre)) LIKE 'AZ__CAR';
SELECT id_forma, nombre, DUMP(nombre, 1016) AS bytes
FROM forma_adquisicion
WHERE UPPER(TRIM(nombre)) LIKE 'PRODUCCI_N PROPIA'
   OR UPPER(TRIM(nombre)) LIKE 'PRODUCCI__N PROPIA';

-- Se conserva el ID de cada fila y por tanto sus relaciones.
UPDATE articulo SET nombre = UNISTR('Az\00FAcar')
WHERE UPPER(TRIM(nombre)) LIKE 'AZ_CAR'
   OR UPPER(TRIM(nombre)) LIKE 'AZ__CAR';
UPDATE forma_adquisicion SET nombre = UNISTR('Producci\00F3n propia')
WHERE UPPER(TRIM(nombre)) LIKE 'PRODUCCI_N PROPIA'
   OR UPPER(TRIM(nombre)) LIKE 'PRODUCCI__N PROPIA';

PROMPT === Revise los resultados en las listas completas ===
SELECT id_articulo, nombre FROM articulo ORDER BY id_articulo;
SELECT id_forma, nombre FROM forma_adquisicion ORDER BY id_forma;
PROMPT === Si todo esta correcto escriba COMMIT; ===
PROMPT === Si algo no esta correcto escriba ROLLBACK; ===
PROMPT === No cierre SQLPlus antes de elegir una opcion ===
