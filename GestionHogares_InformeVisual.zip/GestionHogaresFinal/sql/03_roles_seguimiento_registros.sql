SET SQLBLANKLINES ON
SET DEFINE OFF
WHENEVER SQLERROR EXIT SQL.SQLCODE
-- Ejecutar como ENPH_ADMIGASCA, despues del script 01.
CREATE OR REPLACE FUNCTION nb_visitas(p_login_sesion VARCHAR2, p_clave_sesion VARCHAR2) RETURN SYS_REFCURSOR IS
    v_id_sesion NUMBER;
    c SYS_REFCURSOR;
  BEGIN
    v_id_sesion := nb_validar_sesion(p_login_sesion, p_clave_sesion, 'RECOLECTOR');
    OPEN c FOR SELECT vi.id_visita, vi.id_hogar, CAST(vi.fecha_visita AS TIMESTAMP),
      vi.tipo_visita, vi.estado, v.direccion, vi.observaciones,
      fun_encuesta_finalizada(h.id_hogar, h.id_recolector)
    FROM visita vi JOIN hogar h ON h.id_hogar = vi.id_hogar
    JOIN vivienda v ON v.id_vivienda = h.id_vivienda
    JOIN recolector r ON r.documento = h.id_recolector
    WHERE r.id_usuario = v_id_sesion AND vi.estado = 'PENDIENTE'
      AND TRUNC(vi.fecha_visita) = TRUNC(SYSDATE)
      AND EXISTS (SELECT 1 FROM encuesta e WHERE e.id_hogar = h.id_hogar AND e.estado_ciclo = 'PROCESO') ORDER BY vi.fecha_visita, vi.id_visita;
    RETURN c;
  END;
/
SHOW ERRORS FUNCTION nb_visitas
CREATE OR REPLACE PROCEDURE nb_editar_gasto(p_login_sesion VARCHAR2, p_clave_sesion VARCHAR2, p_gasto NUMBER, p_cantidad NUMBER, p_valor NUMBER, p_frecuencia VARCHAR2,
    p_forma NUMBER, p_unidad NUMBER, p_articulo NUMBER, p_lugar NUMBER) IS
    v_id_sesion NUMBER;
    v_rol_sesion VARCHAR2(20);
    e_acceso EXCEPTION;
    v_documento VARCHAR2(20);
    v_tipo VARCHAR2(10);
  BEGIN
    v_rol_sesion := nb_rol_sesion(p_login_sesion, p_clave_sesion);
    v_id_sesion := nb_validar_sesion(p_login_sesion, p_clave_sesion, 'RECOLECTOR');
    SELECT g.id_encuestado, g.tipo_gasto INTO v_documento, v_tipo
    FROM gastos g JOIN encuestado x ON x.documento = g.id_encuestado
    JOIN hogar h ON h.id_hogar = x.id_hogar
    LEFT JOIN recolector r ON r.documento = h.id_recolector
    WHERE g.id_gasto = p_gasto AND
      r.id_usuario = v_id_sesion
      AND EXISTS (SELECT 1 FROM visita vi WHERE vi.id_hogar = h.id_hogar AND vi.estado = 'PENDIENTE' AND TRUNC(vi.fecha_visita) = TRUNC(SYSDATE));
    IF p_cantidad <= 0 OR p_valor < 0 THEN RAISE e_acceso; END IF;
    pro_editar_gasto(p_gasto, v_documento, p_articulo, p_cantidad, p_unidad,
      p_valor, p_forma, p_lugar, p_frecuencia, v_tipo);
  END;
/
SHOW ERRORS PROCEDURE nb_editar_gasto
CREATE OR REPLACE PROCEDURE nb_revisar(p_login_sesion VARCHAR2, p_clave_sesion VARCHAR2, p_gasto NUMBER) IS
    v_id_sesion NUMBER;
    e_acceso EXCEPTION;
    v_total NUMBER;
    v_documento NUMBER;
  BEGIN
    v_id_sesion := nb_validar_sesion(p_login_sesion, p_clave_sesion, 'RECOLECTOR');
    v_documento := TO_NUMBER(nb_documento_actual(p_login_sesion, p_clave_sesion));
    SELECT COUNT(*) INTO v_total FROM gastos g JOIN encuestado x ON x.documento = g.id_encuestado
    JOIN hogar h ON h.id_hogar = x.id_hogar
    WHERE g.id_gasto = p_gasto AND h.id_recolector = v_documento AND g.estado = 'PENDIENTE'
      AND EXISTS (SELECT 1 FROM visita vi WHERE vi.id_hogar = h.id_hogar AND vi.estado = 'PENDIENTE' AND TRUNC(vi.fecha_visita) = TRUNC(SYSDATE));
    IF v_total = 0 THEN RAISE e_acceso; END IF;
    pro_revisar_gasto(p_gasto, v_documento);
  END;
/
SHOW ERRORS PROCEDURE nb_revisar
CREATE OR REPLACE PROCEDURE nb_observar(p_login_sesion VARCHAR2, p_clave_sesion VARCHAR2, p_visita NUMBER, p_nota VARCHAR2) IS
    v_id_sesion NUMBER;
    e_acceso EXCEPTION;
    v_total NUMBER;
    v_documento NUMBER;
  BEGIN
    v_id_sesion := nb_validar_sesion(p_login_sesion, p_clave_sesion, 'RECOLECTOR');
    v_documento := TO_NUMBER(nb_documento_actual(p_login_sesion, p_clave_sesion));
    SELECT COUNT(*) INTO v_total FROM visita vi JOIN hogar h ON h.id_hogar = vi.id_hogar
    WHERE vi.id_visita = p_visita AND h.id_recolector = v_documento AND vi.estado = 'PENDIENTE'
      AND TRUNC(vi.fecha_visita) = TRUNC(SYSDATE)
      AND EXISTS (SELECT 1 FROM encuesta e WHERE e.id_hogar = h.id_hogar AND e.estado_ciclo = 'PROCESO');
    IF v_total = 0 THEN RAISE e_acceso; END IF;
    pro_guardar_observacion_visita(p_visita, v_documento, p_nota);
  END;
/
SHOW ERRORS PROCEDURE nb_observar
CREATE OR REPLACE PROCEDURE nb_cerrar(p_login_sesion VARCHAR2, p_clave_sesion VARCHAR2, p_hogar NUMBER) IS
    v_id_sesion NUMBER;
    e_acceso EXCEPTION;
    v_estado VARCHAR2(20);
    v_total NUMBER;
  BEGIN
    v_id_sesion := nb_validar_sesion(p_login_sesion, p_clave_sesion, 'RECOLECTOR');
    SELECT COUNT(*) INTO v_total FROM hogar h JOIN recolector r ON r.documento = h.id_recolector
      WHERE h.id_hogar = p_hogar AND r.id_usuario = v_id_sesion;
    IF v_total = 0 THEN RAISE e_acceso; END IF;
    pro_cerrar_encuesta(p_hogar);
    SELECT estado_ciclo INTO v_estado FROM encuesta WHERE id_hogar = p_hogar;
    IF v_estado <> 'FINALIZADO' THEN RAISE e_acceso; END IF;
  END;
/
SHOW ERRORS PROCEDURE nb_cerrar
CREATE OR REPLACE FUNCTION nb_gastos(p_login_sesion VARCHAR2, p_clave_sesion VARCHAR2) RETURN SYS_REFCURSOR IS
    v_id_sesion NUMBER;
    v_rol_sesion VARCHAR2(20);
    c SYS_REFCURSOR;
  BEGIN
    v_rol_sesion := nb_rol_sesion(p_login_sesion, p_clave_sesion);
    v_id_sesion := nb_validar_sesion(p_login_sesion, p_clave_sesion);
    OPEN c FOR SELECT g.id_gasto, g.fecha_registro, h.id_hogar, a.nombre,
      g.cantidad, g.valor_producto, g.estado
    FROM gastos g JOIN encuestado x ON x.documento = g.id_encuestado
    JOIN hogar h ON h.id_hogar = x.id_hogar JOIN articulo a ON a.id_articulo = g.id_articulo
    LEFT JOIN recolector r ON r.documento = h.id_recolector
    WHERE (v_rol_sesion = 'RECOLECTOR' AND r.id_usuario = v_id_sesion)
       OR (v_rol_sesion = 'ENCUESTADO' AND x.id_usuario = v_id_sesion)
    ORDER BY g.fecha_registro DESC, g.id_gasto;
    RETURN c;
  END;
/
SHOW ERRORS FUNCTION nb_gastos
CREATE OR REPLACE FUNCTION nb_encuestas_cierre(p_login_sesion VARCHAR2, p_clave_sesion VARCHAR2) RETURN SYS_REFCURSOR IS
  v_id NUMBER;
  c SYS_REFCURSOR;
BEGIN
  v_id := nb_validar_sesion(p_login_sesion, p_clave_sesion, 'RECOLECTOR');
  OPEN c FOR SELECT h.id_hogar, v.direccion, e.fecha_inicio, e.fecha_cierre, e.estado_ciclo
    FROM hogar h JOIN vivienda v ON v.id_vivienda = h.id_vivienda
    JOIN recolector r ON r.documento = h.id_recolector JOIN encuesta e ON e.id_hogar = h.id_hogar
    WHERE r.id_usuario = v_id AND (e.estado_ciclo = 'FINALIZADO' OR
      (e.estado_ciclo = 'PROCESO' AND TRUNC(SYSDATE) >= TRUNC(e.fecha_cierre)
       AND fun_contar_gastos_pendientes(h.id_hogar) = 0)) ORDER BY h.id_hogar;
  RETURN c;
END;
/
SHOW ERRORS FUNCTION nb_encuestas_cierre
CREATE OR REPLACE PROCEDURE nb_realizar_visita(p_login_sesion VARCHAR2, p_clave_sesion VARCHAR2, p_visita NUMBER, p_nota VARCHAR2) IS
  v_id NUMBER;
  e_visita EXCEPTION;
BEGIN
  v_id := nb_validar_sesion(p_login_sesion, p_clave_sesion, 'RECOLECTOR');
  IF LENGTH(p_nota) > 300 THEN RAISE e_visita; END IF;
  UPDATE visita vi SET estado = 'REALIZADA', observaciones = p_nota
    WHERE vi.id_visita = p_visita AND vi.estado = 'PENDIENTE' AND TRUNC(vi.fecha_visita) = TRUNC(SYSDATE)
      AND EXISTS (SELECT 1 FROM hogar h JOIN recolector r ON r.documento = h.id_recolector
        JOIN encuesta e ON e.id_hogar = h.id_hogar
        WHERE h.id_hogar = vi.id_hogar AND r.id_usuario = v_id AND e.estado_ciclo = 'PROCESO');
  IF SQL%ROWCOUNT = 0 THEN RAISE e_visita; END IF;
END;
/
SHOW ERRORS PROCEDURE nb_realizar_visita
CREATE OR REPLACE FUNCTION nb_registros(p_login_sesion VARCHAR2, p_clave_sesion VARCHAR2, p_tipo VARCHAR2) RETURN SYS_REFCURSOR IS
 v_id NUMBER; c SYS_REFCURSOR; e_tipo EXCEPTION;
BEGIN
 v_id := nb_validar_sesion(p_login_sesion, p_clave_sesion, 'ADMINISTRADOR');
 IF p_tipo = 'VIVIENDA' THEN
   OPEN c FOR SELECT id_vivienda, direccion, id_barrio, cant_hogares FROM vivienda ORDER BY id_vivienda;
 ELSIF p_tipo = 'HOGAR' THEN
   OPEN c FOR SELECT id_hogar, total_personas, id_vivienda FROM hogar ORDER BY id_hogar;
 ELSIF p_tipo = 'RECOLECTOR' THEN
   OPEN c FOR SELECT documento, nombre, apellido, telefono FROM recolector ORDER BY documento;
 ELSIF p_tipo = 'ENCUESTADO' THEN
   OPEN c FOR SELECT documento, nombre, apellido, telefono, correo FROM encuestado ORDER BY documento;
 ELSIF p_tipo = 'USUARIO' THEN
   OPEN c FOR SELECT id_usuario, login FROM usuario ORDER BY id_usuario;
 ELSE RAISE e_tipo; END IF;
 RETURN c;
END;
/
SHOW ERRORS FUNCTION nb_registros
CREATE OR REPLACE PROCEDURE nb_editar_registro(p_login_sesion VARCHAR2, p_clave_sesion VARCHAR2,
 p_tipo VARCHAR2, p_id VARCHAR2, p_a VARCHAR2, p_b VARCHAR2, p_c VARCHAR2, p_d VARCHAR2) IS
 v_id NUMBER; e_datos EXCEPTION;
BEGIN
 v_id := nb_validar_sesion(p_login_sesion, p_clave_sesion, 'ADMINISTRADOR');
 IF p_tipo = 'VIVIENDA' THEN
   IF p_a IS NULL OR p_b IS NULL OR p_c IS NULL OR TO_NUMBER(p_c) < 1 OR TO_NUMBER(p_c) <> TRUNC(TO_NUMBER(p_c)) THEN RAISE e_datos; END IF;
   UPDATE vivienda SET direccion = p_a, id_barrio = TO_NUMBER(p_b), cant_hogares = TO_NUMBER(p_c) WHERE id_vivienda = TO_NUMBER(p_id);
 ELSIF p_tipo = 'HOGAR' THEN
   IF p_a IS NULL OR TO_NUMBER(p_a) < 1 OR TO_NUMBER(p_a) <> TRUNC(TO_NUMBER(p_a)) OR p_b IS NULL THEN RAISE e_datos; END IF;
   UPDATE hogar SET total_personas = TO_NUMBER(p_a), id_vivienda = TO_NUMBER(p_b) WHERE id_hogar = TO_NUMBER(p_id);
 ELSIF p_tipo = 'RECOLECTOR' THEN
   IF p_a IS NULL OR p_b IS NULL OR p_c IS NULL THEN RAISE e_datos; END IF;
   UPDATE recolector SET nombre = p_a, apellido = p_b, telefono = TO_NUMBER(p_c) WHERE documento = TO_NUMBER(p_id);
 ELSIF p_tipo = 'ENCUESTADO' THEN
   IF p_a IS NULL OR p_b IS NULL OR p_c IS NULL THEN RAISE e_datos; END IF;
   UPDATE encuestado SET nombre = p_a, apellido = p_b, telefono = TO_NUMBER(p_c), correo = p_d WHERE documento = p_id;
 ELSIF p_tipo = 'USUARIO' THEN
   IF p_a IS NULL THEN RAISE e_datos; END IF;
   UPDATE usuario SET login = p_a WHERE id_usuario = TO_NUMBER(p_id);
 ELSE RAISE e_datos; END IF;
 IF SQL%ROWCOUNT = 0 THEN RAISE e_datos; END IF;
END;
/
SHOW ERRORS PROCEDURE nb_editar_registro
CREATE OR REPLACE PROCEDURE nb_eliminar_registro(p_login_sesion VARCHAR2, p_clave_sesion VARCHAR2, p_tipo VARCHAR2, p_id VARCHAR2) IS
 v_id NUMBER; e_datos EXCEPTION; v_total NUMBER;
BEGIN
 v_id := nb_validar_sesion(p_login_sesion, p_clave_sesion, 'ADMINISTRADOR');
 IF p_tipo = 'VIVIENDA' THEN
   SELECT COUNT(*) INTO v_total FROM hogar WHERE id_vivienda = p_id;
   IF v_total > 0 THEN RAISE e_datos; END IF;
   DELETE FROM vivienda WHERE id_vivienda = TO_NUMBER(p_id);
 ELSIF p_tipo = 'HOGAR' THEN
   SELECT COUNT(*) INTO v_total FROM encuestado WHERE id_hogar = p_id;
   IF v_total > 0 THEN RAISE e_datos; END IF;
   SELECT COUNT(*) INTO v_total FROM visita WHERE id_hogar = p_id;
   IF v_total > 0 THEN RAISE e_datos; END IF;
   SELECT COUNT(*) INTO v_total FROM encuesta WHERE id_hogar = p_id;
   IF v_total > 0 THEN RAISE e_datos; END IF;
   DELETE FROM hogar WHERE id_hogar = TO_NUMBER(p_id);
 ELSIF p_tipo = 'RECOLECTOR' THEN
   SELECT COUNT(*) INTO v_total FROM hogar WHERE id_recolector = p_id;
   IF v_total > 0 THEN RAISE e_datos; END IF;
   SELECT COUNT(*) INTO v_total FROM visita WHERE id_recolector = p_id;
   IF v_total > 0 THEN RAISE e_datos; END IF;
   DELETE FROM recolector WHERE documento = TO_NUMBER(p_id);
 ELSIF p_tipo = 'ENCUESTADO' THEN
   SELECT COUNT(*) INTO v_total FROM gastos WHERE id_encuestado = p_id;
   IF v_total > 0 THEN RAISE e_datos; END IF;
   DELETE FROM encuestado WHERE documento = p_id;
 ELSIF p_tipo = 'USUARIO' THEN
   IF TO_NUMBER(p_id) = v_id THEN RAISE e_datos; END IF;
   SELECT COUNT(*) INTO v_total FROM recolector WHERE id_usuario = p_id;
   IF v_total > 0 THEN RAISE e_datos; END IF;
   SELECT COUNT(*) INTO v_total FROM encuestado WHERE id_usuario = p_id;
   IF v_total > 0 THEN RAISE e_datos; END IF;
   DELETE FROM usuario WHERE id_usuario = TO_NUMBER(p_id);
 ELSE RAISE e_datos; END IF;
 IF SQL%ROWCOUNT = 0 THEN RAISE e_datos; END IF;
END;
/
SHOW ERRORS PROCEDURE nb_eliminar_registro
GRANT EXECUTE ON nb_encuestas_cierre TO rol_recolector;
GRANT EXECUTE ON nb_realizar_visita TO rol_recolector;
GRANT EXECUTE ON nb_registros TO rol_administrador;
GRANT EXECUTE ON nb_editar_registro TO rol_administrador;
GRANT EXECUTE ON nb_eliminar_registro TO rol_administrador;

SELECT name, line, text FROM user_errors WHERE name LIKE 'NB_%' ORDER BY name, sequence;

CREATE OR REPLACE FUNCTION nb_gastos_hogar(p_login_sesion VARCHAR2, p_clave_sesion VARCHAR2, p_hogar NUMBER) RETURN SYS_REFCURSOR IS
 v_id NUMBER; c SYS_REFCURSOR;
BEGIN
 v_id := nb_validar_sesion(p_login_sesion, p_clave_sesion, 'RECOLECTOR');
 OPEN c FOR SELECT g.id_gasto, g.fecha_registro, h.id_hogar, a.nombre,
   g.cantidad, g.valor_producto, g.estado
 FROM gastos g JOIN encuestado x ON x.documento = g.id_encuestado
 JOIN hogar h ON h.id_hogar = x.id_hogar JOIN articulo a ON a.id_articulo = g.id_articulo
 JOIN recolector r ON r.documento = h.id_recolector
 WHERE h.id_hogar = p_hogar AND r.id_usuario = v_id
   AND EXISTS (SELECT 1 FROM visita vi WHERE vi.id_hogar = h.id_hogar
      AND vi.estado = 'PENDIENTE' AND TRUNC(vi.fecha_visita) = TRUNC(SYSDATE))
 ORDER BY g.fecha_registro DESC, g.id_gasto;
 RETURN c;
END;
/
SHOW ERRORS FUNCTION nb_gastos_hogar
GRANT EXECUTE ON nb_gastos_hogar TO rol_recolector;
SELECT name, line, text FROM user_errors WHERE name LIKE 'NB_%' ORDER BY name, sequence;
