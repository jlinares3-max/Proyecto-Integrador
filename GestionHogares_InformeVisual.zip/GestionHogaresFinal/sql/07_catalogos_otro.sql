SET SQLBLANKLINES ON
SET DEFINE OFF
-- Ejecutar como ENPH_ADMIGASCA.
CREATE OR REPLACE FUNCTION nb_opcion_otro(p_tipo VARCHAR2, p_nombre VARCHAR2) RETURN NUMBER IS
 v_id NUMBER; v_nombre VARCHAR2(100); e_nombre EXCEPTION;
BEGIN
 v_nombre := TRIM(p_nombre);
 IF v_nombre IS NULL THEN RAISE e_nombre; END IF;
 IF p_tipo = 'ARTICULO' THEN
 IF LENGTHB(v_nombre) > 100 THEN RAISE e_nombre; END IF;
 LOCK TABLE articulo IN EXCLUSIVE MODE;
 SELECT MIN(id_articulo) INTO v_id FROM articulo WHERE UPPER(TRIM(nombre)) = UPPER(v_nombre);
 IF v_id IS NULL THEN
 SELECT seq_articulo.NEXTVAL INTO v_id FROM dual;
 INSERT INTO articulo (id_articulo, nombre) VALUES (v_id, v_nombre);
 END IF;
 ELSIF p_tipo = 'UNIDAD_MEDIDA' THEN
 IF LENGTHB(v_nombre) > 30 THEN RAISE e_nombre; END IF;
 LOCK TABLE unidad_medida IN EXCLUSIVE MODE;
 SELECT MIN(id_unidad) INTO v_id FROM unidad_medida WHERE UPPER(TRIM(nombre)) = UPPER(v_nombre);
 IF v_id IS NULL THEN
 SELECT seq_unidad_medida.NEXTVAL INTO v_id FROM dual;
 INSERT INTO unidad_medida (id_unidad, nombre) VALUES (v_id, v_nombre);
 END IF;
 ELSIF p_tipo = 'FORMA_ADQUISICION' THEN
 IF LENGTHB(v_nombre) > 60 THEN RAISE e_nombre; END IF;
 LOCK TABLE forma_adquisicion IN EXCLUSIVE MODE;
 SELECT MIN(id_forma) INTO v_id FROM forma_adquisicion WHERE UPPER(TRIM(nombre)) = UPPER(v_nombre);
 IF v_id IS NULL THEN
 SELECT seq_forma_adquisicion.NEXTVAL INTO v_id FROM dual;
 INSERT INTO forma_adquisicion (id_forma, nombre) VALUES (v_id, v_nombre);
 END IF;
 ELSIF p_tipo = 'LUGAR_COMPRA' THEN
 IF LENGTHB(v_nombre) > 80 THEN RAISE e_nombre; END IF;
 LOCK TABLE lugar_compra IN EXCLUSIVE MODE;
 SELECT MIN(id_lugar) INTO v_id FROM lugar_compra WHERE UPPER(TRIM(nombre)) = UPPER(v_nombre);
 IF v_id IS NULL THEN
 SELECT seq_lugar_compra.NEXTVAL INTO v_id FROM dual;
 INSERT INTO lugar_compra (id_lugar, nombre) VALUES (v_id, v_nombre);
 END IF;
 ELSE RAISE e_nombre; END IF;
 RETURN v_id;
END;
/
SHOW ERRORS FUNCTION nb_opcion_otro
CREATE OR REPLACE PROCEDURE nb_gasto_con_otros(
 p_login_sesion VARCHAR2, p_clave_sesion VARCHAR2, p_gasto NUMBER,
 p_cantidad NUMBER, p_valor NUMBER, p_frecuencia VARCHAR2,
 p_articulo NUMBER, p_otro_articulo VARCHAR2,
 p_unidad NUMBER, p_otra_unidad VARCHAR2,
 p_forma NUMBER, p_otra_forma VARCHAR2,
 p_lugar NUMBER, p_otro_lugar VARCHAR2) IS
 v_usuario NUMBER; v_articulo NUMBER; v_unidad NUMBER; v_forma NUMBER; v_lugar NUMBER;
BEGIN
 SAVEPOINT gasto_otros;
 IF p_gasto IS NULL THEN
 v_usuario := nb_validar_sesion(p_login_sesion, p_clave_sesion, 'ENCUESTADO');
 ELSE
 v_usuario := nb_validar_sesion(p_login_sesion, p_clave_sesion, 'RECOLECTOR');
 END IF;
 v_articulo := p_articulo; v_unidad := p_unidad; v_forma := p_forma; v_lugar := p_lugar;
 IF p_otro_articulo IS NOT NULL THEN v_articulo := nb_opcion_otro('ARTICULO', p_otro_articulo); END IF;
 IF p_otra_unidad IS NOT NULL THEN v_unidad := nb_opcion_otro('UNIDAD_MEDIDA', p_otra_unidad); END IF;
 IF p_otra_forma IS NOT NULL THEN v_forma := nb_opcion_otro('FORMA_ADQUISICION', p_otra_forma); END IF;
 IF p_otro_lugar IS NOT NULL THEN v_lugar := nb_opcion_otro('LUGAR_COMPRA', p_otro_lugar); END IF;
 IF p_gasto IS NULL THEN
 nb_registrar_gasto(p_login_sesion,p_clave_sesion,p_cantidad,p_valor,p_frecuencia,v_forma,v_unidad,v_articulo,v_lugar);
 ELSE
 nb_editar_gasto(p_login_sesion,p_clave_sesion,p_gasto,p_cantidad,p_valor,p_frecuencia,v_forma,v_unidad,v_articulo,v_lugar);
 END IF;
EXCEPTION WHEN OTHERS THEN
 ROLLBACK TO gasto_otros;
 RAISE;
END;
/
SHOW ERRORS PROCEDURE nb_gasto_con_otros
GRANT EXECUTE ON nb_gasto_con_otros TO rol_encuestado;
GRANT EXECUTE ON nb_gasto_con_otros TO rol_recolector;
