SET SQLBLANKLINES ON
SET DEFINE OFF
WHENEVER SQLERROR EXIT SQL.SQLCODE
-- Ejecutar como ENPH_ADMIGASCA.
-- Funciones y procedimientos de conexión para la aplicación.
CREATE OR REPLACE FUNCTION nb_rol_sesion (
  p_login_sesion VARCHAR2, p_clave_sesion VARCHAR2
) RETURN VARCHAR2 IS
  v_rol VARCHAR2(20);
BEGIN
  SELECT rol INTO v_rol FROM usuario
  WHERE login = p_login_sesion AND contrasena = p_clave_sesion;
  RETURN v_rol;
EXCEPTION
  WHEN NO_DATA_FOUND THEN RETURN NULL;
END;
/
SHOW ERRORS FUNCTION nb_rol_sesion
CREATE OR REPLACE FUNCTION nb_id_sesion (
  p_login_sesion VARCHAR2, p_clave_sesion VARCHAR2
) RETURN NUMBER IS
  v_id NUMBER;
BEGIN
  SELECT id_usuario INTO v_id FROM usuario
  WHERE login = p_login_sesion AND contrasena = p_clave_sesion;
  RETURN v_id;
EXCEPTION
  WHEN NO_DATA_FOUND THEN RETURN NULL;
END;
/
SHOW ERRORS FUNCTION nb_id_sesion
CREATE OR REPLACE FUNCTION nb_validar_sesion (
  p_login_sesion VARCHAR2, p_clave_sesion VARCHAR2,
  p_rol VARCHAR2 DEFAULT NULL
) RETURN NUMBER IS
  v_id NUMBER;
  v_rol VARCHAR2(20);
  e_acceso EXCEPTION;
BEGIN
  v_id := nb_id_sesion(p_login_sesion, p_clave_sesion);
  v_rol := nb_rol_sesion(p_login_sesion, p_clave_sesion);
  IF v_id IS NULL OR v_rol IS NULL
     OR SYS_CONTEXT('USERENV','SESSION_USER') <> 'US_' || v_rol
     OR (p_rol IS NOT NULL AND v_rol <> p_rol) THEN
    RAISE e_acceso;
  END IF;
  RETURN v_id;
END;
/
SHOW ERRORS FUNCTION nb_validar_sesion
-- Ampliación del texto devuelto para ocho observaciones con tildes.
CREATE OR REPLACE FUNCTION fun_detalle_visitas_informe (
  p_id_hogar NUMBER, p_doc_recolector NUMBER
) RETURN VARCHAR2 IS
  v_detalle VARCHAR2(32767);
  CURSOR c_visitas IS
    SELECT fecha_visita, tipo_visita, observaciones FROM visita
    WHERE id_hogar = p_id_hogar ORDER BY fecha_visita, id_visita;
BEGIN
  IF fun_encuesta_finalizada(p_id_hogar, p_doc_recolector) = 0 THEN RETURN NULL; END IF;
  FOR v IN c_visitas LOOP
    v_detalle := v_detalle || TO_CHAR(v.fecha_visita, 'DD/MM/YYYY') || ' - '
      || v.tipo_visita || CHR(10) || 'Observaciones: '
      || NVL(v.observaciones, 'Sin observaciones') || CHR(10) || CHR(10);
  END LOOP;
  RETURN v_detalle;
END;
/
SHOW ERRORS FUNCTION fun_detalle_visitas_informe

CREATE OR REPLACE FUNCTION nb_documento_actual(p_login_sesion VARCHAR2, p_clave_sesion VARCHAR2) RETURN VARCHAR2 IS
    v_id_sesion NUMBER;
    v_rol_sesion VARCHAR2(20);
    v_documento VARCHAR2(20);
  BEGIN
    v_rol_sesion := nb_rol_sesion(p_login_sesion, p_clave_sesion);
    v_id_sesion := nb_validar_sesion(p_login_sesion, p_clave_sesion);
    IF v_rol_sesion = 'RECOLECTOR' THEN
      SELECT TO_CHAR(documento) INTO v_documento FROM recolector WHERE id_usuario = v_id_sesion;
    ELSIF v_rol_sesion = 'ENCUESTADO' THEN
      SELECT documento INTO v_documento FROM encuestado WHERE id_usuario = v_id_sesion;
    END IF;
    RETURN v_documento;
  END;
/
SHOW ERRORS FUNCTION nb_documento_actual
CREATE OR REPLACE FUNCTION nb_catalogo(p_login_sesion VARCHAR2, p_clave_sesion VARCHAR2, p_tipo VARCHAR2, p_padre NUMBER) RETURN SYS_REFCURSOR IS
    v_id_sesion NUMBER;
    e_acceso EXCEPTION;
    c SYS_REFCURSOR;
  BEGIN
    v_id_sesion := nb_validar_sesion(p_login_sesion, p_clave_sesion);
    IF p_tipo = 'DEPARTAMENTO' THEN
      OPEN c FOR SELECT id_departamento, nombre FROM departamento ORDER BY nombre;
    ELSIF p_tipo = 'MUNICIPIO' THEN
      OPEN c FOR SELECT id_municipio, nombre FROM municipio WHERE p_padre IS NULL OR id_departamento = p_padre ORDER BY nombre;
    ELSIF p_tipo = 'BARRIO' THEN
      OPEN c FOR SELECT id_barrio, nombre FROM barrio WHERE p_padre IS NULL OR id_municipio = p_padre ORDER BY nombre;
    ELSIF p_tipo = 'ARTICULO' THEN
      OPEN c FOR SELECT id_articulo, nombre FROM articulo ORDER BY nombre;
    ELSIF p_tipo = 'UNIDAD_MEDIDA' THEN
      OPEN c FOR SELECT id_unidad, nombre FROM unidad_medida ORDER BY nombre;
    ELSIF p_tipo = 'FORMA_ADQUISICION' THEN
      OPEN c FOR SELECT id_forma, nombre FROM forma_adquisicion ORDER BY nombre;
    ELSIF p_tipo = 'LUGAR_COMPRA' THEN
      OPEN c FOR SELECT id_lugar, nombre FROM lugar_compra ORDER BY nombre;
    ELSIF p_tipo = 'VIVIENDA' THEN
      v_id_sesion := nb_validar_sesion(p_login_sesion, p_clave_sesion, 'ADMINISTRADOR');
      OPEN c FOR SELECT v.id_vivienda, v.direccion || ' - ' || b.nombre FROM vivienda v JOIN barrio b ON b.id_barrio = v.id_barrio ORDER BY v.direccion;
    ELSIF p_tipo = 'RECOLECTOR' THEN
      v_id_sesion := nb_validar_sesion(p_login_sesion, p_clave_sesion, 'ADMINISTRADOR');
      OPEN c FOR SELECT documento, nombre || ' ' || apellido FROM recolector ORDER BY nombre;
    ELSIF p_tipo = 'HOGAR' THEN
      v_id_sesion := nb_validar_sesion(p_login_sesion, p_clave_sesion, 'ADMINISTRADOR');
      OPEN c FOR SELECT h.id_hogar, TO_CHAR(h.id_hogar) || ' - ' || v.direccion FROM hogar h JOIN vivienda v ON v.id_vivienda = h.id_vivienda WHERE h.id_recolector IS NULL ORDER BY h.id_hogar;
    ELSE RAISE e_acceso;
    END IF;
    RETURN c;
  END;
/
SHOW ERRORS FUNCTION nb_catalogo
CREATE OR REPLACE FUNCTION nb_hogares(p_login_sesion VARCHAR2, p_clave_sesion VARCHAR2) RETURN SYS_REFCURSOR IS
    v_id_sesion NUMBER;
    c SYS_REFCURSOR;
  BEGIN
    v_id_sesion := nb_validar_sesion(p_login_sesion, p_clave_sesion, 'ADMINISTRADOR');
    OPEN c FOR SELECT h.id_hogar, v.direccion, h.estado,
      r.nombre || ' ' || r.apellido, e.fecha_inicio, fun_dia_periodo(h.id_hogar),
      (SELECT COUNT(*) FROM visita vi WHERE vi.id_hogar = h.id_hogar),
      e.estado_ciclo, e.fecha_cierre, fun_contar_gastos_pendientes(h.id_hogar)
    FROM hogar h JOIN vivienda v ON v.id_vivienda = h.id_vivienda
    LEFT JOIN recolector r ON r.documento = h.id_recolector
    LEFT JOIN encuesta e ON e.id_hogar = h.id_hogar ORDER BY h.id_hogar;
    RETURN c;
  END;
/
SHOW ERRORS FUNCTION nb_hogares
CREATE OR REPLACE FUNCTION nb_visitas(p_login_sesion VARCHAR2, p_clave_sesion VARCHAR2) RETURN SYS_REFCURSOR IS
    v_id_sesion NUMBER;
    c SYS_REFCURSOR;
  BEGIN
    v_id_sesion := nb_validar_sesion(p_login_sesion, p_clave_sesion, 'RECOLECTOR');
    OPEN c FOR SELECT vi.id_visita, vi.id_hogar, CAST(vi.fecha_visita AS TIMESTAMP),
      vi.tipo_visita, vi.estado, v.direccion, vi.observaciones,
      fun_encuesta_finalizada(h.id_hogar, h.id_recolector)
    FROM visita vi JOIN hogar h ON h.id_hogar = vi.id_hogar
    JOIN vivienda v ON v.id_vivienda = h.id_vivienda
    JOIN recolector r ON r.documento = h.id_recolector
    WHERE r.id_usuario = v_id_sesion AND vi.estado = 'PENDIENTE'
      AND TRUNC(vi.fecha_visita) = TRUNC(SYSDATE)
      AND EXISTS (SELECT 1 FROM encuesta e WHERE e.id_hogar = h.id_hogar AND e.estado_ciclo = 'PROCESO') ORDER BY vi.fecha_visita, vi.id_visita;
    RETURN c;
  END;
/
SHOW ERRORS FUNCTION nb_visitas
CREATE OR REPLACE FUNCTION nb_gastos(p_login_sesion VARCHAR2, p_clave_sesion VARCHAR2) RETURN SYS_REFCURSOR IS
    v_id_sesion NUMBER;
    v_rol_sesion VARCHAR2(20);
    c SYS_REFCURSOR;
  BEGIN
    v_rol_sesion := nb_rol_sesion(p_login_sesion, p_clave_sesion);
    v_id_sesion := nb_validar_sesion(p_login_sesion, p_clave_sesion);
    OPEN c FOR SELECT g.id_gasto, g.fecha_registro, h.id_hogar, a.nombre,
      g.cantidad, g.valor_producto, g.estado
    FROM gastos g JOIN encuestado x ON x.documento = g.id_encuestado
    JOIN hogar h ON h.id_hogar = x.id_hogar JOIN articulo a ON a.id_articulo = g.id_articulo
    LEFT JOIN recolector r ON r.documento = h.id_recolector
    WHERE (v_rol_sesion = 'RECOLECTOR' AND r.id_usuario = v_id_sesion)
       OR (v_rol_sesion = 'ENCUESTADO' AND x.id_usuario = v_id_sesion)
    ORDER BY g.fecha_registro DESC, g.id_gasto;
    RETURN c;
  END;
/
SHOW ERRORS FUNCTION nb_gastos
CREATE OR REPLACE PROCEDURE nb_registrar_vivienda(p_login_sesion VARCHAR2, p_clave_sesion VARCHAR2, p_direccion VARCHAR2, p_barrio NUMBER, p_hogares NUMBER) IS
    v_id_sesion NUMBER;
  BEGIN
    v_id_sesion := nb_validar_sesion(p_login_sesion, p_clave_sesion, 'ADMINISTRADOR');
    pro_registrar_vivienda(p_direccion, p_barrio, p_hogares);
  END;
/
SHOW ERRORS PROCEDURE nb_registrar_vivienda
CREATE OR REPLACE PROCEDURE nb_registrar_recolector(p_login_sesion VARCHAR2, p_clave_sesion VARCHAR2, p_documento NUMBER, p_nombre VARCHAR2, p_apellido VARCHAR2, p_telefono NUMBER, p_login VARCHAR2, p_clave VARCHAR2) IS
    v_id_sesion NUMBER;
    v_usuario NUMBER;
  BEGIN
    SAVEPOINT registro;
    v_id_sesion := nb_validar_sesion(p_login_sesion, p_clave_sesion, 'ADMINISTRADOR');
    pro_registrar_usuario(p_login, p_clave, 'RECOLECTOR');
    SELECT seq_usuario.CURRVAL INTO v_usuario FROM dual;
    pro_registrar_recolector(p_documento, p_nombre, p_apellido, p_telefono, v_usuario);
  EXCEPTION WHEN OTHERS THEN
    ROLLBACK TO registro;
    RAISE;
  END;
/
SHOW ERRORS PROCEDURE nb_registrar_recolector
CREATE OR REPLACE PROCEDURE nb_registrar_hogar(p_login_sesion VARCHAR2, p_clave_sesion VARCHAR2, p_vivienda NUMBER, p_personas NUMBER, p_documento VARCHAR2, p_nombre VARCHAR2, p_apellido VARCHAR2, p_telefono NUMBER, p_correo VARCHAR2, p_login VARCHAR2, p_clave VARCHAR2) IS
    v_id_sesion NUMBER;
    v_usuario NUMBER;
    v_hogar NUMBER;
  BEGIN
    SAVEPOINT registro;
    v_id_sesion := nb_validar_sesion(p_login_sesion, p_clave_sesion, 'ADMINISTRADOR');
    pro_registrar_usuario(p_login, p_clave, 'ENCUESTADO');
    SELECT seq_usuario.CURRVAL INTO v_usuario FROM dual;
    pro_registrar_hogar(p_vivienda, p_personas);
    SELECT seq_hogar.CURRVAL INTO v_hogar FROM dual;
    pro_registrar_encuestado(p_documento, p_nombre, p_apellido, p_telefono, p_correo, v_hogar, v_usuario);
  EXCEPTION WHEN OTHERS THEN
    ROLLBACK TO registro;
    RAISE;
  END;
/
SHOW ERRORS PROCEDURE nb_registrar_hogar
CREATE OR REPLACE PROCEDURE nb_asignar(p_login_sesion VARCHAR2, p_clave_sesion VARCHAR2, p_hogar NUMBER, p_recolector NUMBER, p_inicio DATE) IS
    v_id_sesion NUMBER;
    e_acceso EXCEPTION;
    v_asignado NUMBER;
    v_total NUMBER;
  BEGIN
    SAVEPOINT asignacion;
    v_id_sesion := nb_validar_sesion(p_login_sesion, p_clave_sesion, 'ADMINISTRADOR');
    SELECT id_recolector INTO v_asignado FROM hogar WHERE id_hogar = p_hogar FOR UPDATE;
    IF v_asignado IS NOT NULL OR p_inicio IS NULL THEN RAISE e_acceso; END IF;
    pro_asignar_hogar(p_hogar, p_recolector);
    SELECT id_recolector INTO v_asignado FROM hogar WHERE id_hogar = p_hogar;
    IF v_asignado IS NULL OR v_asignado <> p_recolector THEN RAISE e_acceso; END IF;
    pro_iniciar_encuesta(p_hogar, p_inicio);
    SELECT COUNT(*) INTO v_total FROM visita WHERE id_hogar = p_hogar;
    IF v_total <> 8 THEN RAISE e_acceso; END IF;
  EXCEPTION WHEN OTHERS THEN
    ROLLBACK TO asignacion;
    RAISE;
  END;
/
SHOW ERRORS PROCEDURE nb_asignar
CREATE OR REPLACE PROCEDURE nb_observar(p_login_sesion VARCHAR2, p_clave_sesion VARCHAR2, p_visita NUMBER, p_nota VARCHAR2) IS
    v_id_sesion NUMBER;
    e_acceso EXCEPTION;
    v_total NUMBER;
    v_documento NUMBER;
  BEGIN
    v_id_sesion := nb_validar_sesion(p_login_sesion, p_clave_sesion, 'RECOLECTOR');
    v_documento := TO_NUMBER(nb_documento_actual(p_login_sesion, p_clave_sesion));
    SELECT COUNT(*) INTO v_total FROM visita vi JOIN hogar h ON h.id_hogar = vi.id_hogar
    WHERE vi.id_visita = p_visita AND h.id_recolector = v_documento AND vi.estado = 'PENDIENTE'
      AND TRUNC(vi.fecha_visita) = TRUNC(SYSDATE)
      AND EXISTS (SELECT 1 FROM encuesta e WHERE e.id_hogar = h.id_hogar AND e.estado_ciclo = 'PROCESO');
    IF v_total = 0 THEN RAISE e_acceso; END IF;
    pro_guardar_observacion_visita(p_visita, v_documento, p_nota);
  END;
/
SHOW ERRORS PROCEDURE nb_observar
CREATE OR REPLACE PROCEDURE nb_revisar(p_login_sesion VARCHAR2, p_clave_sesion VARCHAR2, p_gasto NUMBER) IS
    v_id_sesion NUMBER;
    e_acceso EXCEPTION;
    v_total NUMBER;
    v_documento NUMBER;
  BEGIN
    v_id_sesion := nb_validar_sesion(p_login_sesion, p_clave_sesion, 'RECOLECTOR');
    v_documento := TO_NUMBER(nb_documento_actual(p_login_sesion, p_clave_sesion));
    SELECT COUNT(*) INTO v_total FROM gastos g JOIN encuestado x ON x.documento = g.id_encuestado
    JOIN hogar h ON h.id_hogar = x.id_hogar
    WHERE g.id_gasto = p_gasto AND h.id_recolector = v_documento AND g.estado = 'PENDIENTE'
      AND EXISTS (SELECT 1 FROM visita vi WHERE vi.id_hogar = h.id_hogar AND vi.estado = 'PENDIENTE' AND TRUNC(vi.fecha_visita) = TRUNC(SYSDATE));
    IF v_total = 0 THEN RAISE e_acceso; END IF;
    pro_revisar_gasto(p_gasto, v_documento);
  END;
/
SHOW ERRORS PROCEDURE nb_revisar
CREATE OR REPLACE PROCEDURE nb_registrar_gasto(p_login_sesion VARCHAR2, p_clave_sesion VARCHAR2, p_cantidad NUMBER, p_valor NUMBER, p_frecuencia VARCHAR2, p_forma NUMBER, p_unidad NUMBER, p_articulo NUMBER, p_lugar NUMBER) IS
    v_id_sesion NUMBER;
    e_acceso EXCEPTION;
    v_documento VARCHAR2(20);
    v_total NUMBER;
  BEGIN
    v_id_sesion := nb_validar_sesion(p_login_sesion, p_clave_sesion, 'ENCUESTADO');
    v_documento := nb_documento_actual(p_login_sesion, p_clave_sesion);
    SELECT COUNT(*) INTO v_total FROM encuestado x JOIN encuesta e ON e.id_hogar = x.id_hogar
    WHERE x.documento = v_documento AND e.estado_ciclo = 'PROCESO'
      AND TRUNC(SYSDATE) BETWEEN TRUNC(e.fecha_inicio) AND TRUNC(e.fecha_cierre);
    IF v_total = 0 OR p_cantidad <= 0 OR p_valor < 0 THEN RAISE e_acceso; END IF;
    pro_registrar_gasto(v_documento, p_articulo, p_cantidad, p_unidad,
      p_valor, p_forma, p_lugar, p_frecuencia, SYSDATE, 'HOGAR');
  END;
/
SHOW ERRORS PROCEDURE nb_registrar_gasto
CREATE OR REPLACE PROCEDURE nb_cerrar(p_login_sesion VARCHAR2, p_clave_sesion VARCHAR2, p_hogar NUMBER) IS
    v_id_sesion NUMBER;
    e_acceso EXCEPTION;
    v_estado VARCHAR2(20);
    v_total NUMBER;
  BEGIN
    v_id_sesion := nb_validar_sesion(p_login_sesion, p_clave_sesion, 'RECOLECTOR');
    SELECT COUNT(*) INTO v_total FROM hogar h JOIN recolector r ON r.documento = h.id_recolector
      WHERE h.id_hogar = p_hogar AND r.id_usuario = v_id_sesion;
    IF v_total = 0 THEN RAISE e_acceso; END IF;
    pro_cerrar_encuesta(p_hogar);
    SELECT estado_ciclo INTO v_estado FROM encuesta WHERE id_hogar = p_hogar;
    IF v_estado <> 'FINALIZADO' THEN RAISE e_acceso; END IF;
  END;
/
SHOW ERRORS PROCEDURE nb_cerrar
CREATE OR REPLACE FUNCTION nb_informe(p_login_sesion VARCHAR2, p_clave_sesion VARCHAR2, p_hogar NUMBER) RETURN VARCHAR2 IS
    v_id_sesion NUMBER;
    v_documento NUMBER;
    v_resumen VARCHAR2(500);
    v_detalle VARCHAR2(32767);
  BEGIN
    v_id_sesion := nb_validar_sesion(p_login_sesion, p_clave_sesion, 'RECOLECTOR');
    v_documento := TO_NUMBER(nb_documento_actual(p_login_sesion, p_clave_sesion));
    IF fun_encuesta_finalizada(p_hogar, v_documento) = 0 THEN RETURN NULL; END IF;
    v_resumen := fun_resumen_informe(p_hogar, v_documento);
    v_detalle := fun_detalle_visitas_informe(p_hogar, v_documento);
    RETURN v_resumen || CHR(10) || CHR(10) || v_detalle;
  END;
/
SHOW ERRORS FUNCTION nb_informe
CREATE OR REPLACE FUNCTION nb_gasto_detalle(p_login_sesion VARCHAR2, p_clave_sesion VARCHAR2, p_gasto NUMBER) RETURN SYS_REFCURSOR IS
    v_id_sesion NUMBER;
    v_rol_sesion VARCHAR2(20);
    c SYS_REFCURSOR;
  BEGIN
    v_rol_sesion := nb_rol_sesion(p_login_sesion, p_clave_sesion);
    v_id_sesion := nb_validar_sesion(p_login_sesion, p_clave_sesion);
    OPEN c FOR SELECT g.cantidad, g.valor_producto, g.frecuencia_compra,
        g.id_forma, g.id_unidad, g.id_articulo, g.id_lugar
      FROM gastos g JOIN encuestado x ON x.documento = g.id_encuestado
      JOIN hogar h ON h.id_hogar = x.id_hogar
      LEFT JOIN recolector r ON r.documento = h.id_recolector
      WHERE g.id_gasto = p_gasto AND
        ((v_rol_sesion = 'ENCUESTADO' AND x.id_usuario = v_id_sesion)
          OR (v_rol_sesion = 'RECOLECTOR' AND r.id_usuario = v_id_sesion));
    RETURN c;
  END;
/
SHOW ERRORS FUNCTION nb_gasto_detalle
CREATE OR REPLACE PROCEDURE nb_editar_gasto(p_login_sesion VARCHAR2, p_clave_sesion VARCHAR2, p_gasto NUMBER, p_cantidad NUMBER, p_valor NUMBER, p_frecuencia VARCHAR2,
    p_forma NUMBER, p_unidad NUMBER, p_articulo NUMBER, p_lugar NUMBER) IS
    v_id_sesion NUMBER;
    v_rol_sesion VARCHAR2(20);
    e_acceso EXCEPTION;
    v_documento VARCHAR2(20);
    v_tipo VARCHAR2(10);
  BEGIN
    v_rol_sesion := nb_rol_sesion(p_login_sesion, p_clave_sesion);
    v_id_sesion := nb_validar_sesion(p_login_sesion, p_clave_sesion, 'RECOLECTOR');
    SELECT g.id_encuestado, g.tipo_gasto INTO v_documento, v_tipo
    FROM gastos g JOIN encuestado x ON x.documento = g.id_encuestado
    JOIN hogar h ON h.id_hogar = x.id_hogar
    LEFT JOIN recolector r ON r.documento = h.id_recolector
    WHERE g.id_gasto = p_gasto AND
      r.id_usuario = v_id_sesion
      AND EXISTS (SELECT 1 FROM visita vi WHERE vi.id_hogar = h.id_hogar AND vi.estado = 'PENDIENTE' AND TRUNC(vi.fecha_visita) = TRUNC(SYSDATE));
    IF p_cantidad <= 0 OR p_valor < 0 THEN RAISE e_acceso; END IF;
    pro_editar_gasto(p_gasto, v_documento, p_articulo, p_cantidad, p_unidad,
      p_valor, p_forma, p_lugar, p_frecuencia, v_tipo);
  END;
/
SHOW ERRORS PROCEDURE nb_editar_gasto
GRANT EXECUTE ON nb_rol_sesion TO rol_administrador;
GRANT EXECUTE ON nb_rol_sesion TO rol_recolector;
GRANT EXECUTE ON nb_rol_sesion TO rol_encuestado;
GRANT EXECUTE ON nb_id_sesion TO rol_administrador;
GRANT EXECUTE ON nb_id_sesion TO rol_recolector;
GRANT EXECUTE ON nb_id_sesion TO rol_encuestado;
GRANT EXECUTE ON nb_validar_sesion TO rol_administrador;
GRANT EXECUTE ON nb_validar_sesion TO rol_recolector;
GRANT EXECUTE ON nb_validar_sesion TO rol_encuestado;
GRANT EXECUTE ON nb_documento_actual TO rol_administrador;
GRANT EXECUTE ON nb_documento_actual TO rol_recolector;
GRANT EXECUTE ON nb_documento_actual TO rol_encuestado;
GRANT EXECUTE ON nb_catalogo TO rol_administrador;
GRANT EXECUTE ON nb_catalogo TO rol_recolector;
GRANT EXECUTE ON nb_catalogo TO rol_encuestado;
GRANT EXECUTE ON nb_hogares TO rol_administrador;
GRANT EXECUTE ON nb_hogares TO rol_recolector;
GRANT EXECUTE ON nb_hogares TO rol_encuestado;
GRANT EXECUTE ON nb_visitas TO rol_administrador;
GRANT EXECUTE ON nb_visitas TO rol_recolector;
GRANT EXECUTE ON nb_visitas TO rol_encuestado;
GRANT EXECUTE ON nb_gastos TO rol_administrador;
GRANT EXECUTE ON nb_gastos TO rol_recolector;
GRANT EXECUTE ON nb_gastos TO rol_encuestado;
GRANT EXECUTE ON nb_registrar_vivienda TO rol_administrador;
GRANT EXECUTE ON nb_registrar_vivienda TO rol_recolector;
GRANT EXECUTE ON nb_registrar_vivienda TO rol_encuestado;
GRANT EXECUTE ON nb_registrar_recolector TO rol_administrador;
GRANT EXECUTE ON nb_registrar_recolector TO rol_recolector;
GRANT EXECUTE ON nb_registrar_recolector TO rol_encuestado;
GRANT EXECUTE ON nb_registrar_hogar TO rol_administrador;
GRANT EXECUTE ON nb_registrar_hogar TO rol_recolector;
GRANT EXECUTE ON nb_registrar_hogar TO rol_encuestado;
GRANT EXECUTE ON nb_asignar TO rol_administrador;
GRANT EXECUTE ON nb_asignar TO rol_recolector;
GRANT EXECUTE ON nb_asignar TO rol_encuestado;
GRANT EXECUTE ON nb_observar TO rol_administrador;
GRANT EXECUTE ON nb_observar TO rol_recolector;
GRANT EXECUTE ON nb_observar TO rol_encuestado;
GRANT EXECUTE ON nb_revisar TO rol_administrador;
GRANT EXECUTE ON nb_revisar TO rol_recolector;
GRANT EXECUTE ON nb_revisar TO rol_encuestado;
GRANT EXECUTE ON nb_registrar_gasto TO rol_administrador;
GRANT EXECUTE ON nb_registrar_gasto TO rol_recolector;
GRANT EXECUTE ON nb_registrar_gasto TO rol_encuestado;
GRANT EXECUTE ON nb_cerrar TO rol_administrador;
GRANT EXECUTE ON nb_cerrar TO rol_recolector;
GRANT EXECUTE ON nb_cerrar TO rol_encuestado;
GRANT EXECUTE ON nb_informe TO rol_administrador;
GRANT EXECUTE ON nb_informe TO rol_recolector;
GRANT EXECUTE ON nb_informe TO rol_encuestado;
GRANT EXECUTE ON nb_gasto_detalle TO rol_administrador;
GRANT EXECUTE ON nb_gasto_detalle TO rol_recolector;
GRANT EXECUTE ON nb_gasto_detalle TO rol_encuestado;
GRANT EXECUTE ON nb_editar_gasto TO rol_administrador;
GRANT EXECUTE ON nb_editar_gasto TO rol_recolector;
GRANT EXECUTE ON nb_editar_gasto TO rol_encuestado;
SELECT object_name, object_type, status FROM user_objects
WHERE object_name LIKE 'NB_%' ORDER BY object_name;

-- Aplicar tambien 03_roles_seguimiento_registros.sql despues de este archivo.
