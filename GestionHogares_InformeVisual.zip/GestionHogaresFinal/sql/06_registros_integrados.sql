SET SQLBLANKLINES ON
CREATE OR REPLACE FUNCTION nb_registros(p_login_sesion VARCHAR2, p_clave_sesion VARCHAR2, p_tipo VARCHAR2) RETURN SYS_REFCURSOR IS
 v_id NUMBER; c SYS_REFCURSOR; e_tipo EXCEPTION;
BEGIN
 v_id := nb_validar_sesion(p_login_sesion, p_clave_sesion, 'ADMINISTRADOR');
 IF p_tipo = 'VIVIENDA' THEN
 OPEN c FOR SELECT v.id_vivienda,v.direccion,v.id_barrio,v.cant_hogares,b.nombre,m.nombre,d.nombre FROM vivienda v JOIN barrio b ON b.id_barrio=v.id_barrio JOIN municipio m ON m.id_municipio=b.id_municipio JOIN departamento d ON d.id_departamento=m.id_departamento ORDER BY v.direccion;
 ELSIF p_tipo = 'ENCUESTADO' THEN
 OPEN c FOR SELECT x.documento,x.nombre,x.apellido,x.telefono,x.correo,u.login,v.direccion,h.total_personas,h.estado,h.id_hogar,x.id_usuario,r.nombre || ' ' || r.apellido FROM encuestado x JOIN usuario u ON u.id_usuario=x.id_usuario JOIN hogar h ON h.id_hogar=x.id_hogar JOIN vivienda v ON v.id_vivienda=h.id_vivienda LEFT JOIN recolector r ON r.documento=h.id_recolector ORDER BY x.nombre;
 ELSIF p_tipo = 'RECOLECTOR' THEN
 OPEN c FOR SELECT r.documento,r.nombre,r.apellido,r.telefono,u.login,r.id_usuario FROM recolector r JOIN usuario u ON u.id_usuario=r.id_usuario ORDER BY r.nombre;
 ELSIF p_tipo = 'HOGAR' THEN
 OPEN c FOR SELECT h.id_hogar,h.total_personas,h.id_vivienda,v.direccion,h.estado,(SELECT MIN(x.nombre || ' ' || x.apellido) FROM encuestado x WHERE x.id_hogar=h.id_hogar),r.nombre || ' ' || r.apellido,h.id_recolector FROM hogar h JOIN vivienda v ON v.id_vivienda=h.id_vivienda LEFT JOIN recolector r ON r.documento=h.id_recolector ORDER BY v.direccion,h.id_hogar;
 ELSIF p_tipo = 'USUARIO' THEN
 OPEN c FOR SELECT id_usuario,login,rol FROM usuario ORDER BY login;
 ELSE RAISE e_tipo; END IF;
 RETURN c;
END;
/
SHOW ERRORS FUNCTION nb_registros
